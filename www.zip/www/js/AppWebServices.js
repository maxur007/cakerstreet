var app = angular.module('AppWebServices', ['ngCordova'])

// -----------------------------------------------------------------------------------------------
app.run(function($rootScope) {

})

// -----------------------------------------------------------------------------------------------
app.factory('WebService', function($http, $q, $rootScope, $state, $ionicLoading, $ionicPopup, LocalStore, $soap) {
        return {
            // make serve call without header
            makeServiceCall: function(url, params, apiMethod) {
                // if (navigator && navigator.connection && navigator.connection.type ===
                // 'NONE') {
                // $ionicPopup.alert({
                // title : "Classified App", template : '' + message, buttons : [ {
                // text : '<b>' + "OK" + '</b>', type : 'button-dark', onTap : function(e)
                // {
                // }
                // } ]
                // }).then(function(result) {
                // if (!result) {
                // ionic.Platform.exitApp();
                // }
                // });
                // } else {
                console.log('params: ' + JSON.stringify(params));
                $ionicLoading.show({
                    template: 'Loading...'
                });
                var defer = $q.defer();
                //alert('Url ' + url + ' params ' + JSON.stringify(params)  + ' apimethod ' + apiMethod);
                $http({
                    method: apiMethod,
                    url: url,
                    data: params,
                    // formData: params
                }).success(function(data) {
                    //alert('Success ' + JSON.stringify(data))
                    $ionicLoading.hide();
                    defer.resolve(data);
                }).error(function(data) {
                    //alert('Error ' + JSON.stringify(data))
                    $ionicLoading.hide();
                    defer.reject(data);
                });
                return defer.promise;
                // }
            },

            showAlert: function(message) {
                var alertPopup = $ionicPopup.alert({
                    title: "Nurtuary_App",
                    template: '' + message,
                    buttons: [{
                        text: '<b>' + "OK" + '</b>',
                        type: 'button-dark',
                        onTap: function(e) {}
                    }]
                });

            }
        };
    })
    // ------------------------------------------------------------------------------------------------
    .factory("LocalStorage", function($window, $rootScope) {
        angular.element($window).on('storage', function(event) {
            if (event.key === 'user') {
                $rootScope.$apply();
            }
        });
        return {
            setData: function(key, value) {
                $window.localStorage && $window.localStorage.setItem(key, value);
                return this;
            },
            getData: function(key) {
                return $window.localStorage && $window.localStorage.getItem(key);
            },
            clearAll: function(key) {
                $window.localStorage && $window.localStorage.setItem(key, 'null');
            },
            setObject: function(key, value) {
                $window.localStorage[key] = JSON.stringify(value);
            },
            getObject: function(key) {
                return JSON.parse($window.localStorage[key] || '{}');
            }
        };
    })
    // -----------------------------------------------------------------------------------------------
    .factory('LocalStore', function($window, $rootScope) {
        return {
            setPrefrenses: function(key, value) {
                window.localStorage.setItem(key, value);
            },
            getPrefrenses: function(key) {
                return window.localStorage.getItem(key);
            },
            setOjectPref: function(key, val) {
                $window.localStorage && $window.localStorage.setItem(key, val);
                return this;
            },
            getOjectPref: function(key) {
                return $window.localStorage && $window.localStorage.getItem(key);
            },
            clearAll: function(key) {
                $window.localStorage && $window.localStorage.setItem(key, null);
            }

        };
    })
    // -----------------------------------------------------------------------------------------------
