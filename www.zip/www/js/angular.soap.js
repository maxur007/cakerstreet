angular.module('angularSoap', [])

.factory("$soap", ['$q', function($q) {
        return {
            post: function(url, action, params) {
                var deferred = $q.defer();

                //Create SOAPClientParameters
                var soapParams = new SOAPClientParameters();
                for (var param in params) {
                    soapParams.add(param, params[param]);
                }

                //Create Callback
                var soapCallback = function(e) {
                    if (e.constructor.toString().indexOf("function Error()") != -1) {
                        deferred.reject("An error has occurred.");
                    } else {
                        deferred.resolve(e);
                    }
                }

                SOAPClient.invoke(url, action, soapParams, true, soapCallback);

                return deferred.promise;
            },
            setCredentials: function(username, password) {
                SOAPClient.username = username;
                SOAPClient.password = password;
            }
        }
    }])
    //user login  Api
    .factory("getuserdetail", ['$soap', '$rootScope', function($soap, $rootScope) {

        return {
            getuserdetail: function(Username, password) {
                return $soap.post($rootScope.base_url, "getuserdetail", { Username: Username, password: password });
            }
        }
    }])

.factory("ByPostcode", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        ByPostcode: function(Postcode, AccountCode, LicenseKey, MachineId) {
            return $soap.post($rootScope.getAddress_url, "ByPostcode", { Postcode: Postcode, AccountCode: AccountCode, LicenseKey: LicenseKey, MachineId: MachineId });
        }
    }
}])

.factory("FetchAddress", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        FetchAddress: function(Id, Language, ContentType, AccountCode, LicenseKey, MachineId) {
            return $soap.post($rootScope.getAddress_url, "FetchAddress", { Id: Id, Language: Language, ContentType: ContentType, AccountCode: AccountCode, LicenseKey: LicenseKey, MachineId: MachineId });
        }
    }
}])

.factory("GetAccessoriesByBakeryID", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        GetAccessoriesByBakeryID: function(bakeryid, pageno, pagesize) {
            console.log(bakeryid);
            console.log(pageno);
            console.log(pagesize);
            return $soap.post($rootScope.base_url, "GetAccessoriesByBakeryID", { 'bakeryID': bakeryid, 'pageno': pageno, 'pagesize': pagesize, 'searchkeyword': '' });
        }
    }
}])

.factory("GetOrderCancelReasonList", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        GetOrderCancelReasonList: function() {
            return $soap.post($rootScope.base_url, "GetOrderCancelReasonList");
        }
    }
}])

.factory("CancelOrder", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        CancelOrder: function(orderId, orderReason, orderDescription) {
            console.log(orderId);
            console.log(orderReason);
            console.log(orderDescription);
            return $soap.post($rootScope.base_url, "CancelOrder", { 'orderID': orderId, 'ordercancelreason': orderReason, 'comments': orderDescription });
        }
    }
}])

.factory("OrderDetails", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {

        OrderDetails: function(JsonObject) {
            console.log("'" + JsonObject + "'");
            return $soap.post($rootScope.base_url, "OrderDetails", { 'JsonString': "'" + JsonObject + "'" });
        }
    }
}])

.factory("SaveConfirmedOrderFromJson", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {

        SaveConfirmedOrderFromJson: function(JsonObject) {
            console.log(JsonObject);
            return $soap.post($rootScope.base_url, "SaveConfirmedOrderFromJson", { 'ordersJson': JsonObject });
        }
    }
}])

.factory("DeleteCustomerAddress", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        DeleteCustomerAddress: function(custID, deliveryID) {
            return $soap.post($rootScope.base_url, "DeleteCustomerAddress", { 'customerid': custID, 'deliveryadd_ID': deliveryID });
        }
    }
}])

.factory("ForgotPWD", ['$soap', '$rootScope', function($soap, $rootScope) {


    return {
        ForgotPWD: function(EmailID) {
            return $soap.post($rootScope.base_url, "ForgotPWD", { EmailID: EmailID });
        }
    }
}])


.factory("insertdevice", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        insertdevice: function(deviceID, UserID, devicetypeid) {
            return $soap.post($rootScope.base_url, "insertdevice", { deviceID: deviceID, UserID: UserID, devicetypeid: devicetypeid });
        }
    }
}])

.factory("getbakerylist_bypostcode", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        getbakerylist_bypostcode: function(pageno, pagesize, searchmiles, searchpostcode, searchkeyword) {
            return $soap.post($rootScope.base_url, "getbakerylist_bypostcode", { pageno: pageno, pagesize: pagesize, searchmiles: searchmiles, searchpostcode: searchpostcode, searchkeyword: searchkeyword }, { cache: true });
        }
    }
}])

.factory("getbakeryProducts_byBakeryid", ['$soap', '$rootScope', function($soap, $rootScope) {


    return {
        getbakeryProducts_byBakeryid: function(pageno, pagesize, bakeryId) {
            return $soap.post($rootScope.base_url, "getbakeryProducts_byBakeryid", { pageno: pageno, pagesize: pagesize, bakeryId: bakeryId }, { cache: true });
        }
    }
}])

.factory("bakerylist_filterList", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        bakerylist_filterList: function(postcode, miles) {
            return $soap.post($rootScope.base_url, "bakerylist_filterList", { postcode: postcode, miles: miles }, { cache: true });
        }
    }
}])

.factory("CustomerRegistration", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        CustomerRegistration: function(EmailID, FName, Lname, Password, Facebookid, socialType, postcodeSelected) {
            console.log(EmailID);
            console.log(FName);
            console.log(Lname);
            console.log(Password);
            console.log(Facebookid);
            console.log(socialType);
            console.log(postcodeSelected);
            return $soap.post($rootScope.base_url, "CustomerRegistration", { 'EmailID': EmailID, 'FName': FName, 'Lname': Lname, 'Password': Password, 'Facebookid': Facebookid, 'socialmediatype': socialType, "Postcode": postcodeSelected });
        }
    }
}])

//GetCakesListByPostcodeAndFilters
.factory("GetCakesListByPostcodeAndFilters", ['$soap', '$rootScope', function($soap, $rootScope) {

        return {
            GetCakesListByPostcodeAndFilters: function(filterObject) {
                return $soap.post($rootScope.base_url, "GetCakesListByPostcodeAndFilters", {
                    "pageno": filterObject.pageno,
                    "pagesize": filterObject.pagesize,
                    "searchmiles": filterObject.searchmiles,
                    "searchpostcode": filterObject.searchpostcode,
                    "bakeryids": filterObject.bakeryids,
                    "ocassionids": filterObject.ocassionids,
                    "deliveryids": filterObject.deliveryids,
                    "Caketypeids": filterObject.Caketypeids,
                    "CakeShapeids": filterObject.CakeShapeids,
                    "CakeSizeids": filterObject.CakeSizeids,
                    "minportion": filterObject.minportion,
                    "maxportion": filterObject.maxportion,
                    "minprice": filterObject.minprice,
                    "maxprice": filterObject.maxprice,
                    "sortcode": filterObject.sortcode
                });
            }
        }
    }])
    .factory("GetCakedetailByCakeID", ['$soap', '$rootScope', function($soap, $rootScope) {


        return {
            GetCakedetailByCakeID: function(pid) {
                return $soap.post($rootScope.base_url, "GetCakedetailByCakeID", { pid: pid });
            }
        }
    }])


.factory("GetCakeAttributesListByCakeID", ['$soap', '$rootScope', function($soap, $rootScope) {


    return {
        GetCakeAttributesListByCakeID: function(pid, sizeID) {
            return $soap.post($rootScope.base_url, "GetCakeAttributesListByCakeID", { pid: pid, sizeID: sizeID });
        }
    }
}])

.factory("AddUpdateCustomerAddress", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        AddUpdateCustomerAddress: function(address) {
            return $soap.post($rootScope.base_url, "AddUpdateCustomerAddress", { "address": address });
        }
    }
}])

.factory("GetCustomerAddressesByCustomerID", ['$soap', '$rootScope', function($soap, $rootScope) {


    return {
        GetCustomerAddressesByCustomerID: function(CustomerID) {
            return $soap.post($rootScope.base_url, "GetCustomerAddressesByCustomerID", { "CustomerID": CustomerID });
        }
    }
}])


.factory("GetCustomerDetailByID", ['$soap', '$rootScope', function($soap, $rootScope) {


    return {
        GetCustomerDetailByID: function(CustomerID) {
            return $soap.post($rootScope.base_url, "GetCustomerDetailByID", { "CustomerID": CustomerID });
        }
    }
}])

.factory("UpdateCustomerInformation", ['$soap', '$rootScope', function($soap, $rootScope) {

        return {
            UpdateCustomerInformation: function(cust) {
                return $soap.post($rootScope.base_url, "UpdateCustomerInformation", { "cust": cust });
            }
        }
    }])
    .factory("GetBakeriesAndCakesBypostcodeAndMiles", ['$soap', '$rootScope', function($soap, $rootScope) {

        return {
            GetBakeriesAndCakesBypostcodeAndMiles: function(pageno, pagesize, postcode, miles, searchkeyword) {
                return $soap.post($rootScope.base_url, "GetBakeriesAndCakesBypostcodeAndMiles", { 'pageno': pageno, 'pagesize': pagesize, 'postcode': postcode, 'miles': miles, 'searchkeyword': searchkeyword }, { cache: true });
            }
        }
    }])

.factory("GetCakesByPostcodeAndMiles", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        GetCakesByPostcodeAndMiles: function(pageno, pagesize, postcode, miles, catId, searchkeyword, sortcode) {
            return $soap.post($rootScope.base_url, "GetCakesByPostcodeAndMiles", { 'pageno': pageno, 'pagesize': pagesize, 'postcode': postcode, 'miles': miles, 'cids': catId, 'searchkeyword': searchkeyword, 'sortcode': sortcode }, { cache: true });
        }
    }
}])

// .factory("SaveConfirmedOrder", ['$soap', function($soap) {
//     
//     return {
//         SaveConfirmedOrder: function(orders) {
//             //var order = JSON.stringify(orders);
//             return $soap.post($rootScope.base_url, "SaveConfirmedOrder", { orders });
//         }
//     }
// }])

.factory("GetCategories", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        GetCategories: function() {
            return $soap.post($rootScope.base_url, "GetCategories");
        }
    }
}])

.factory("GetCustomerOrders", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        GetCustomerOrders: function(CustomerID, StartDate, EndDate, pagenumber, pagesize) {
            return $soap.post($rootScope.base_url, "GetCustomerOrders", { CustomerID: CustomerID, StartDate: StartDate, EndDate: EndDate, pagenumber: pagenumber, pagesize: pagesize });
        }
    }
}])

.factory("GetCustomerOrderDetail", ['$soap', '$rootScope', function($soap, $rootScope) {

        return {
            GetCustomerOrderDetail: function(customerID, orderID) {
                return $soap.post($rootScope.base_url, "GetCustomerOrderDetail", { 'CustomerID': customerID, 'OrderID': orderID });
            }
        }
    }])
    .factory("IsDeliverableToUserPostcode", ['$soap', '$rootScope', function($soap, $rootScope) {

        return {
            IsDeliverableToUserPostcode: function(postcode, cakeid) {
                console.log(postcode);
                console.log(cakeid);
                return $soap.post($rootScope.base_url, "IsDeliverableToUserPostcode", { 'userpostcode': postcode, 'cakeID': cakeid });
            }
        }
    }])

.factory("GetUserDetailByFacebookID", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        GetUserDetailByFacebookID: function(registrationType, socialmediaID) {
            return $soap.post($rootScope.base_url, "GetUserDetailByFacebookID", { 'SocialRegistrationType': registrationType, 'FacebookID': socialmediaID });
        }
    }
}])

.factory("UploadOrderPicture", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        UploadOrderPicture: function(image) {
            return $soap.post($rootScope.base_url, "UploadOrderPicture", { 'bytes': image });
        }
    }
}])

.factory("AddOnCustomerSocialMediaID", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        AddOnCustomerSocialMediaID: function(emailID, socialmediatype, Facebookid) {
            return $soap.post($rootScope.base_url, "AddOnCustomerSocialMediaID", { 'emailID': emailID, 'socialmediatype': socialmediatype, 'Facebookid': Facebookid });
        }
    }
}])

.factory("AddOnCustomerSocialMediaID", ['$soap', '$rootScope', function($soap, $rootScope) {

    return {
        AddOnCustomerSocialMediaID: function(emailID, socialmediatype, Facebookid) {
            return $soap.post($rootScope.base_url, "AddOnCustomerSocialMediaID", { 'emailID': emailID, 'socialmediatype': socialmediatype, 'Facebookid': Facebookid });
        }
    }
}])

.factory("UploadCustomerPicture", ['$soap', '$rootScope', function($soap, $rootScope) {

        return {
            UploadCustomerPicture: function(bytes, CustomerID) {
                return $soap.post($rootScope.base_url, "UploadCustomerPicture", { 'bytes': bytes, 'CustomerID': CustomerID });
            }
        }
    }])
    .factory("GetMilesListing", ['$soap', '$rootScope', function($soap, $rootScope) {
        return {
            GetMilesListing: function() {
                return $soap.post($rootScope.base_url, "GetMilesListing");
            }
        }
    }])
    .factory("Customrequirement_optionList", ['$soap', '$rootScope', function($soap, $rootScope) {
        return {
            Customrequirement_optionList: function() {
                return $soap.post($rootScope.base_url, "Customrequirement_optionList");
            }
        }
    }])
    .factory("getgoogleprdsbykeyword", ['$soap', '$rootScope', function($soap, $rootScope) {

        return {
            getgoogleprdsbykeyword: function(bytes, CustomerID) {
                return $soap.post($rootScope.base_url, "getgoogleprdsbykeyword", { 'strkeyword': strkeyword });
            }
        }
    }])
    .factory("Customrequirement_AttributeList", ['$soap', '$rootScope', function($soap, $rootScope) {

        return {
            Customrequirement_AttributeList: function(bytes, CustomerID) {
                return $soap.post($rootScope.base_url, "Customrequirement_AttributeList");
            }
        }
    }])
    .factory("CustomrequirementForm_Submit", ['$soap', '$rootScope', function($soap, $rootScope) {
        return {
            CustomrequirementForm_Submit: function(
                googleprdid,
                prdid,
                CRF_ID,
                custId,
                CRF_Name,
                CRF_EmailID,
                CRF_Alergyadvice,
                CRF_Cakedesc,
                CRF_remarks,
                CRF_Contactno,
                CRF_Postcode,
                CRF_datetime_dd_MM_yyy_HH_mm,
                CRF_iscollection,
                CRF_collectionuptomiles,
                CRF_isdelivery,
                CRF_messageoncake,
                CRF_OccasionID,
                CRF_portionmin,
                CRF_portionmax,
                CRF_Size,
                CRF_ShapeID,
                CRF_typeID,
                isimage1,
                isimage1New,
                image1,
                isimage2,
                isimage2New, image2, isimage3, isimage3New, image3, isimage4, isimage4New, image4, json_data) {
                console.log("parteek");
                console.log(json_data);
                console.log(googleprdid);
                console.log(prdid);
                console.log(CRF_ID);
                console.log(custId);
                console.log(CRF_Name);
                console.log(CRF_EmailID);
                console.log(CRF_Alergyadvice);
                console.log(CRF_Cakedesc);
                console.log(CRF_remarks);
                console.log(CRF_Contactno);
                console.log(CRF_Postcode);
                console.log(CRF_datetime_dd_MM_yyy_HH_mm);
                console.log(CRF_iscollection);
                console.log(CRF_collectionuptomiles);
                console.log(CRF_isdelivery);
                console.log(CRF_messageoncake);
                console.log(CRF_OccasionID);
                console.log(CRF_portionmin);
                console.log(CRF_portionmax);
                console.log(CRF_Size);
                console.log(CRF_ShapeID);
                console.log(CRF_typeID);
                console.log(isimage1);
                console.log(isimage1New);
                console.log(image1);
                return $soap.post($rootScope.base_url, "CustomrequirementForm_Submit", {
                    'googleprdid': googleprdid,
                    'prdid': prdid,
                    'CRF_ID': CRF_ID,
                    'custId': custId,
                    'CRF_Name': CRF_Name,
                    'CRF_EmailID': CRF_EmailID,
                    'CRF_Alergyadvice': CRF_Alergyadvice,
                    'CRF_Cakedesc': CRF_Cakedesc,
                    'CRF_remarks': CRF_remarks,
                    'CRF_Contactno': CRF_Contactno,
                    'CRF_Postcode': CRF_Postcode,
                    'CRF_datetime_dd_MM_yyy_HH_mm': CRF_datetime_dd_MM_yyy_HH_mm,
                    'CRF_iscollection': CRF_iscollection,
                    'CRF_collectionuptomiles': CRF_collectionuptomiles,
                    'CRF_isdelivery': CRF_isdelivery,
                    'CRF_messageoncake': CRF_messageoncake,
                    'CRF_OccasionID': CRF_OccasionID,
                    'CRF_portionmin': CRF_portionmin,
                    'CRF_portionmax': CRF_portionmax,
                    'CRF_Size': CRF_Size,
                    'CRF_ShapeID': CRF_ShapeID,
                    'CRF_typeID': CRF_typeID,
                    'isimage1': isimage1,
                    'isimage1New': isimage1New,
                    'image1': image1,
                    'isimage2': isimage2,
                    'isimage2New': isimage2New,
                    'image2': image2,
                    'isimage3': isimage3,
                    'isimage3New': isimage3New,
                    'image3': image3,
                    'isimage4': isimage4,
                    'isimage4New': isimage4New,
                    'image4': image4,
                    'attributesJson': json_data
                });
            }
        }
    }])
    .factory("getCustomrequirementList_byCustID", ['$soap', '$rootScope', function($soap, $rootScope) {
        return {
            getCustomrequirementList_byCustID: function(customerID, pageno, pagesize) {
                return $soap.post($rootScope.base_url, "getCustomrequirementList_byCustID", { 'customerID': customerID, 'pageno': pageno, 'pagesize': pagesize });
            }
        }
    }])
    .factory("generateProductbyQuoteID", ['$soap', '$rootScope', function($soap, $rootScope) {
        return {
            generateProductbyQuoteID: function(QuoteID) {
                return $soap.post($rootScope.base_url, "generateProductbyQuoteID", { 'QuoteID': QuoteID });
            }
        }
    }])
