var app = angular.module('starter', ['ionic', 'AppWebServices', 'starter.controllers', 'credit-cards', 'angularSoap', 'payPalService', 'ngCordova', 'ngCordovaOauth', 'ngStorage', 'ionic-datepicker', 'ionicNumberPicker'])
app.run(function($ionicPlatform, $rootScope, $window, $ionicPopup, $ionicPlatform, LocalStorage, $cordovaSplashscreen, $http, $cordovaGeolocation, $ionicModal, $timeout, $localStorage, $location, $ionicLoading, $cordovaToast, $timeout, $state, $localStorage) {

    $ionicPlatform.ready(function() {

        //push notificatiions 
        // pushNotification = window.plugins.pushNotification;

        // window.onNotification = function(e) {

        //     switch (e.event) {
        //         case 'registered':
        //             if (e.regid.length > 0) {
        //                 var device_token = e.regid;
        //                 console.log(device_token);
        //                 $localStorage.deviceToken = device_token;
        //                 console.log($localStorage.deviceToken);

        //             }
        //             break;

        //         case 'message':
        //             alert('msg received: ' + e.message);

        //             console.log(e.payload);
        //             break;

        //         case 'error':
        //             alert('error occured');
        //             break;

        //     }
        // };
        // window.errorHandler = function(error) {
        //     alert('an error occured');
        // }
        // pushNotification.register(
        //     onNotification,
        //     errorHandler, {
        //         'badge': 'true',
        //         'sound': 'true',
        //         'alert': 'true',
        //         'senderID': '262608592968',
        //         'ecb': 'onNotification',

        //     }
        // );
        // document.addEventListener("deviceready", onDeviceReady, false);

        // function onDeviceReady() {
        //     var push = PushNotification.init({
        //         "android": {
        //             "senderID": "262608592968",
        //             "title": "Caker Street"
        //                 // "iconColor": "red"
        //         }
        //     });
        //     push.on('registration', function(data) {
        //         console.log(data.registrationId);
        //         $localStorage.deviceToken = data.registrationId;
        //         //document.getElementById("gcm_id").innerHTML = data.registrationId;
        //     });

        //     push.on('notification', function(data) {
        //         $state.go('app.notification');
        //         //alert(data.title + " Message: " + data.message);
        //         console.log(data)
        //     });

        //     push.on('error', function(e) {
        //         alert(e);
        //     });
        // }
        // var push = PushNotification.init({
        //     "android": { "senderID": "262608592968" },
        //     "ios": { "alert": "true", "badge": "true", "sound": "true" },
        //     "windows": {}
        // });

        // push.on('registration', function(data) {
        //     console.log(data.registrationId);
        //     $localStorage.deviceToken = data.registrationId;
        //     // data.registrationId
        // });

        // push.on('notification', function(data) {
        //     // data.message,
        //     // data.title,
        //     // data.count,
        //     // data.sound,
        //     // data.image,
        //     // data.additionalData
        // });

        // push.on('error', function(e) {
        //     // e.message
        // });

        $rootScope.online = navigator.onLine;
        $window.addEventListener("offline", function() {
            $rootScope.$apply(function() {
                $rootScope.online = false;
            });
        }, false);

        $window.addEventListener("online", function() {
            $rootScope.$apply(function() {
                $rootScope.online = true;
            });
        }, false);
        $rootScope.uid = -1;
        $rootScope.quantity = [];
        $rootScope.timer_delay = 20000;
        $rootScope.detail = [];
        $rootScope.userdetail = '';
        $rootScope.BakeryidObject = '';
        $rootScope.sortcode = 0;
        $rootScope.update = false;
        $rootScope.isEdit = false;
        $localStorage.filterChoose = undefined;
        cordova.plugins.backgroundMode.isEnabled();
        cordova.plugins.backgroundMode.configure({
            silent: true
        });

        //live url
        //$rootScope.base_url = "https://www.cakerstreet.com/service.asmx";
        //local url
        $rootScope.base_url = "http://dev.cakerstreet.com/service.asmx";
        $rootScope.getAddress_url = "http://services.postcodeanywhere.co.uk/uk/lookup.asmx";


        navigator.splashscreen.show();

        // Moal Quanttaity cake detail
        function createQtyArray() {

            for (var i = 0; i <= 100; i++) {
                $rootScope.quantity.push({ value: i });
            }
        };

        createQtyArray();


        // listen for Online event
        function createCustomer() {
            // creating a customer: https://stripe.com/docs/api#create_customer
            stripe.customers.create({
                    description: "Aaron Saunders",
                    email: "aaron@clearlyinnovative.com"
                },
                function(response) {
                    alert("Customer created:\n\n" + JSON.stringify(response))
                    console.log(JSON.stringify(response, null, 2))
                },
                function(response) {
                    alert(JSON.stringify(response))
                } // error handler
            );
        }
        // document.addEventListener('deviceready', function() {
        //     // Android customization
        //     cordova.plugins.backgroundMode.setDefaults({
        //         title: 'Caker Street',
        //         text: 'The easiest way to pick a cake for your special day.',
        //         icon: "icon",
        //         resume: true / false,
        //         color: "#123456",
        //         isPublic: true / false,
        //     });
        //     // Enable background mode
        //     cordova.plugins.backgroundMode.enable();

        //     // Called when background mode has been activated
        //     cordova.plugins.backgroundMode.onactivate = function() {
        //         setTimeout(function() {
        //             // Modify the currently displayed notification
        //             cordova.plugins.backgroundMode.configure({
        //                 text: 'Running in background for more than 5s now.'
        //             });
        //         }, 5000);
        //     }
        // }, false);

        // document.addEventListener('deviceready', function() {

        //     // Android customization
        //     // To indicate that the app is executing tasks in background and being paused would disrupt the user.
        //     // The plug-in has to create a notification while in background - like a download progress bar.
        //     cordova.plugins.backgroundMode.setDefaults({
        //         title: 'Caker Street',
        //         text: 'The easiest way to pick a cake for your special occasion.'
        //     });

        //     // Enable background mode
        //     cordova.plugins.backgroundMode.enable();

        //     // Called when background mode has been activated
        //     cordova.plugins.backgroundMode.onactivate = function() {

        //         // Set an interval of 3 seconds (3000 milliseconds)
        //         setInterval(function() {
        //             console.log("appruning");
        //             // The code that you want to run repeatedly

        //         }, 3000);
        //     }
        // }, false);


        // listen for Offline event
        $rootScope.$on('$cordovaNetwork:offline', function(event, networkState) {
            var offlineState = networkState;
            $ionicLoading.hide();
            $cordovaToast.showLongBottom("Internet disconnected");
            // Create the event.
            var event = new CustomEvent('networkstatus', { 'status': 'offline' });
            window.dispatchEvent(event);
        });

        $rootScope.$on('$cordovaNetwork:online', function(event, networkState) {
            var onlineState = networkState;

            $cordovaToast.showLongBottom("Internet connected");
            // Create the event.
            var event = new CustomEvent('networkstatus', { 'status': 'online' });
            window.dispatchEvent(event);
        });

        if (window.cordova && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            cordova.plugins.Keyboard.disableScroll(true);
        }

        if (window.StatusBar) {
            // org.apache.cordova.statusbar required
            StatusBar.styleDefault();
        }

        if ($localStorage.userDetails != null && $localStorage.userDetails.length != 0 && $localStorage.postcodeSelected != null) {
            console.log($localStorage.detail);
            $rootScope.postcode = $localStorage.postcodeSelected;
            $rootScope.selectedvalue = $localStorage.milesSelected;
            $rootScope.miles = $localStorage.milesArray;
            if ($localStorage.detail != undefined) {
                $rootScope.detail = $localStorage.detail;
            } else {
                $rootScope.detail = [];
            }
            $state.go('app.home');
        } else if ($localStorage.loggedin != true && $localStorage.postcodeSelected == null) {
            $rootScope.loggedin = false;
            $rootScope.username = "Guest";
            $rootScope.userdetail = [];
            $rootScope.detail = [];
            $state.go('app.home');
        } else if ($localStorage.postcodeSelected != null) {
            $rootScope.postcode = $localStorage.postcodeSelected;
            $rootScope.selectedvalue = $localStorage.milesSelected;
            $rootScope.miles = $localStorage.milesArray;
            if ($localStorage.detail != undefined) {
                $rootScope.detail = $localStorage.detail;
            } else {
                $rootScope.detail = [];
            }
            //$rootScope.detail = $localStorage.detail;
            $state.go('app.home');
        } else {
            $rootScope.loggedin = false;
            $rootScope.username = "Guest";
            $rootScope.userdetail = [];
            if ($localStorage.detail != undefined) {
                $rootScope.detail = $localStorage.detail;
            } else {
                $rootScope.detail = [];
            }
            $state.go('app.home');
        }

    });


})

app.config(function($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
    // Disable the javascript scroll globally
    $ionicConfigProvider.scrolling.jsScrolling(true);
    $ionicConfigProvider.views.forwardCache(true);
    $ionicConfigProvider.views.swipeBackEnabled(false);
    // Ionic uses AngularUI Router which uses the concept of states
    // Learn more here: https://github.com/angular-ui/ui-router
    // Set up the various states which the app can be in.
    // Each state's controller can be found in controllers.js
    $stateProvider
        .state('app', {
            url: '/app',
            // cache: false,
            abstract: true,
            templateUrl: 'templates/menu.html',
            controller: 'AppCtrl'
        })

    .state('app.login', {

        url: '/login',
        cache: false,
        params: {
            'Is_delivery': null

        },
        views: {
            'menuContent': {
                templateUrl: 'templates/login.html',
                controller: 'loginCtrl'
            }
        }
    })

    .state('app.stripayment', {
        url: '/stripepages',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/stripe.html',
                controller: 'stripeCtrl'
            }
        }
    })

    .state('app.user-register-page', {

        url: '/user-register',
        cache: false,

        views: {
            'menuContent': {
                templateUrl: 'templates/user-register.html',
                controller: 'userRegisterCtrl'
            }
        }
    })

    .state('app.mywishlist', {
        url: '/mywishlist',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/mywishlist.html',
                controller: 'mywishlistCtrl'
            }
        }
    })

    .state('app.backerydetailbyfilter', {
        url: '/backeryfilter',
        cache: true,
        params: {
            'filter_object': null
        },
        views: {
            'menuContent': {
                templateUrl: 'templates/backerydetailsbyfilter.html',
                controller: 'backerydetailfilterCtrl'
            }
        }
    })

    .state('app.orderdetails', {
        url: '/orderdetails',
        cache: false,
        params: {
            'id': '',
        },
        views: {
            'menuContent': {
                templateUrl: 'templates/orderdetails.html',
                controller: 'orderdetailsCtrl'
            }
        }
    })

    .state('app.changepassword', {
        url: '/changepassword',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/changepassword.html',
                controller: 'changepasswordCtrl'
            }
        }
    })

    .state('app.manage_account', {
        url: '/manage_account',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/ManageAccount.html',
                controller: 'manage_accountCtrl'
            }
        }
    })

    .state('app.notification', {
        url: '/notification',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/notification.html',
                controller: 'notificationCtrl'
            }
        }
    })

    .state('app.manage_address', {
            url: '/manage_address',
            cache: false,
            views: {
                'menuContent': {
                    templateUrl: 'templates/manage_address.html',
                    controller: 'manage_addressCtrl'
                }
            }
        })
        .state('app.backreydetail', {
            url: '/backreydetail',
            cache: false,
            params: {
                'bakeryarray': null,
                'singleClicked': false
            },
            views: {
                'menuContent': {
                    templateUrl: 'templates/backreydetail.html',
                    controller: 'backreyDetailCtrl'
                }
            }
        })


    .state('app.termsandconditions', {
        url: '/termsandconditions',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/termsandconditions.html',
                controller: 'termsCtrl'
            }
        }
    })

    .state('app.privacypolicy', {
        url: '/privacypolicy',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/privacypolicy.html',
                controller: 'privacypolicyCtrl'
            }
        }
    })

    .state('app.transactionpolicy', {
        url: '/transactionpolicy',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/transactionpolicy.html',
                controller: 'transactionpolicyCtrl'
            }
        }
    })

    .state('app.help', {
        url: '/helpcenter',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/helpcenter.html',
                controller: 'helpcenterCtrl'
            }
        }
    })

    .state('app.facts', {
        url: '/facts',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/facts.html',
                controller: 'factsCtrl'
            }
        }
    })

    .state('app.returnpolicy', {
        url: '/returnpolicy',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/returnpolicy.html',
                controller: 'returnpolicyCtrl'
            }
        }
    })

    .state('app.paymentissues', {
        url: '/paymentissues',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/paymentissues.html',
                controller: 'paymentissuesCtrl'
            }
        }
    })

    .state('app.billingdetails', {
        url: '/billingdetails',
        cache: false,
        params: {
            'addressObj': null
        },

        views: {
            'menuContent': {
                templateUrl: 'templates/billingdetails.html',
                controller: 'billingDetailCtrl'
            }
        }
    })

    .state('app.billingaddressconfirm', {
        url: '/billingaddressconfirm',
        cache: true,
        params: {
            'billAddressObj': null
        },

        views: {
            'menuContent': {
                templateUrl: 'templates/billingaddressconfirm.html',
                controller: 'billingaddressconfirmCtrl'
            }
        }
    })

    .state('app.myorders', {
        url: '/myorders',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/myorders.html',
                controller: 'myordersCtrl'
            }
        }
    })

    .state('app.home', {

        url: '/home',
        cache: false,

        views: {
            'menuContent': {
                templateUrl: 'templates/home.html',
                controller: 'homeCtrl'
            }
        }
    })

    .state('app.searchbusiness', {
        url: '/searchbusiness',
        cache: true,
        params: {
            'postalcode': null,
            'miles': null
        },
        views: {
            'menuContent': {
                templateUrl: 'templates/searchbusiness.html',
                controller: 'searchlistCtrl'
            }
        }
    })

    .state('app.checkout', {
        url: '/checkout',
        cache: false,

        views: {
            'menuContent': {
                templateUrl: 'templates/paypalpage.html',
                controller: 'paypalCheckoutCtrl'
            }
        }
    })

    .state('app.forgetpwd', {
        url: '/forgetpwd',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/forgetpassword.html',
                controller: 'forgetpwdCtrl'
            }
        }
    })

    .state('app.filter', {
        url: '/filter',
        cache: false,
        params: {
            'backery_details': null
        },
        views: {
            'menuContent': {
                templateUrl: 'templates/filter.html',
                controller: 'FilterCtrl'
            }
        }
    })

    .state('app.contact_us', {
        url: '/contact_us',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/contact_us.html',
                controller: 'contactCtrl'
            }
        }
    })


    .state('app.registerbusiness', {
        url: '/registerbusiness',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/registerbusiness.html',
                controller: 'registerbusinessCtrl'
            }
        }
    })

    .state('app.aboutus', {
        url: '/aboutus',

        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/aboutus.html',
                controller: 'aboutusCtrl'
            }
        }
    })

    .state('app.shippingdetail', {
        url: '/shippigndetail',
        cache: false,
        params: {
            nextview: null,
        },
        views: {
            'menuContent': {
                templateUrl: 'templates/shipingdetail.html',
                controller: 'ShipingDetailctrl'
            }
        }
    })

    .state('app.categories', {
        url: '/categories',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/categories.html',
                controller: 'categoriesCtrl'
            }
        }
    })

    .state('app.search', {
        url: '/search',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/search.html',
                controller: 'searchCtrl'
            }
        }
    })

    .state('app.billingAddressPge', {
        url: '/billingAddressPge',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/BillingAddressPge.html',
                controller: 'billingAddressPge'
            }
        }
    })

    .state('app.searchcriteriapage', {
        url: '/searchCriteria',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/searchCriteria.html',
                controller: 'searchCriteriaCtrl'
            }
        }
    })

    .state('app.cart', {
        url: '/cart',
        params: {
            'cakeid': null
        },
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/cart.html',
                controller: 'cartCtrl'
            }
        }
    })

    .state('cartapp.cakes', {
        url: '/cakespage',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/cakes.html',
                controller: 'cakesCtrl'
            }
        }
    })

    .state('app.shippingaddress', {
        url: '/address',
        cache: false,
        params: { 'address_details': null },
        views: {
            'menuContent': {
                templateUrl: 'templates/shipping_address.html',
                controller: 'ship_addressCtrl'
            }
        }
    })

    .state('app.cakedetail', {
        url: '/cakedetail',
        cache: false,
        params: {
            'cakeid': null,
            'editTextMes': null,
            'image': null
        },
        views: {
            'menuContent': {
                templateUrl: 'templates/cakedetail.html',
                controller: 'cakedetailCtrl'
            }
        }
    })

    .state('app.buynow', {
        url: '/buynow',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/buynow.html',
                controller: 'buynowCtrl'
            }
        }
    })

    .state('app.filter_detail', {
        url: '/filterdetails',
        cache: true,
        params: {
            'bakeryarray': null,
            'singleClicked': false
        },
        views: {
            'menuContent': {
                templateUrl: 'templates/bussinessdetail.html',
                controller: 'bussinessDetail'
            }
        }
    })

    .state('app.invoice', {
            url: '/invoice',
            cache: false,
            views: {
                'menuContent': {
                    templateUrl: 'templates/invoice.html',
                    controller: 'invoiceCtrl'
                }
            }
        })
        .state('app.thanks', {
            url: '/thanks',
            cache: false,
            views: {
                'menuContent': {
                    templateUrl: 'templates/thanksmessage.html',
                    controller: 'thanksCtrl'
                }
            }
        })

    .state('app.faliure', {
        url: '/faliure',
        cache: false,
        views: {
            'menuContent': {
                templateUrl: 'templates/faliuremessage.html',
                controller: 'faliureCtrl'
            }
        }
    })

    .state('app.customer_requrments', {
            url: '/customer_requrments',
            cache: false,
            params: {
                'imageparmas': null
            },
            views: {
                'menuContent': {
                    templateUrl: 'templates/customer_requirment.html',
                    controller: 'customer_requirmentCtrl'
                }
            }
        })
        .state('app.allproducts', {
            url: '/allproducts',
            cache: true,
            params: {
                'bakeryinfo': null
            },
            //:playlistId
            views: {
                'menuContent': {
                    templateUrl: 'templates/allproducts.html',
                    controller: 'allproductsCtrl'
                }
            }
        })
        .state('app.customercare', {

            url: '/customercare',
            cache: false,
            params: {
                'crf_id': null
            },
            views: {
                'menuContent': {
                    templateUrl: 'templates/customercare.html',
                    controller: 'customercareCtrl'
                }
            }
        })
        .state('app.quotes', {

            url: '/quotes',
            cache: false,

            views: {
                'menuContent': {
                    templateUrl: 'templates/quotes.html',
                    controller: 'quotesCtrl'
                }
            }
        })
        .state('app.googleimages', {

            url: '/googleimages',
            cache: false,
            params: {
                'prid': null
            },
            views: {
                'menuContent': {
                    templateUrl: 'templates/googleimages.html',
                    controller: 'googleimagesCtrl'
                }
            }
        });

    //$urlRouterProvider.otherwise('/app/home');

});

app.directive('actualImage', ['$timeout', function($timeout) {
    return {
        link: function($scope, element, attrs) {
            function waitForImage(url) {
                var tempImg = new Image();
                tempImg.onload = function() {
                    $timeout(function() {
                        element.attr('src', url);
                    });
                }
                tempImg.src = url;
            }

            attrs.$observe('actualImage', function(newValue) {
                if (newValue) {
                    waitForImage(newValue);
                }
            });
        }
    }
}]);


app.directive('ngEnter', function() {
    return function(scope, element, attrs) {
        element.bind("keydown keypress", function(event) {
            //    console.log(event.which);
            if (event.which === 13) {
                scope.$apply(function() {
                    scope.$eval(attrs.ngEnter);

                });

                event.preventDefault();
            }
        })

    }
});
app.directive('replace', function() {
    return {
        require: 'ngModel',
        scope: {
            regex: '@replace',
            with: '@with'
        },
        link: function(scope, element, attrs, model) {
            model.$parsers.push(function(val) {
                if (!val) {
                    return;
                }
                var regex = new RegExp(scope.regex);
                var replaced = val.replace(regex, scope.with);
                if (replaced !== val) {
                    model.$setViewValue(replaced);
                    model.$render();
                }
                return replaced;
            });
        }
    };
})



app.constant('shopSettings', {

    payPalSandboxId: 'AXOuqjzW_FK1miF1YipDCqphx8-DGBzcY_zlvrwOFnNdMkUwDRsY4t9tjdyybNizZhgbaWCoXO8ZUMEj',

    payPalProductionId: 'production id here',

    payPalEnv: 'PayPalEnvironmentSandbox', // for testing production for production

    payPalShopName: 'MyShopName',

    payPalMerchantPrivacyPolicyURL: 'url to policy',

    payPalMerchantUserAgreementURL: 'url to user agreement '

});

app.directive('focus', function() {
    return {
        restrict: 'A',
        link: function($scope, elem, attrs) {
            elem.bind('keydown', function(e) {
                var code = e.keyCode || e.which;
                if (code == 13) {
                    e.preventDefault();
                    setTimeout(function() {
                        elem.parent().next().next().find('input')[0].focus();
                    }, 100);
                }
            });
        }
    }
})
app.directive('focuslogin', function() {
    return {
        restrict: 'A',
        link: function($scope, elem, attrs) {
            elem.bind('keydown', function(e) {
                var code = e.keyCode || e.which;
                if (code == 13) {
                    e.preventDefault();
                    setTimeout(function() {
                        elem.parent().next().find('input')[0].focus();
                    }, 100);
                }
            });
        }
    }
})
app.directive('focusMe', ['$timeout', function($timeout) {
    return {
        link: function(scope, element, attrs) {
            if (attrs.focusMeDisable === true) {
                return;
            }
            $timeout(function() {
                element[0].focus();
                if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
                    window.cordova.plugins.Keyboard.show(); //open keyboard manually
                }
            }, 350);
        }
    };
}])
app.directive('onFinishRender', function($timeout) {
    return {
        restrict: 'A',
        link: function(scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function() {
                    scope.$emit(attr.onFinishRender);
                });
            }
        }
    }
})
app.directive('myMaxlength', function() {
    return {
        require: 'ngModel',
        link: function(scope, element, attrs, ngModelCtrl) {
            var maxlength = Number(attrs.myMaxlength);

            function fromUser(text) {
                if (text.length > maxlength) {
                    var transformedInput = text.substring(0, maxlength);
                    ngModelCtrl.$setViewValue(transformedInput);
                    ngModelCtrl.$render();
                    return transformedInput;
                }
                return text;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
})
app.directive("moveNextOnMaxlength", function() {
    return {
        restrict: "A",
        link: function($scope, element) {
            element.on("input", function(e) {
                if (element.val().length == element.attr("maxlength")) {
                    var $nextElement = element.next();
                    if ($nextElement.length) {
                        $nextElement[0].focus();
                    }
                }
            });
        }
    }
});
