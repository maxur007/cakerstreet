app.controller('billingAddressPge', function($scope, $state, $stateParams,
    $rootScope, $localStorage,
    $cordovaNetwork, $cordovaToast, AddUpdateCustomerAddress, $ionicSideMenuDelegate, $ionicLoading) {
    $ionicSideMenuDelegate.canDragContent(false);
    console.log($rootScope.addressDetail);

    $scope.data = {};
    var deliveryadd_ID = 0;
    console.log($localStorage.userDetails);

    $scope.$on("$ionicView.afterLeave", function(event, data) {
        deliveryadd_ID = 0;

    });

    $rootScope.$on('$stateChangeSuccess', function(ev, to, toParams, from, fromParams) {
        $rootScope.previousState = from.name;
        $rootScope.currentState = to.name;
        console.log($rootScope.previousState);
        console.log($rootScope.currentState);

    });

    $scope.$on("$ionicView.afterEnter", function(event, data) {

        if ($rootScope.loggedin == true) {
            $scope.data.fname = $localStorage.userDetails.First_Name;
            $scope.data.lstname = $localStorage.userDetails.Last_Name;
            $scope.data.email = $localStorage.userDetails.Email;
            $scope.data.postcode = $localStorage.userDetails.Postcode;
            console.log(localStorage.userDetails.Postcode);

        }
        // handle event
        // if (!$rootScope.addressDetail || deliveryadd_ID == undefined || $rootScope.addressDetail == undefined) {
        //     $scope.data.fname = $rootScope.userdetail.Last_Name;

        //     $scope.data.lstname = $rootScope.userdetail.First_Name;
        //     $scope.data.email = $rootScope.userdetail.Email;
        // } else {
        //     deliveryadd_ID = $rootScope.addressDetail.deliveryadd_ID;
        //     $scope.data.fname = $rootScope.addressDetail.deliveryadd_fName;
        //     $scope.data.lstname = $rootScope.addressDetail.deliveryadd_lName;
        //     $scope.data.email = $rootScope.userdetail.Email;
        //     $scope.data.postcode = $rootScope.addressDetail.deliveryadd_zip;
        //     $scope.data.mobileno = $rootScope.addressDetail.deliveryadd_mobile;
        //     $scope.data.phoneno = $rootScope.addressDetail.deliveryadd_phone;
        //     $scope.data.city = $rootScope.addressDetail.deliveryadd_city;
        //     $scope.data.address = $rootScope.addressDetail.deliveryadd_address;
        // }
    });



    var shipingData = '';


    var IsDefaultDeliveryAdd;
    $scope.data.selectedvalue = 'United Kingdom';
    //backbutton
    //change
    $scope.myGoBack = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if ($rootScope.previousState == 'app.checkout') {
                $state.go("app.checkout");
            } else {
                $state.go("app.cart");
            }
        }
        //chnage
    $scope.cancel = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.cart");
        }
    }
    $scope.submit = function(data, selectedvalue, defaultcheckbox) {

        if (defaultcheckbox == undefined) {
            IsDefaultDeliveryAdd = false;

        } else {
            IsDefaultDeliveryAdd = defaultcheckbox;
        }
        // deliveryadd_ID = deliveryadd_ID + 1;
        console.log(selectedvalue);
        if (data.fname == '' || data.fname == undefined) {
            $cordovaToast.showLongBottom('Please Enter Firstname');
        } else if (data.lstname == '' || data.lstname == undefined) {

            $cordovaToast.showLongBottom('Please Enter Lastname');
        } else if (data.email == '' || data.email == undefined) {

            $cordovaToast.showLongBottom('Please Enter Email');
        } else if (!(/^([\w]+(?:\.[\w]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/.test(data.email))) {

            $cordovaToast.showLongBottom("Please enter valid Email");
        } else if (!(/^([\w]+(?:\.[\w]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/.test(data.email))) {
            $cordovaToast.showLongBottom("Please enter valid Email");
        } else if (data.postcode == '' || data.postcode == undefined) {

            $cordovaToast.showLongBottom('Please Enter Postcode');
        } else if (data.city == '' || data.city == undefined) {

            $cordovaToast.showLongBottom('Please Enter City');
        } else if (data.mobileno == '' || data.mobileno == undefined) {

            $cordovaToast.showLongBottom('Please Enter Mobile Number');
        } else if (data.phoneno == '' || data.phoneno == undefined) {

            $cordovaToast.showLongBottom('Please Enter Phone number');

        } else if (data.address == '' || data.address == undefined) {

            $cordovaToast.showLongBottom('Plase Enter Address');
        } else if (data.address == '' || data.address == undefined) {

            $cordovaToast.showLongBottom('Plase Enter Address');
        } else {

            // if ($cordovaNetwork.isOnline()) {
            // $ionicLoading.show({
            //     template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
            // });

            var address = {
                "deliveryadd_ID": deliveryadd_ID,
                "deliveryadd_custID": $rootScope.CustomerID,
                "deliveryadd_fName": data.fname,
                "deliveryadd_lName": data.lstname,
                "deliveryadd_address": data.address,
                "deliveryadd_city": data.city,
                "deliveryadd_county": selectedvalue,
                "deliveryadd_country": selectedvalue,
                "deliveryadd_zip": data.postcode,
                "deliveryadd_phone": data.phoneno,
                "deliveryadd_mobile": data.mobileno,
                "IsDefaultDeliveryAdd": IsDefaultDeliveryAdd
            }


            // AddUpdateCustomerAddress.AddUpdateCustomerAddress(address).then(function(response) {
            //     $ionicLoading.hide();
            //     console.log(response)
            //     if (response == 1) {
            //         $state.go("app.checkout");
            //     } else if (response != 1) {
            //         $cordovaToast.showLongBottom('Something went wrong please try again');
            //     } else {
            //         $cordovaToast.showLongBottom('please check Internet connection');
            //     }
            // });
            // }
        }

    }

});