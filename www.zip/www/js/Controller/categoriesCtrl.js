app
    .controller(
        'categoriesCtrl',
        function($scope, LocalStorage, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $location, $cordovaNetwork,
            $ionicSideMenuDelegate, LocalStore, $window, $ionicPlatform, $ionicModal,
            $q, $http, $cordovaToast, $ionicLoading, $ionicModal, getbakeryProducts_byBakeryid) {
            $ionicSideMenuDelegate.canDragContent(false);
            var pagenumber = 1;
            var pagesize = 10;
            var bakeryId = 21;
            var selected_category;
            var selected_miles;
            var timer;
            var delay_time = $rootScope.timer_delay;

            $scope.list = [];

            $scope.radiobtn = {};
            $scope.miles = {};


            //chnage
            $scope.goBack = function() {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    $state.go("app.home");
                }
            }
            $scope.changeselected = function() {

                alert((this.radiobtn));
                selected_category = this.radiobtn;
            }
            $scope.changemiles = function() {

                alert((this.miles));
                selected_miles = this.miles;
            }

            $scope.hide = true;
            $scope.hidediv = true;

            $scope.categories_select = function() {

                $scope.hide = $scope.hide ? false : true;

                $scope.hidediv = $scope.hidediv ? false : true;

            }

            $scope.hidemiles = true;
            $scope.miles_select = function() {

                $scope.hidemiles = $scope.hidemiles ? false : true;

            }
            apiTimeout();
            getbakeryProducts_byBakeryid.getbakeryProducts_byBakeryid(pagenumber, pagesize, bakeryId).then(function(response) {

                console.log(response);
                var jsondata = JSON.parse("{" + response + "}");
                clearTimeout(timer);
                for (var i = 0; i < jsondata.data.BakeryProducts.length; i++) {
                    $scope.list.push(jsondata.data.BakeryProducts[i]);
                }
            });

            /* apitimeout*/
            function apiTimeout() {
                clearTimeout(timer);
                timer = setTimeout(function() {
                    $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
                    $ionicLoading.hide();
                }, delay_time);
            }


        });
