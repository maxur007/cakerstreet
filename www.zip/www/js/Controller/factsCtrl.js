app
    .controller(
        'factsCtrl',
        function($scope, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $cordovaNetwork,
            $ionicSideMenuDelegate, LocalStore, LocalStorage, $ionicPlatform,
            $q, $cordovaNetwork, $cordovaToast) {
            $ionicSideMenuDelegate.canDragContent(false);
            //change
            $scope.myGoBack = function() {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    window.history.back();
                }
            }

        });