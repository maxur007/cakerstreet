app
    .controller(
        'returnpolicyCtrl',
        function($scope, LocalStorage, $state, $timeout, $ionicHistory,
            WebService, $rootScope,
            $ionicSideMenuDelegate, LocalStore, $ionicPlatform,
            $q, $cordovaNetwork, $cordovaToast) {
            $ionicSideMenuDelegate.canDragContent(false);
            //change
            $scope.myGoBack = function() {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    window.history.back();
                }
            }

        });