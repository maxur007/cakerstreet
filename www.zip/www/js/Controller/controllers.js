angular.module('starter.controllers', [])
app.controller('AppCtrl', function($scope, $state, $localStorage, $timeout,
    $http, UploadCustomerPicture, $ionicHistory, $rootScope, WebService, $interval,
    $location, $ionicLoading, $cordovaNetwork, $cordovaToast, $ionicSideMenuDelegate,
    $ionicPlatform, $ionicPopup, $ionicActionSheet, $cordovaCamera, LocalStorage,
    $ionicModal, $cordovaGeolocation, $localStorage) {


    var path = $location.path();
    $rootScope.username = "Guest";
    $rootScope.loggedin = false;

    $scope.$on("$ionicView.afterEnter", function(event, data) {
        $scope.notification = 0;
        getCartCount();
        /** **/
        //debugger;

        if ($localStorage.userDetails != null && $localStorage.userDetails.length != 0) {
            setTimeout(function() {
                if ($localStorage.userDetails.userID == 0) {
                    $rootScope.loggedin = false;
                    $rootScope.username = 'Guest'
                } else {
                    $rootScope.loggedin = true;
                    $rootScope.username = $localStorage.userDetails.Name;
                    $rootScope.userdetail = $localStorage.userDetails;
                    $rootScope.CustomerID = $localStorage.userDetails.userID;
                    //$localStorage.userFbImg = $localStorage.userDetails.ProfilePicture;
                }
            }, 50);
        }
        //debugger;
        if ($localStorage.userFbImg != undefined) {
            $scope.imgURI = $localStorage.userFbImg;
            //$scope.$apply();
        } else {
            $scope.imgURI = "img/icon_profile.png";
        }
    });
    //change
    $scope.logout_click = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            window.localStorage.clear();
            $ionicHistory.clearCache();
            $rootScope.loggedin = false;
            $rootScope.username = "Guest";
            $localStorage.userDetails = [];
            // $localStorage.postcodeSelected = null;
            // $localStorage.milesSelected = null;
            $rootScope.statename = null;
            //$localStorage.milesArray = null;
            $localStorage.userFbImg = undefined;
            $scope.imgURI = $scope.$new(true);
            $localStorage.detail = [];
            $rootScope.detail = [];
            $scope.count = 0;
            $rootScope.cartnotificationHome = false;
            $state.go('app.home', { reload: true });
            $cordovaToast.showLongBottom('Logged out successfully!');
        }
    };
    //change
    $scope.home = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go('app.home');
        }
    };
    //change
    $scope.myGoBack = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.home");
        }
    };


    $scope.goTo = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            if ($rootScope.loggedin == true) {
                $state.go('app.manage_account', { reload: true });
            }
        }
    };

    $scope.myorder = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            if ($rootScope.loggedin == true) {
                $state.go('app.myorders', { reload: true });
            }
        }
    };

    $scope.goToManageAddress = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $rootScope.statename = "app.home";
            $rootScope.showFooter = false;
            $state.go('app.shippingdetail', { 'nextview': null });
        }
    };
    $scope.goToquotes = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $rootScope.statename = "app.home";
            $rootScope.showFooter = false;
            $state.go("app.quotes");
        }
    };

    //change
    $scope.signin = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.login");
        }
    };
    //change
    $scope.mangeAccount_Arrowclick = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.manage_account");
        }
    };


    function getCartCount() {
        if ($rootScope.detail == undefined) {
            $scope.cartnotification = true;
            $scope.count = 0;
            $rootScope.cartnotificationHome = false;
        } else if ($rootScope.detail.length == 0) {
            $scope.cartnotification = true;
            $scope.count = 0;
            $rootScope.cartnotificationHome = false;
        } else {
            $scope.cartnotification = true;
            $rootScope.cartnotificationHome = true;
            $scope.count = $rootScope.detail.length;
        }
    };


    $scope.cart_click = function() {

        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if ($rootScope.detail.length == 0) {
            $cordovaToast.showLongBottom("Cart is empty");
        } else {
            $state.go("app.cart");
        }

    }



});
