app.controller('loginCtrl',
    function($scope, LocalStorage, $state, $timeout,
        $localStorage, WebService, $rootScope, $location, $ionicSideMenuDelegate, LocalStore, $window,
        $ionicPlatform, $q, $http, $cordovaToast, $ionicLoading, $cordovaNetwork,
        getuserdetail, insertdevice, $ionicPopup, $cordovaOauth, $q, $http, $window, GetUserDetailByFacebookID, CustomerRegistration, AddOnCustomerSocialMediaID) {
        $rootScope.checkoutStage = false;
        $ionicSideMenuDelegate.canDragContent(false);
        $scope.data = {};
        var timer;
        var delay_time = $rootScope.timer_delay;
        $scope.disableView = false;
        $scope.$on('$stateChangeSuccess', function(ev, to, toParams, from, fromParams) {


            $rootScope.previousState = from.name;
            $localStorage.previousState = $rootScope.previousState;
            console.log($localStorage.previousState);
            $rootScope.currentState = to.name;

        });
        if ($rootScope.previousState == 'app.checkout') {

            $rootScope.checkoutStage = true


        }

        if ($rootScope.previousState == 'app.cart') {

            $rootScope.cartstage = true


        }
        if ($localStorage.previousState == 'app.billingdetails') {
            $rootScope.billingdetailState = true
        }
        //
        //backbutton
        $scope.myGoBack = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if ($rootScope.previousState == 'app.cart') {
                $state.go("app.cart");
            } else if ($rootScope.previousState = 'app.forgetpwd') {
                $state.go("app.home");
            } else {
                window.history.back();
            }

        };

        $scope.data = {};
        $scope.search_click = function(data) {
            if ($cordovaNetwork.isOnline()) {
                if ($scope.data.email == '' || $scope.data.email == undefined) {
                    $cordovaToast.showLongBottom('Please Enter Email');
                } else if (!(/^([\w]+(?:\.[\w]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/.test($scope.data.email))) {
                    $cordovaToast.showLongBottom("Please enter valid email");
                } else if ($scope.data.password == '' || $scope.data.password == undefined) {
                    $cordovaToast.showLongBottom("Please enter password");
                } else {
                    cordova.plugins.Keyboard.close();
                    if ($cordovaNetwork.isOnline()) {
                        apiTimeout();
                        $ionicLoading.show({
                            noBackdrop: false,
                            template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                        });
                        getuserdetail.getuserdetail($scope.data.email, $scope.data.password).then(function(response) {
                            var jsondata = JSON.parse("{" + response + "}");
                            $ionicLoading.hide();
                            clearTimeout(timer);
                            console.log(jsondata);
                            $localStorage.userDetails = jsondata.data.User[0];

                            if (jsondata.data.User[0].userID == '0') {
                                $ionicLoading.hide();
                                cordova.plugins.Keyboard.close();
                                $rootScope.loggedin = false;
                                $localStorage.loggedin = $rootScope.loggedin;
                                $rootScope.username = " Guest";

                                $cordovaToast.showLongBottom(jsondata.data.User[0].Error);
                                $state.go("app.login");
                            } else if ($localStorage.previousState == 'app.billingdetails') {

                                $rootScope.loggedin = true;
                                $localStorage.loggedin = $rootScope.loggedin;
                                $rootScope.userdetail = jsondata.data.User[0];
                                $localStorage.userDetails = $rootScope.userdetail;
                                $rootScope.username = jsondata.data.User[0].Name;

                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                $localStorage.userFbImg = jsondata.data.User[0].ProfilePicture;
                                $rootScope.showFooter = true;
                                $state.go("app.shippingdetail");

                                $ionicLoading.hide();

                            } else if ($localStorage.previousState == 'app.checkout') {

                                $rootScope.loggedin = true;
                                $localStorage.loggedin = $rootScope.loggedin;
                                $rootScope.userdetail = jsondata.data.User[0];
                                $localStorage.userDetails = $rootScope.userdetail;
                                $rootScope.username = jsondata.data.User[0].Name;

                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                $localStorage.userFbImg = jsondata.data.User[0].ProfilePicture;
                                $rootScope.showFooter = true;
                                $state.go("app.stripayment");

                                $ionicLoading.hide();

                            } else if ($rootScope.previousState == 'app.cart') {

                                $rootScope.loggedin = true;
                                $localStorage.loggedin = $rootScope.loggedin;
                                $rootScope.userdetail = jsondata.data.User[0];
                                $localStorage.userDetails = $rootScope.userdetail;
                                $rootScope.username = jsondata.data.User[0].Name;

                                $rootScope.CustomerID = jsondata.data.User[0].userID;

                                // getpushApi();

                                $ionicLoading.hide();
                                // $state.go("app.filtersrch");
                                if (delivery == true) {
                                    $localStorage.userDetails = $rootScope.userdetail;
                                    $rootScope.showFooter = true;
                                    $localStorage.userFbImg = jsondata.data.User[0].ProfilePicture;
                                    $state.go("app.shippingdetail");
                                } else {
                                    $localStorage.userDetails = $rootScope.userdetail;
                                    $state.go("app.checkout");

                                }
                            } else {
                                $rootScope.loggedin = true;
                                $localStorage.loggedin = $rootScope.loggedin;
                                $ionicLoading.hide();
                                $rootScope.loggedin = true;
                                $rootScope.userdetail = jsondata.data.User[0];

                                $rootScope.username = jsondata.data.User[0].Name;
                                $rootScope.CustomerID = jsondata.data.User[0].userID;

                                // getpushApi();

                                // $ionicLoading.hide();
                                $localStorage.userDetails = jsondata.data.User[0];
                                console.log("logging");
                                $localStorage.userFbImg = jsondata.data.User[0].ProfilePicture;
                                $state.go("app.home");
                            }

                        }, function(err) {
                            console.log(err);
                            clearTimeout(timer);
                            $ionicLoading.hide();
                            var confirmPopup = $ionicPopup.confirm({
                                template: 'Something went wrong!',
                                cssClass: 'popup_head_cust',
                                scope: $scope,
                                buttons: [{
                                    text: 'Try Again!!',
                                    onTap: function(e) {
                                        $state.go($state.current, {}, { reload: true });
                                    }
                                }]
                            });

                        });
                    } else if ($cordovaNetwork.offline()) {
                        $ionicLoading.hide();
                        $cordovaToast.showLongBottom("Please check your internet");
                    } else {
                        $ionicLoading.hide();
                        $cordovaToast.showLongBottom("A Problem Occurred While Connecting to the Server");
                    }
                }
            } else {
                $ionicLoading.hide();
                $cordovaToast.showLongCenter("No internet connection!");
            }
        }


        var deviceToken = window.localStorage['device_token'];
        console.log(deviceToken);

        $scope.loginFB = function() {

            if ($cordovaNetwork.isOnline()) {
                //facebokplugin 
                facebookConnectPlugin.login(["email", "public_profile"], function(response) {
                    console.log(response);
                    console.log(JSON.stringify(response));
                    if (response.authResponse) {
                        facebookConnectPlugin.api("me/?fields=name,gender,location,picture,email", null,
                            function(response) {
                                $ionicLoading.show({
                                    noBackdrop: false,
                                    template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                                });
                                $scope.disableView = true;
                                console.log(response);
                                //  alert(JSON.stringify(response));
                                console.log(JSON.stringify(response));
                                $localStorage.userFbImg = response.picture.data.url;
                                console.log($localStorage.userFbImg);
                                var nameDetails = response.name.split(' ');
                                var name = nameDetails[0];
                                var surname = " - ";
                                if (nameDetails.length > 1) {
                                    surname = nameDetails[1];
                                }
                                //loader
                                $ionicLoading.show({
                                    noBackdrop: false,
                                    template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                                });
                                $cordovaToast.showLongBottom("Please wait we are connecting with SocialMedia");
                                loginConfirm(name, surname, response.email, response.id, 1);
                            });


                    }
                });
            } else {
                $ionicLoading.hide();
                $cordovaToast.showLongBottom("Please check your internet");
            }
        }

        function loginConfirm(fname, lname, emailid, socialmediaID, socialmediaType) {
            apiTimeout();

            $cordovaToast.showLongBottom("Please wait we are connecting with SocialMedia");
            $ionicLoading.show({
                noBackdrop: false,
                template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
            });
            GetUserDetailByFacebookID.GetUserDetailByFacebookID(socialmediaType, socialmediaID).then(function(response) {
                var jsondata = JSON.parse(response);
                $ionicLoading.hide();
                console.log(jsondata);
                clearTimeout(timer);
                if (jsondata.ErrorID == 1) {
                    // Error Not found
                    var pwd = (fname + lname);

                    CustomerRegistration.CustomerRegistration(emailid, fname, lname, pwd, socialmediaID, socialmediaType, $localStorage.postcodeSelected).then(function(responseReg) {
                        // debugger;
                        console.log(responseReg);
                        var jsondataReg = JSON.parse(responseReg);
                        $ionicLoading.hide();
                        if (jsondataReg != null) {
                            if (jsondataReg.data.Error == undefined || jsondataReg.data.Error == "") {
                                $rootScope.userdetail = jsondataReg.data.User[0];
                                $localStorage.userDetails = jsondataReg.data.User[0];
                                $ionicLoading.hide();
                                $rootScope.CustomerID = jsondataReg.data.User[0].userID;
                                if (jsondataReg.data.User[0].userID == 0) {
                                    $ionicLoading.hide();
                                    $rootScope.CustomerID = jsondataReg.data.User[0].userID;
                                    // $cordovaToast.showLongBottom(jsondataReg.data.User[0].Error);
                                    AddOnCustomerSocialMediaID.AddOnCustomerSocialMediaID(emailid, socialmediaType, socialmediaID).then(function(responseReg) {
                                        console.log(responseReg);
                                        var jsondata = JSON.parse("{" + responseReg + "}");
                                        $localStorage.userDetails = jsondata.data.User[0];

                                        if (jsondata.data.User[0].userID == '0') {
                                            $ionicLoading.hide();
                                            cordova.plugins.Keyboard.close();
                                            $rootScope.loggedin = false;
                                            $localStorage.loggedin = $rootScope.loggedin;
                                            $rootScope.username = " Guest";

                                            $cordovaToast.showLongBottom(jsondata.data.User[0].Error);
                                            $state.go("app.login");
                                        } else if ($localStorage.previousState == 'app.billingdetails') {

                                            $rootScope.loggedin = true;
                                            $localStorage.loggedin = $rootScope.loggedin;
                                            $rootScope.userdetail = jsondata.data.User[0];
                                            $localStorage.userDetails = $rootScope.userdetail;
                                            $rootScope.username = jsondata.data.User[0].Name;

                                            $rootScope.CustomerID = jsondata.data.User[0].userID;
                                            $rootScope.showFooter = true;
                                            $state.go("app.shippingdetail");

                                            $ionicLoading.hide();

                                        } else if ($rootScope.previousState == 'app.cart') {

                                            $rootScope.loggedin = true;
                                            $localStorage.loggedin = $rootScope.loggedin;
                                            $rootScope.userdetail = jsondata.data.User[0];
                                            $localStorage.userDetails = $rootScope.userdetail;
                                            $rootScope.username = jsondata.data.User[0].Name;

                                            $rootScope.CustomerID = jsondata.data.User[0].userID;

                                            // getpushApi();

                                            $ionicLoading.hide();
                                            // $state.go("app.filtersrch");
                                            if (delivery == true) {
                                                $localStorage.userDetails = $rootScope.userdetail;
                                                $rootScope.showFooter = true;
                                                $state.go("app.shippingdetail");
                                            } else {
                                                $localStorage.userDetails = $rootScope.userdetail;
                                                $state.go("app.checkout");

                                            }
                                        } else {
                                            $rootScope.loggedin = true;
                                            $localStorage.loggedin = $rootScope.loggedin;
                                            $ionicLoading.hide();
                                            $rootScope.loggedin = true;
                                            $rootScope.userdetail = jsondata.data.User[0];

                                            $rootScope.username = jsondata.data.User[0].Name;
                                            $rootScope.CustomerID = jsondata.data.User[0].userID;

                                            // getpushApi();

                                            // $ionicLoading.hide();
                                            $localStorage.userDetails = jsondata.data.User[0];
                                            console.log("logging");

                                            $cordovaToast.showLongBottom('Logged In successfully!');
                                            if ($localStorage.postcodeSelected != undefined) {
                                                $state.go('app.searchbusiness');
                                            } else {
                                                $state.go('app.home');
                                            }
                                        }


                                    });

                                } else {
                                    $rootScope.loggedin = true;
                                    $ionicLoading.hide();
                                    $cordovaToast.showLongBottom('Logged in successfully!');
                                    if ($localStorage.postcodeSelected != undefined) {
                                        $state.go('app.searchbusiness');
                                    } else {
                                        $state.go('app.home');
                                    }

                                }

                            } else {
                                $ionicLoading.hide();
                                $scope.disableView = false;
                                $cordovaToast.showLongBottom(jsondataReg.data.Error);
                            }
                        } else {
                            $ionicLoading.hide();
                            $scope.disableView = false;
                            $cordovaToast.showLongBottom("Something went wrong! Please check your login deatils.");
                        }
                    });
                } else if ($localStorage.previousState == 'app.billingdetails') {

                    // Found in cakerstreet
                    $rootScope.loggedin = true;
                    $localStorage.loggedin = $rootScope.loggedin;
                    $rootScope.userdetail = jsondata.User;
                    $rootScope.CustomerID = jsondata.User.userID;
                    $localStorage.userDetails = jsondata.User;
                    $rootScope.showFooter = true;
                    $state.go("app.shippingdetail");

                    $ionicLoading.hide();

                } else if ($localStorage.previousState == 'app.checkout') {

                    // Found in cakerstreet
                    $rootScope.loggedin = true;
                    $localStorage.loggedin = $rootScope.loggedin;
                    $rootScope.userdetail = jsondata.User;
                    $rootScope.CustomerID = jsondata.User.userID;
                    $localStorage.userDetails = jsondata.User;
                    $rootScope.showFooter = true;
                    $state.go("app.stripayment");

                    $ionicLoading.hide();

                } else {
                    // Found in cakerstreet
                    $rootScope.loggedin = true;
                    $localStorage.loggedin = $rootScope.loggedin;
                    $rootScope.userdetail = jsondata.User;
                    $rootScope.CustomerID = jsondata.User.userID;
                    $localStorage.userDetails = jsondata.User;

                    $ionicLoading.hide();
                    $cordovaToast.showLongBottom('Logged in successfully!');
                    //$state.go('app.home');
                    if ($localStorage.postcodeSelected != undefined) {
                        $state.go('app.searchbusiness');
                    } else {
                        $state.go('app.home');
                    }
                }
            }, function(err) {
                console.log(err);
                clearTimeout(timer);
                $ionicLoading.hide();
                var confirmPopup = $ionicPopup.confirm({
                    template: 'Something went wrong!',
                    cssClass: 'popup_head_cust',
                    scope: $scope,
                    buttons: [{
                        text: 'Try Again!!',
                        onTap: function(e) {
                            $state.go($state.current, {}, { reload: true });
                        }
                    }]
                });

            });
        }


        $scope.loginGoogle = function() {
            $scope.disableView = true;
            if ($cordovaNetwork.isOnline()) {
                $ionicLoading.show({
                    noBackdrop: false,
                    template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                });

                window.plugins.googleplus.login({},
                    function(user_data) {

                        $localStorage.userFbImg = user_data.imageUrl;
                        if (user_data.email != null) {
                            console.log('email');
                            var surname = " - ";
                            console.log(user_data.email);
                            var name = "";
                            if (user_data.familyName == "") {
                                console.log(user_data.familyName);
                                surname = " - ";
                            } else {
                                surname = user_data.familyName;
                                console.log(surname);
                            }
                            if (user_data.givenName == "") {
                                if (user_data.givenName == "") {
                                    name = user_data.email.substring(0, user_data.email.lastIndexOf('@'));
                                } else {
                                    name = user_data.givenName;
                                }
                            } else {
                                name = user_data.givenName;
                            }
                            console.log('name');

                            $cordovaToast.showLongBottom("Please wait we are connecting with SocialMedia");
                            $scope.disableView = true;
                            loginConfirm(name, surname, user_data.email, user_data.userId, 2);


                            $ionicLoading.hide();
                        } //$state.go('app.home');
                    },
                    function(msg) {
                        $ionicLoading.hide();
                        $scope.disableView = false;
                        console.log(msg);
                    }
                );
            } else {
                $ionicLoading.hide();
                $cordovaToast.showLongBottom("Please check your internet");
            }
        }

        //forgot password
        // $ionicModal.fromTemplateUrl('templates/modal.html', {
        //     scope: $scope
        // }).then(function(modal) {
        //     $scope.modal = modal;
        // });





        childid = [];
        finalProductList = [];

        //login button
        $scope.loginSubmit = function(data) {
            if ($cordovaNetwork.isOnline()) {
                if (data.email == '' || data.email == undefined) {
                    $cordovaToast.showLongBottom('Please Enter Email');
                } else if (!(/^([\w]+(?:\.[\w]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/.test(data.email))) {
                    $cordovaToast.showLongBottom("Please enter valid email");
                } else if (data.password == '' || data.password == undefined) {
                    $cordovaToast.showLongBottom("Please enter password");

                } else {
                    if ($cordovaNetwork.isOnline()) {

                        $ionicLoading.show({
                            noBackdrop: false,
                            template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                        });
                        apiTimeout();
                        getuserdetail.getuserdetail(data.email, data.password).then(function(response) {
                            var jsondata = JSON.parse("{" + response + "}");
                            clearTimeout(timer);

                            if (jsondata.data.User[0].userID == '0') {
                                $localStorage.userDetails = jsondata.data.User[0];
                                $scope.loader = false;
                                $rootScope.loggedin = false;
                                $localStorage.loggedin = $rootScope.loggedin;
                                $rootScope.username = "Guest";
                                $ionicLoading.hide();
                                $cordovaToast.showLongBottom(jsondata.data.User[0].Error);
                                $state.go("app.login");
                            } else if ($localStorage.previousState == 'app.billingdetails') {

                                $rootScope.loggedin = true;
                                $localStorage.loggedin = $rootScope.loggedin;
                                $rootScope.userdetail = jsondata.data.User[0];
                                $localStorage.userDetails = $rootScope.userdetail;
                                $rootScope.username = jsondata.data.User[0].Name;

                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                $rootScope.showFooter = true;
                                $localStorage.userFbImg = jsondata.data.User[0].ProfilePicture;
                                $state.go("app.shippingdetail");

                                $ionicLoading.hide();

                            } else if ($localStorage.previousState == 'app.checkout') {

                                $rootScope.loggedin = true;
                                $localStorage.loggedin = $rootScope.loggedin;
                                $rootScope.userdetail = jsondata.data.User[0];
                                $localStorage.userDetails = $rootScope.userdetail;
                                $rootScope.username = jsondata.data.User[0].Name;

                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                $rootScope.showFooter = true;
                                $localStorage.userFbImg = jsondata.data.User[0].ProfilePicture;
                                $state.go("app.stripayment");

                                $ionicLoading.hide();

                            } else if ($rootScope.previousState == 'app.cart') {
                                $localStorage.userDetails = jsondata.data.User[0];
                                $scope.loader = false;
                                $rootScope.loggedin = true;
                                $rootScope.username = jsondata.data.User[0].Name;
                                $rootScope.userdetail = jsondata.data.User[0];
                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                $ionicLoading.hide();

                                if (delivery == true) {
                                    $rootScope.showFooter = true;
                                    $localStorage.userFbImg = jsondata.data.User[0].ProfilePicture;
                                    $state.go("app.shippingdetail");
                                } else {
                                    $state.go("app.checkout");
                                }
                            } else {
                                $ionicLoading.hide();
                                $rootScope.loggedin = true;
                                $localStorage.loggedin = $rootScope.loggedin;
                                $rootScope.userdetail = jsondata.data.User[0];
                                $rootScope.username = jsondata.data.User[0].Name;
                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                $localStorage.userDetails = jsondata.data.User[0];

                                $rootScope.loggedin = true;
                                $localStorage.userFbImg = undefined;
                                $cordovaToast.showLongBottom('Logged In successfully!');
                                $localStorage.userFbImg = jsondata.data.User[0].ProfilePicture;
                                $state.go("app.home");
                            }
                        }, function(err) {
                            console.log(err);
                            clearTimeout(timer);
                            $ionicLoading.hide();
                            var confirmPopup = $ionicPopup.confirm({
                                template: 'Something went wrong!',
                                cssClass: 'popup_head_cust',
                                scope: $scope,
                                buttons: [{
                                    text: 'Try Again!!',
                                    onTap: function(e) {
                                        $state.go($state.current, {}, { reload: true });
                                    }
                                }]
                            });

                        });



                    }
                }
            } else {
                $ionicLoading.hide();
                $cordovaToast.showLongBottom("Please check your internet");
            }
        }

        $scope.Signup = function(data) {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    $state.go("app.user-register-page");
                }

            }
            //Change
        $scope.forgetpwd = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $state.go("app.forgetpwd");
            }
        }



        function apiTimeout() {
            clearTimeout(timer);
            timer = setTimeout(function() {
                $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
                $ionicLoading.hide();
            }, delay_time);
        }
    });
