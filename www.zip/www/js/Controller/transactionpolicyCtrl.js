app
    .controller(
        'transactionpolicyCtrl',
        function($scope, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $location,
            $ionicSideMenuDelegate, LocalStore, LocalStorage, $window, $ionicPlatform, $ionicModal,
            $q, $http, $ionicLoading, $cordovaNetwork, $cordovaToast) {
            $ionicSideMenuDelegate.canDragContent(false);

            //change
            $scope.myGoBack = function() {
                // if ($cordovaNetwork.isOffline()) {
                //     $cordovaToast.showLongCenter("No internet connection!");
                // } else {
                    window.history.back();
               // }
            }

        });