app
    .controller(
        'buynowCtrl',
        function($scope, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $location,
            $ionicSideMenuDelegate, LocalStore, LocalStorage, $window, $ionicPlatform, $ionicModal,
            $q, $http, $cordovaToast, $ionicLoading, $ionicModal, $cordovaNetwork) {
            $ionicSideMenuDelegate.canDragContent(false);
            //change
            $scope.myGoBack = function() {
                    if ($cordovaNetwork.isOffline()) {
                        $cordovaToast.showLongCenter("No internet connection!");
                    } else {
                        $state.go("app.cakedetail");
                    }
                }
                //change
            $scope.submit = function() {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    $state.go("app.shippingaddress");
                }
            }

        });