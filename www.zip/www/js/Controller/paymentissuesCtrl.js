app
    .controller(
        'paymentissuesCtrl',
        function($scope, LocalStorage, $state, $timeout, $ionicHistory, WebService, $rootScope, $ionicSideMenuDelegate, LocalStore,
            $ionicPlatform, $q, $cordovaNetwork, $cordovaToast) {
            $ionicSideMenuDelegate.canDragContent(false);
            //change
            $scope.goBack = function() {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    $state.go("app.home");
                }
            }


        });