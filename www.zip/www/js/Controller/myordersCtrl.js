app.controller('myordersCtrl', function($scope, $state, $rootScope, CancelOrder, $filter, $ionicModal, GetOrderCancelReasonList, $timeout, $ionicPopup, $ionicSideMenuDelegate, $ionicLoading, $ionicHistory, $cordovaToast, $cordovaNetwork, GetCustomerOrders, $ionicPlatform, ionicDatePicker) {

    // var timer;
    // var delay_time = $rootScope.timer_delay;


    $ionicPlatform.registerBackButtonAction(function(event) {
        $scope.myGoBack();
    }, 100);

    $ionicSideMenuDelegate.canDragContent(false);
    $scope.selectMessege = true;
    $scope.noitem = false;
    $scope.data = {};
    $scope.data.orders = [];
    $scope.data.orderCount = '';
    //change
    $scope.myGoBack = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.home");
        }
    };

    $scope.$on("$ionicView.afterEnter", function(event, data) {
        var date = new Date();
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        if (month < 10) {
            month = "0" + month;
        }
        var fullDate = date.getDate();
        if (fullDate < 10) {
            fullDate = "0" + fullDate;
        };

        $scope.data.end = year + '-' + month + '-' + fullDate;
        $scope.data.endShow = fullDate + '-' + month + '-' + year;


        // var last = new Date(date.getTime() - (7 * 24 * 60 * 60 * 1000));
        var last = date - 1000 * 60 * 60 * 24 * 7;
        last = new Date(last);

        //xdebugger;
        var yearStart = last.getFullYear();

        var dayStart = last.getDate();

        if (dayStart < 10) {
            dayStart = "0" + dayStart;
        };

        var monthStart = last.getMonth() + 1;


        if (monthStart < 10) {

            monthStart = "0" + monthStart;
        };

        $scope.data.start = yearStart + '-' + monthStart + '-' + dayStart;
        $scope.data.startShow = dayStart + '-' + monthStart + '-' + yearStart;


        $scope.onSearchChange();

    });

    var timer;
    var delay_time = $rootScope.timer_delay;
    var CustomerID = $rootScope.CustomerID;
    var pageno = 1;
    var pagesize = 10;
    var StartDate;
    var EndDate;
    var typeId;

    var datePickerObj1 = {};

    $scope.callDatePicker = function(type_id) {

        typeId = type_id;

        var datePickerObj1 = {
            inputDate: new Date(),
            titleLabel: 'Select a Date',
            setLabel: 'Set',
            todayLabel: 'Today',
            closeLabel: 'Close',
            // mondayFirst: true,
            weeksList: ["S", "M", "T", "W", "T", "F", "S"],
            monthsList: ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"],
            templateType: 'popup',
            from: new Date(2016, 1, 1),
            to: new Date(2018, 1, 1),
            showTodayButton: false,
            dateFormat: 'MMMM dd  yyyy',
            closeOnSelect: false,

            callback: function(val) { //Mandatory
                if (!val) {
                    $cordovaToast
                        .show("Please select the Order Date range !", 'short', 'center')
                        .then(function(success) {

                        }, function(error) {

                        });
                } else {
                    var date = new Date(val);
                    $scope.date = date;
                    var year = date.getFullYear();
                    var month = date.getMonth() + 1;
                    if (month < 10) {
                        month = "0" + month;
                    }
                    var fullDate = date.getDate();
                    if (fullDate < 10) {
                        fullDate = "0" + fullDate;
                    }

                    $scope.datepicker = year + '-' + month + '-' + fullDate;
                    $scope.datepickerShow = fullDate + '-' + month + '-' + year;

                    if (typeId == 1) {

                        $scope.data.start = $scope.datepicker;
                        $scope.data.startShow = $scope.datepickerShow;
                    } else {

                        $scope.data.end = $scope.datepicker;
                        $scope.data.endShow = $scope.datepickerShow;
                        $scope.data.orders = [];
                        $scope.onSearchChange();
                    }

                }
            }
        };

        ionicDatePicker.openDatePicker(datePickerObj1);
    };



    $scope.cancelOrder = function(_id) {

    };

    function getOrderHistory(pageNumber) {
        apiTimeout();
        $scope.noitem = false;

        GetCustomerOrders.GetCustomerOrders(CustomerID, StartDate, EndDate, pageNumber, pagesize).then(function(response) {

            $ionicLoading.hide();
            var result = JSON.parse(response);
            console.log(result);

            clearTimeout(timer);
            if (result.ErrorID == 0) {
                $scope.data.orderCount = result.OrderCount;
                // clearTimeout(timer);
                if ($scope.data.orders === undefined) {
                    $ionicLoading.hide();
                    $scope.data.orders = result.CustomerOrder;
                } else {
                    $ionicLoading.hide();
                    $.merge($scope.data.orders, result.CustomerOrder);
                }
                busyInLoading = false;
                if ($scope.data.orders.length == 0) {
                    $ionicLoading.hide();
                    $scope.noitem = true;
                };
            } else {
                $ionicLoading.hide();
            }

        }, function(err) {
            console.log(err);
            clearTimeout(timer);
            $ionicLoading.hide();
            var confirmPopup = $ionicPopup.confirm({
                template: 'Something went wrong!',
                cssClass: 'popup_head_cust',
                scope: $scope,
                buttons: [{
                    text: 'Try Again!!',
                    onTap: function(e) {
                        $state.go($state.current, {}, { reload: true });
                    }
                }]
            });

        });
    };
    $scope.newdate = [];
    $scope.date_convert = function(item, index) {
        var orderdate = item.OrderDate;
        var converted_date = parseInt(orderdate.substring(orderdate.lastIndexOf("(") + 1, orderdate.lastIndexOf(")")));
        $scope.newdate[index] = $filter('date')(new Date(converted_date), 'yyyy-MM-dd');
    };
    $scope.onSearchChange = function(data, item) {

        $scope.selectMessege = false;
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if ($scope.data.start == '' || $scope.data.start == undefined) {
            $cordovaToast.showLongBottom("Please enter StartDate");
        } else if ($scope.data.end == '' || $scope.data.end == undefined) {
            $cordovaToast.showLongBottom("Please EndDate");

        } else if ($scope.data.start > $scope.data.end) {
            $cordovaToast.showLongBottom("Start date must be less than end date");
        } else {
            StartDate = $scope.data.start + "T" + "00:00:00";
            EndDate = $scope.data.end + "T" + "00:00:00";

            $ionicLoading.show({
                noBackdrop: false,
                template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
            });

            getOrderHistory(1);
        }
    };

    /* Infinite Scroll */
    var busyInLoading = false;
    $scope.loadMore = function() {
        if ($cordovaNetwork.isOffline()) {
            $scope.loaderimage = false;
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            if (!busyInLoading) {
                busyInLoading = true;

                if ((parseInt(pageno) * pagesize) < $scope.data.orderCount) {
                    pageno = parseInt(pageno) + 1;
                    $scope.loaderimage = true;
                    getOrderHistory(pageno);
                } else {
                    $scope.loaderimage = false;
                    if ($scope.data.cakeCount != undefined)
                        $scope.loaderimage = false;
                }
            }
            $scope.$broadcast('scroll.infiniteScrollComplete');
        }
    };

    $scope.show_details = function(id) {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.orderdetails", { 'id': id });
        }
    };

    $ionicModal.fromTemplateUrl('my-cancelModal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modal = modal;
    });

    $scope.closeModal = function() {
        $scope.modal.hide();
    };

    $scope.cancelOrder = function(_id) {
        $scope.cancelOrderId = _id;
        var confirmPopup = $ionicPopup.confirm({
            title: 'Cancel Order',
            template: 'Are you sure you want to cancel order?',
            scope: $scope,
            buttons: [
                { text: 'No' }, {
                    text: 'Yes',
                    onTap: function(e) {
                        GetOrderCancelReasonList.GetOrderCancelReasonList().then(function(response) {
                            $scope.cancelReason = JSON.parse(response);
                            $scope.data.reason = undefined;
                            $scope.modal.show();

                        });
                    }
                }
            ]
        });
    };

    $scope.chooseReason = function(reason) {
        $scope.cancel_reason = reason;
    };

    $scope.cancelYourOrder = function() {

        if (internetcheck) {
            if ($scope.cancel_reason == undefined) {
                $cordovaToast.showLongBottom('Please select reason');
            } else if ($scope.data.reason == undefined || $scope.data.reason == "" || $scope.data.reason == null) {
                $cordovaToast.showLongBottom('Please write description');
            } else {
                $ionicLoading.show({
                    noBackdrop: false,
                    template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                });
                CancelOrder.CancelOrder($scope.cancelOrderId, $scope.cancel_reason, $scope.data.reason).then(function(response) {
                    $ionicLoading.hide();

                    var resObj = JSON.parse(response);
                    if (resObj.ErrorID == 0) {
                        $cordovaToast.showLongCenter("Your order has been cancelled");
                        $scope.data.orders = [];
                        getOrderHistory(1);
                        $scope.modal.hide();
                    }

                }, function(err) {
                    console.log(err);
                    clearTimeout(timer);
                    $ionicLoading.hide();
                    var confirmPopup = $ionicPopup.confirm({
                        template: 'Something went wrong!',
                        cssClass: 'popup_head_cust',
                        scope: $scope,
                        buttons: [{
                            text: 'Try Again!!',
                            onTap: function(e) {
                                $state.go($state.current, {}, { reload: true });
                            }
                        }]
                    });

                });
            }
        }
    };

    function internetcheck() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
            return false;
        } else {
            return true;
        }
    }

    function apiTimeout() {
        clearTimeout(timer);
        timer = setTimeout(function() {
            $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
            $ionicLoading.hide();
        }, delay_time);
    };
});
