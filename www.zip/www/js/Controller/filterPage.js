app.controller('FilterCtrl', function($scope, $state, $stateParams, $timeout, WebService, $rootScope, $interval, $location, $cordovaNetwork, $cordovaToast, $ionicPlatform, $window, $localStorage, $ionicPopup, $ionicSideMenuDelegate, $ionicLoading, LocalStorage, getbakerylist_bypostcode, $cordovaToast, bakerylist_filterList) {


    $ionicPlatform.registerBackButtonAction(function(event) {
        $scope.myGoBack();
    }, 100);

    var timer;
    var delay_time = $rootScope.timer_delay;
    var minPor, maxPor;
    var minPri, maxPri;
    $ionicSideMenuDelegate.canDragContent(false);
    $ionicLoading.show({
        noBackdrop: false,
        template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
    });

    $scope.$on("$ionicView.enter", function(event, data) {
        $scope.backery_ids = [];
        if (data.fromCache == false) {
            oldKey = "";
            while (api_callinginfo.length != 0) {
                api_callinginfo.pop();
            }
            var node = document.getElementById("main-container");
            while (node.firstChild) {
                node.removeChild(node.firstChild);
            }
            if ($localStorage.filterOption == undefined) {
                loadFilterContent();
            } else {

                $scope.filterOptions = $localStorage.filterOption;
                var result = $.grep($scope.filterOptions, function(e) {
                    return e.key == "Occsasion";
                });
                showOptions(result[0].key, result[0].data, result[0].divid);
                divid = result[0].divid;
                selectedDiv = divid;

                setTimeout(function() {
                    $('#' + selectedDiv).addClass('selected');
                    $("#div_" + selectedDiv).css({
                        'display': 'block',
                    });
                    addPrefetchedFilter();
                }, 500);
                $ionicLoading.hide();
            }
        }

        if ($rootScope.BakeryidObject instanceof Array) {
            $scope.backery_list = $rootScope.BakeryidObject;
            for (i = 0; i < $scope.backery_list.length; i++) {
                $scope.backery_ids.push($scope.backery_list[i].webstore_ID);
                console.log($scope.backery_ids);
                $scope.backery_ids.toString();
                console.log($scope.backery_ids.toString());
            }
        } else {
            if ($rootScope.BakeryidObject != null) {
                $scope.backery_ids = $rootScope.BakeryidObject.webstore_ID;
            }
        }
        console.log($scope.backery_ids);
        console.log($scope.backery_list);
        //$scope.clearall();
        if (selectedDiv != '') {
            $('#' + selectedDiv).addClass('selected');
        } else {
            $('#Occsasion').addClass('selected');
        }
        //if (data.fromCache != true) {

        //$ionicLoading.hide();
        //}
    });

    $scope.$on("$ionicView.afterenter", function(event, data) {
        $ionicLoading.hide();
    });

    $scope.myGoBack = function() {
        // $state.go("app.searchbusiness");
        window.history.back();
        $rootScope.isBack = true;
    };

    if (event.originalEvent !== undefined && _.touchObject.swipeLength > 4) {
        event.preventDefault();
    }
    var cakePriceMinRange = 17,
        cakePriceMaxRange = 675,
        CakePortionMin = 5,
        CakePortionMax = 450;

    $scope.count;
    // window.plugins.spinnerDialog.show(null, null, true);    
    var api_callinginfo = [];
    var oldKey = "";

    $('#content').css({
        'height': window.innerHeight
    });

    $scope.keyvalue = function(key, data, div_id) {
        console.log(key + " " + div_id);
        showOptions(key, data, div_id);
    }

    function showOptions(key, data, div_id) {
        // $("#badge_" + "Delivery").show();
        // $("#badge_" + "Occsasion").show();
        // $("#badge_" + "CakePortion").show();

        if (oldKey.length != 0) {
            $("#div_" + oldKey).css({
                'display': 'none',
            });
            $('#' + oldKey).removeClass('selected');



            if (oldKey == 'CakePortion') {
                if (CakePortionMin != minPor || CakePortionMax != maxPor) {
                    $("#badge_" + oldKey).show();
                }
                // $('#' + oldKey).addClass('selected_price_portion');
            } else if (oldKey == 'CakePriceRange') {
                if (cakePriceMinRange != minPri || cakePriceMaxRange != maxPri) {
                    $("#badge_" + oldKey).show();
                }
            } else {
                var count = $("#div_" + oldKey + " input:checked").map(function(i, el) {
                    return el.id.split('_')[1];
                }).length;

                if (count != 0) {
                    $("#badge_" + oldKey).css({
                        'display': 'inline'
                    });
                    //  $("#badge_" + oldKey)[0].innerHTML = count;
                    $("#badge_" + oldKey).show();
                } else {
                    $("#badge_" + oldKey).css({
                        'display': 'none'
                    });
                }
            }

        }

        if (document.getElementById('div_' + div_id) == null) {
            $('<div/>', {
                id: 'div_' + div_id,
            }).appendTo('#main-container');

            $.each(data, function(i, val) {
                if (key == 'CakePortion') {

                    CakePortionMin = minPor = parseInt(val.minportion);
                    CakePortionMax = maxPor = parseInt(val.maxportion);

                    $("#div_" + div_id).append('<div class="checkbox-container" ><p> <label for="amount"></label> <input type="text" id="amount" readonly style="padding:0 0 10px 7px;border:0; color:#e03133;background: #fff; font-weight:bold;"></p> <div id="slider-range" style="margin: 0px 15px;"></div></div>');

                    if ($localStorage.filterChoose != undefined) {
                        CakePortionMin = $localStorage.filterChoose.minportion;
                        CakePortionMax = $localStorage.filterChoose.maxportion;

                    }

                    $("#slider-range").slider({
                        range: true,
                        min: parseInt(val.minportion),
                        max: parseInt(val.maxportion),
                        values: [parseInt(CakePortionMin), parseInt(CakePortionMax)],
                        slide: function(event, ui) {
                            CakePortionMin = ui.values[0];
                            CakePortionMax = ui.values[1];
                            $("#amount").val(" " + ui.values[0] + " - " + ui.values[1]);
                            // $('#' + div_id).addClass('selected_price_portion');
                            $("#badge_" + div_id).show();
                            //$('.test:nth-child()')
                        }
                    });

                    $("#amount").val($("#slider-range").slider("values", 0) +
                        "  -  " + $("#slider-range").slider("values", 1));

                } else if (key == 'CakePriceRange') {
                    //$("#div_" + key).append('<div class="checkbox-container" >Min :' + val.minprice + ',Max : ' + val.maxprice + '</div>');

                    cakePriceMinRange = minPri = parseInt(val.minprice);
                    cakePriceMaxRange = maxPri = parseInt(val.maxprice);

                    $("#div_" + div_id).append('<div class="checkbox-container" ><p> <label for="amount-price"></label> <input type="text" id="amount-price" readonly style="padding:0 0 10px 9px;border:0;background: #fff;color:#e03133;font-weight:bold;"></p> <div id="slider-range-price" style="margin: 0px 15px;"></div></div>');


                    if ($localStorage.filterChoose != undefined) {
                        cakePriceMinRange = minPri = $localStorage.filterChoose.minprice;
                        cakePriceMaxRange = maxPri = $localStorage.filterChoose.maxprice;

                    }

                    $("#slider-range-price").slider({
                        range: true,
                        min: parseInt(val.minprice),
                        max: parseInt(val.maxprice),
                        values: [parseInt(minPri), parseInt(maxPri)],
                        slide: function(event, ui) {
                            cakePriceMinRange = ui.values[0];
                            cakePriceMaxRange = ui.values[1];

                            console.log(ui.values[1]);
                            // $('#' + div_id).addClass('selected_price_portion');
                            $("#badge_" + div_id).show();
                            $("#amount-price").val("£" + ui.values[0] + " - £" + ui.values[1]);
                        }
                    });

                    $("#amount-price").val("£" + $("#slider-range-price").slider("values", 0) +
                        " - £" + $("#slider-range-price").slider("values", 1));


                } else {
                    $("#div_" + div_id).append('<label for="' + div_id + '_' + val.id + '"><div class="checkbox-container">' +
                        '<input type="checkbox" class="coloredCheckbox" id="' + div_id + '_' + val.id + '">' +
                        '<span></span><span class="span-checkbox">' + val.title + '</span></div></label><hr class="checkbox-divider">');

                    // Make selected options
                    if ($localStorage.filterChoose != null || $localStorage.filterChoose != undefined)
                        makeCheckboxSelected(div_id, val.id);

                }
            });
            if (div_id == "Occsasion") {
                $("#div_" + div_id).css({
                    'display': 'block',
                    'background': 'white'
                });
            }
            oldKey = div_id;
        } else {
            $("#div_" + div_id).css({
                'display': 'block',
                'background': 'white'
            });
            console.log(oldKey + " -------oldkey");
            oldKey = div_id;
        }


        function readDeviceOrientation() {

            if (Math.abs(window.orientation) === 90) {
                // Landscape
                $('#div_' + div_id).css({
                    'height': (parseInt(window.innerWidth) - 130) + 'px',
                    // 'top': '50px',
                    'overflow-y': 'auto',
                });
            } else {
                // Portrait
                // $state.reload();
                $('#div_' + div_id).css({
                    'height': (parseInt(window.innerHeight) + 150) + 'px',
                    // 'top': '50px',
                    'overflow-y': 'auto',
                });
            }
        }

        window.onload = readDeviceOrientation;
        window.onorientationchange = readDeviceOrientation;


        selectedDiv = div_id;
        $('#' + div_id).addClass('selected');


        if (api_callinginfo[key] == null)
            api_callinginfo[key] = key;

    }

    function addPrefetchedFilter() {
        if ($localStorage.filterChoose != undefined) {
            var count = 0;
            var selctedKey;
            selctedKey = "Ocassion";
            if ($localStorage.filterChoose.ocassionids != "") {
                count = $localStorage.filterChoose.ocassionids.split(',').length;
            }
            showBadge(count, selctedKey);
            count = 0;
            if ($localStorage.filterChoose.deliveryids != "") {
                count = $localStorage.filterChoose.deliveryids.split(',').length;
            }
            selctedKey = "Delivery";
            showBadge(count, selctedKey);
            count = 0;
            if ($localStorage.filterChoose.Caketypeids != "") {
                count = $localStorage.filterChoose.Caketypeids.split(',').length;
            }
            selctedKey = "CakeType";
            showBadge(count, selctedKey);
            count = 0;
            if ($localStorage.filterChoose.CakeShapeids != "") {
                count = $localStorage.filterChoose.CakeShapeids.split(',').length;
            }
            selctedKey = "CakeShape";
            showBadge(count, selctedKey);

            if ($localStorage.filterChoose.minportion != CakePortionMin || $localStorage.filterChoose.maxportion != CakePortionMax) {
                selctedKey = "CakePortion";
                showBadge(null, selctedKey);
            }
            if ($localStorage.filterChoose.minprice != cakePriceMinRange || $localStorage.filterChoose.maxprice != cakePriceMaxRange) {
                selctedKey = "CakePriceRange";
                showBadge(null, selctedKey);
            }

        }
    }

    function showBadge(count, selctedKey) {
        if (selctedKey == 'CakePortion') {
            if (CakePortionMin != minPor || CakePortionMax != maxPor) {
                $("#badge_" + selctedKey).show();
            }
            // $('#' + oldKey).addClass('selected_price_portion');
        } else if (selctedKey == 'CakePriceRange') {
            if (cakePriceMinRange != minPri || cakePriceMaxRange != maxPri) {
                $("#badge_" + selctedKey).show();
            }
        } else if (count != 0) {
            $("#badge_" + selctedKey).css({
                'display': 'inline'
            });
            //$("#badge_" + selctedKey).text(count);
            $("#badge_" + selctedKey).show();
        }

        // if (count == null) {
        //     $("#badge_" + selctedKey).show();
        //     //$('#' + selctedKey).addClass('selected_price_portion');
        //     //$("#badge_" + selctedKey).hide();
        // }
    }

    function makeCheckboxSelected(key, checkboxID) {
        //var filterOptionPreSelected = $localStorage.filterChoose;
        switch (key.toLowerCase()) {
            case "ocassion":
            case "occsasion":
                var result = $.grep($localStorage.filterChoose.ocassionids.split(','), function(e) {
                    return e == checkboxID;
                });
                if (result.length > 0) {
                    $('#' + key + "_" + checkboxID).prop("checked", true);
                }
                break;
            case "delivery":
                var result = $.grep($localStorage.filterChoose.deliveryids.split(','), function(e) {
                    return e == checkboxID;
                });
                if (result.length > 0) {
                    $('#' + key + "_" + checkboxID).prop("checked", true);
                }
                break;
            case "caketype":
                var result = $.grep($localStorage.filterChoose.Caketypeids.split(','), function(e) {
                    return e == checkboxID;
                });
                if (result.length > 0) {
                    $('#' + key + "_" + checkboxID).prop("checked", true);
                }
                break;
            case "cakeshape":
                var result = $.grep($localStorage.filterChoose.CakeShapeids.split(','), function(e) {
                    return e == checkboxID;
                });
                if (result.length > 0) {
                    $('#' + key + "_" + checkboxID).prop("checked", true);
                }
                break;


        }
    }

    $scope.filterOptions = [];
    var bakerylist_filterListResult = '';
    var selectedDiv = '';

    function loadFilterContent() {
        apiTimeout();
        bakerylist_filterList.bakerylist_filterList($rootScope.postcode, $rootScope.selectedvalue).then(function(response) {
            clearTimeout(timer);
            var jsondata = JSON.parse(response);
            //$rootScope.filterdata = jsondata.data;
            while ($scope.filterOptions.length > 0) {
                $scope.filterOptions.pop();
            }
            var i = 0;
            if (jsondata.Filter) {
                for (var key in jsondata.Filter) {
                    if (key.toLowerCase() != "cakesize") {
                        var divid = key.trim(' ').replace(/ /g, '-');
                        var obj = { 'key': key, 'data': jsondata.Filter[key], 'divid': divid };
                        if (i == 0) {
                            showOptions(key, jsondata.Filter[key], divid);
                            selectedDiv = divid;
                            $('#' + divid).addClass('selected');
                        }
                        if (key === "CakePortion") {
                            if (CakePortionMin == -1) {
                                CakePortionMin = parseInt(jsondata.Filter[key][0].minportion);
                            }
                            if (CakePortionMax == -1) {
                                CakePortionMax = parseInt(jsondata.Filter[key][0].maxportion);
                            }
                        }
                        if (key === "CakePriceRange") {
                            if (cakePriceMinRange == -1) {
                                cakePriceMinRange = parseInt(jsondata.Filter[key][0].minprice);
                            }
                            if (cakePriceMaxRange == -1) {
                                cakePriceMaxRange = parseInt(jsondata.Filter[key][0].maxprice);
                            }
                        }
                        i++;
                        $scope.filterOptions.push(obj);
                        console.log($scope.filterOptions);
                    }
                }
                $localStorage.filterOption = $scope.filterOptions;
                $ionicLoading.hide();
                setTimeout(function() {
                    $('#' + selectedDiv).addClass('selected');
                    $("#div_" + selectedDiv).css({
                        'display': 'block',
                    });
                }, 500);
            }
        }, function(err) {
            console.log(err);
            clearTimeout(timer);
            $ionicLoading.hide();
            var confirmPopup = $ionicPopup.confirm({
                template: 'Something went wrong!',
                cssClass: 'popup_head_cust',
                scope: $scope,
                buttons: [{
                    text: 'Try Again!!',
                    onTap: function(e) {
                        $state.go($state.current, {}, { reload: true });
                    }
                }]
            });

        });
    }

    $scope.applyfilter = function() {
        if ($cordovaNetwork.isOnline()) {
            var pageno = 1;
            var pagesize = 10;
            var searchmiles = $rootScope.selectedvalue;
            //$rootScope.selectedvalue
            console.log(searchmiles);
            var searchpostcode = $rootScope.postcode;
            //$rootScope.postcode
            console.log(searchpostcode);
            var bakeryids = $scope.backery_ids.toString();
            console.log(bakeryids);
            var ocassion = '';
            var delivery = '';
            var Caketype = '';
            var CakeShape = '';
            var CakeSize = '';
            var minportion = CakePortionMin;
            var maxportion = CakePortionMax;
            var minprice = cakePriceMinRange;
            var maxprice = cakePriceMaxRange;
            var CakePortion;
            var CakePriceRange;

            for (var i in api_callinginfo) {
                console.log(i + '_' + api_callinginfo[i]);
                var divid = api_callinginfo[i].replace(/ /g, '-');
                var selected = $("#div_" + divid + " input:checked").map(function(i, el) {
                    console.log(selected);
                    return el.id.split('_')[1];
                }).get();
                console.log(selected + " selected " + api_callinginfo[i].toLowerCase());
                switch (api_callinginfo[i].toLowerCase()) {
                    case "ocassion":
                        ocassion = selected.join(',');
                        break;
                    case "occsasion":
                        ocassion = selected.join(',');
                        break;
                    case "delivery":
                        delivery = selected.join(',');
                        break;
                    case "caketype":
                        Caketype = selected.join(',');
                        break;
                    case "cakeshape":
                        CakeShape = selected.join(',');
                        break;
                    case "cakesize":
                        CakeSize = selected.join(',');
                        break;
                    case "cakeportion":
                        CakePortion = selected.join(',');
                        break;
                    case "cakepricerange":
                        CakePriceRange = selected.join(',');
                        break;
                }
            }
            var filterOptionsValue = {
                "pageno": pageno,
                "pagesize": pagesize,
                "searchmiles": searchmiles,
                "searchpostcode": searchpostcode,
                "bakeryids": bakeryids,
                "ocassionids": ocassion,
                "deliveryids": delivery,
                "Caketypeids": Caketype,
                "CakeShapeids": CakeShape,
                "CakeSizeids": CakeSize,
                "minportion": CakePortionMin,
                "maxportion": CakePortionMax,
                "minprice": cakePriceMinRange,
                "maxprice": cakePriceMaxRange,
                "sortcode": $rootScope.sortcode
            };
            console.log(filterOptionsValue);
            $localStorage.filterChoose = filterOptionsValue;
            $state.go("app.backerydetailbyfilter", { 'filter_object': filterOptionsValue });

        } else {
            $cordovaToast.showLongCenter("No internet connection!");
        }
    }

    $scope.clearall = function() {
        $localStorage.filterChoose = undefined;

        console.log(api_callinginfo);

        for (var i in api_callinginfo) {
            var divid = api_callinginfo[i].replace(/ /g, '-');
            $("#div_" + divid).find('input[type=checkbox]:checked').removeAttr('checked');
            //$("#badge_" + divid).hide();

            $("#badge_" + divid).css({
                'display': 'none'
            });

            if (divid == 'CakePortion') {
                CakePortionMin = minPor;
                CakePortionMax = maxPor;
                $("#slider-range").slider({
                    range: true,
                    values: [parseInt(CakePortionMin), parseInt(CakePortionMax)],
                });
                $("#badge_" + divid).hide();
                // $('#' + divid).removeClass('selected_price_portion');
            }

            if (divid == 'CakePriceRange') {
                cakePriceMinRange = minPri;
                cakePriceMaxRange = maxPri;
                $("#slider-range-price").slider({
                    range: true,
                    values: [parseInt(cakePriceMinRange), parseInt(cakePriceMaxRange)],
                });
                $("#badge_" + divid).hide();
                //$('#' + divid).removeClass('selected_price_portion');
            }

        }
    }

    function apiTimeout() {
        clearTimeout(timer);
        timer = setTimeout(function() {
            $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
            $ionicLoading.hide();
        }, delay_time);
    };
});
