app
    .controller(
        'searchCtrl',
        function($scope, LocalStorage, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $location,
            $ionicSideMenuDelegate, LocalStore, $window, $ionicPlatform, $ionicModal,
            $q, $http, $ionicLoading, $ionicModal, $cordovaNetwork, $cordovaToast, getbakerylist_bypostcode) {
            $scope.noitem = false;
            $scope.search = '';

            $scope.list = [];
            var pagesize = 10;
            var pageno = 1;
            var radio_click;
            var radio_clicked;
            var selectedvalue = $rootScope.selectedvalue;
            var postcode = $rootScope.postcode;
            // var searchkeyword;
            var arraylenght;

            var timer;
            var delay_time = $rootScope.timer_delay;
            console.log(delay_time);

            //change
            $scope.myGoBack = function() {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    $state.go("app.allproducts");
                }
            }


            $scope.search_click = function(search) {

                console.log(search);
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else if (search == '' || search == undefined) {

                    $cordovaToast.showLongBottom('Please Enter search keywords');
                } else {
                    var searchkeyword = search;

                    $scope.data = search;
                    console.log($scope.data);
                    window.plugins.spinnerDialog.show(null, null, true);
                    timer = setTimeout(alertfun, delay_time);

                    function alertfun() {
                        $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
                        window.plugins.spinnerDialog.hide();

                    }

                    getbakerylist_bypostcode.getbakerylist_bypostcode(pageno, pagesize, selectedvalue, postcode, searchkeyword)
                        .then(function(response) {
                            clearTimeout(timer);

                            // window.plugins.spinnerDialog.show(null, null, true);
                            var jsondata = JSON.parse("{" + response + "}");
                            lentharray = jsondata.data.Bakery.length;
                            console.log(jsondata);
                            window.plugins.spinnerDialog.hide();
                            if (jsondata.data.Bakery.length == 0) {
                                $scope.noitem = true;

                            } else {
                                $scope.noitem = false;

                                for (var i = 0; i < jsondata.data.Bakery.length; i++) {
                                    console.log(jsondata.data.Bakery[i].ratingpoint);


                                    console.log(jsondata.data.Bakery[i].IsCollectable);
                                    console.log(jsondata.data.Bakery[i].IsDeliverable);



                                    var collectiveclass = '';
                                    var deliverclass = '';
                                    console.log(jsondata.data.Bakery[i].IsCollectable);
                                    if (jsondata.data.Bakery[i].IsCollectable == "1") {


                                        collectiveclass = "icon icon-collection collection-red";

                                    } else {

                                        collectiveclass = "icon icon-collection collection-black";
                                    }



                                    if (jsondata.data.Bakery[i].IsDeliverable == "1") {

                                        deliverclass = "icon icon-delivery delivery-red";

                                    } else {
                                        deliverclass = "icon icon-delivery delivery-black";

                                    }

                                    var starrate_src = "img/icon-star1.png";
                                    if (jsondata.data.Bakery[i].ratingpoint == "1") {
                                        starrate_src = "img/icon-star1.png";
                                    }
                                    if (jsondata.data.Bakery[i].ratingpoint == "2") {
                                        starrate_src = "img/icon-star2.png";

                                    }
                                    if (jsondata.data.Bakery[i].ratingpoint == "3") {
                                        starrate_src = "img/icon-star3.png";
                                    }
                                    if (jsondata.data.Bakery[i].ratingpoint == "4") {
                                        starrate_src = "img/icon-star4.png";

                                    }
                                    if (jsondata.data.Bakery[i].ratingpoint == "5") {
                                        starrate_src = "img/icon-star5.png";

                                    }

                                    jsondata.data.Bakery[i].collectiveclass = collectiveclass;
                                    jsondata.data.Bakery[i].deliverclass = deliverclass;
                                    jsondata.data.Bakery[i].star = starrate_src;
                                    $scope.list.push(jsondata.data.Bakery[i]);
                                    $scope.numberOfItemsToDisplay = jsondata.data.TotalRows;
                                }
                            }
                        });



                }
            }



            // dropdown allcategory
            $scope.dropdown = function(e) {
                $('#dropdown-allcategory').toggle();
                $('#dropdown-miles').hide();
                $('.body').toggleClass('overlay');
            }
            $('.radio-items').on('click', function(event) {
                setTimeout(function() {
                    $('#dropdown-allcategory').hide();
                    $('.body').toggleClass("overlay");
                    // $('#subText-cat')[0].innerHTML = event.target.value;
                    // console.log('alert', event.target.value);
                    $scope.cakes = event.target.value;
                    radio_clicked = event.target.value;
                    console.log(radio_clicked);
                    delete $rootScope.selectedvalue;
                    var selectedvalue = '';
                    selectedvalue = radio_clicked;
                    console.log(selectedvalue);
                    var searchkeyword = $scope.data;
                    $scope.list = [];
                    timer = setTimeout(alertfun, delay_time);

                    function alertfun() {
                        $cordovaToast.showLongBottom('Respone is taking long time Please check Intenet Connectivity');
                        window.plugins.spinnerDialog.hide();

                    }

                    getbakerylist_bypostcode.getbakerylist_bypostcode(pageno, pagesize, selectedvalue, postcode, searchkeyword)
                        .then(function(response) {
                            window.plugins.spinnerDialog.show(null, null, true);

                            var jsondata = JSON.parse("{" + response + "}");
                            clearTimeout(timer);
                            lentharray = jsondata.data.Bakery.length;
                            console.log(jsondata);
                            window.plugins.spinnerDialog.hide();
                            for (var i = 0; i < jsondata.data.Bakery.length; i++) {
                                console.log(jsondata.data.Bakery[i].ratingpoint);


                                console.log(jsondata.data.Bakery[i].IsCollectable);
                                console.log(jsondata.data.Bakery[i].IsDeliverable);



                                var collectiveclass = '';
                                var deliverclass = '';
                                console.log(jsondata.data.Bakery[i].IsCollectable);
                                if (jsondata.data.Bakery[i].IsCollectable == "1") {


                                    collectiveclass = "icon icon-collection collection-red";

                                } else {

                                    collectiveclass = "icon icon-collection collection-black";
                                }
                                if (jsondata.data.Bakery[i].IsDeliverable == "1") {

                                    deliverclass = "icon icon-delivery delivery-red";

                                } else {
                                    deliverclass = "icon icon-delivery delivery-black";

                                }

                                var starrate_src = "img/icon-star1.png";
                                if (jsondata.data.Bakery[i].ratingpoint == "1") {
                                    starrate_src = "img/icon-star1.png";
                                }
                                if (jsondata.data.Bakery[i].ratingpoint == "2") {
                                    starrate_src = "img/icon-star2.png";

                                }
                                if (jsondata.data.Bakery[i].ratingpoint == "3") {
                                    starrate_src = "img/icon-star3.png";
                                }
                                if (jsondata.data.Bakery[i].ratingpoint == "4") {
                                    starrate_src = "img/icon-star4.png";

                                }
                                if (jsondata.data.Bakery[i].ratingpoint == "5") {
                                    starrate_src = "img/icon-star5.png";

                                }

                                jsondata.data.Bakery[i].collectiveclass = collectiveclass;
                                jsondata.data.Bakery[i].deliverclass = deliverclass;
                                jsondata.data.Bakery[i].star = starrate_src;
                                $scope.list.push(jsondata.data.Bakery[i]);
                                $scope.numberOfItemsToDisplay = jsondata.data.TotalRows;
                            }

                        });


                }, 500);
            });
            // end
            // dropdown miles
            $scope.miles = function(e) {
                $('#dropdown-miles').toggle();
                $('#dropdown-allcategory').hide();
                $('#body').toggleClass('overlay');
            }
            $('radio-items').on('click', function(event) {
                setTimeout(function() {
                    $('#dropdown-miles').hide();
                    $('.body').toggleClass("overlay");
                    $('#change_miles')[0].innerHTML = event.target.value;
                    console.log('alert', event.target.value);
                    $scope.miles = event.target.value;
                    radio_click = event.target.value;
                    console.log(radio_click);

                    delete $rootScope.selectedvalue;
                    var selectedvalue = '';
                    selectedvalue = event.target.value;
                    console.log(selectedvalue);
                }, 500);
            });
            // end

            $scope.clearSearch = function() {

                $scope.search = '';

            };


        });
