app.controller(
    'searchlistCtrl',
    function($scope, $cordovaNetwork, $ionicPopup, $stateParams, $state, $timeout, $ionicHistory, WebService, $rootScope, $location, $localStorage, $ionicPopover,
        $ionicSideMenuDelegate, $window, $q, $http, $ionicLoading, $cordovaToast, $ionicModal, $ionicPlatform, GetBakeriesAndCakesBypostcodeAndMiles, $ionicSideMenuDelegate, $cacheFactory,
        GetCakesByPostcodeAndMiles, GetCategories, $ionicPopup, LocalStorage) {

        console.log($localStorage.milesvalue);
        var backbutton = 0;
        var regPostcode = /^([a-zA-Z]){1}([0-9][0-9]|[0-9]|[a-zA-Z][0-9][a-zA-Z]|[a-zA-Z][0-9][0-9]|[a-zA-Z][0-9]){1}([ ])|([0-9][a-zA-z][a-zA-z]){1}$/;
        $ionicPlatform.registerBackButtonAction(function(event) {
            if (backbutton == 0) {
                backbutton++;
                window.plugins.toast.showShortCenter('Press again to exit');
            } else {
                navigator.app.exitApp();
            }
        }, 100);
        $scope.personal_cakes = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $state.go('app.customer_requrments');
            }
        }

        //change
        $scope.myGoBack = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $state.go('app.home');
            }
        };

        $scope.itemfound = true;

        $scope.searchmiles = [];
        $scope.selected = '';
        $ionicSideMenuDelegate.canDragContent(false);
        var selectedMiles = '';
        $scope.itemNotFound = false;
        $scope.search_miles = $rootScope.miles;
        $scope.visualCategories = [];
        $scope.show_cat = true;
        $scope.titlepostcode = true;
        $scope.editbtn = true;
        $scope.searchoption = false;
        $scope.noMoreItemsAvailable = false;
        $scope.visualCategories = [];
        $scope.updateStatus = false;
        var bakery_pagesize = 10;
        var bakery_pageno = 1;

        const bakery_cachekey = "cache_businessbakery";
        const cakes_cachekey = "cache_businesscakes";
        const cakescount_cachekey = "cache_businesscakescount";
        const cakespage_cachekey = "cache_businesscakespage";
        const miles_cachekey = "cache_miles";
        const postalcode_cachekey = "cache_postalcode";
        const cakecategory_cachekey = "cache_cakecat";
        const cake_all = "cache_all";

        var view = $ionicHistory.currentView();
        $localStorage.stateName = view.stateName;

        // Page no for cakes
        var pageno = 1,
            pagesize = 10;
        var miles = $rootScope.selectedvalue;
        var postalcode = $rootScope.postcode;
        var timer;
        var delay_time = $rootScope.timer_delay;
        $scope.data = {};


        $scope.$on("$ionicView.loaded", function(event, data) {

            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            }

            setTimeout(function() {
                _getCategories();
            }, 200);

            if (data.stateParams.miles !== null || data.stateParams.postalcode !== null) {
                $rootScope.postcode = data.stateParams.postalcode;
                console.log($rootScope.postcode);
                $rootScope.selectedvalue = data.stateParams.miles;
                console.log($rootScope.selectedvalue);
                $scope.data.milesdistance = $rootScope.selectedvalue;
                $rootScope.cake_catIds = "";
                $rootScope.postcode = $localStorage.postcodeSelected;
            }
        });

        $scope.$on("$ionicView.beforeEnter", function(event, data) {
            $rootScope.sortcode = 0;
            $scope.sortCategoryChoose = "Relevance";
            $scope.searchoption = false;
            $rootScope.cake_catIds = "";
            if ($localStorage.milesSelected != undefined) {
                $scope.data.milesdistance = $rootScope.selectedvalue;;
            };
            if ($localStorage.postcodeSelected != undefined) {

                $rootScope.postcode = $localStorage.postcodeSelected;
                $scope.postcode = $rootScope.postcode;
            }
        });

        $scope.$on("$ionicView.enter", function(event, data) {
            $scope.searchoption = false;
            clearTimeout(timer);
        });

        $scope.$on("$ionicView.afterEnter", function(event, data) {

            $scope.loaderimage = true;

            getcount();
            var loadFromAPI = false;
            if (data.fromCache == false) {
                //$rootScope.cake_catIds = "";
                $scope.isHideBakerylist = false;
                loadFromAPI = true;
                $scope.$apply();
            }
            if (loadFromAPI || $localStorage.miles !== $rootScope.selectedvalue || $localStorage.postcode !== $rootScope.postcode) {
                // Avoid to load again in case values are same for previous search
                $localStorage.miles = $rootScope.selectedvalue;
                $rootScope.postcode = $localStorage.postcodeSelected;
                $localStorage.postcode = $rootScope.postcode;
                console.log($localStorage.miles);
                console.log($localStorage.postcode);
                console.log($rootScope.postcode);
                $scope.$watch('online', function(newStatus) {

                    //alert(newStatus);
                    if (newStatus == false) {
                        $scope.loaderimage = false;
                        $cordovaToast.showLongCenter("No internet connection!");
                    }
                    if (newStatus == true) {
                        makingAPICallOnactions($rootScope.postcode, $rootScope.selectedvalue, "", true);
                    }
                });
                // makingAPICallOnactions($rootScope.postcode, $rootScope.selectedvalue, "", true);
            }
        });

        $scope.$on('$ionicView.afterLeave', function() {

        });

        $scope.backerylist = function(backerylist) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $state.go("app.backreydetail", {
                    'bakeryarray': backerylist,
                    'singleClicked': true
                });
            }
        }

        /* API section */
        function _getCategories() {
            //internet connectivity
            // apiTimeout();
            if (internetcheck()) {
                GetCategories.GetCategories().then(function(response) {
                    //  clearTimeout(timer);

                    $rootScope.categories = JSON.parse(response);
                    while ($scope.visualCategories.length > 0) {
                        $scope.visualCategories.pop();
                    }
                    for (var i in $rootScope.categories) {
                        if (i > 2) {
                            break;
                        }
                        $scope.visualCategories.push($rootScope.categories[i]);
                    }
                }, function(err) {
                    console.log(err);
                    clearTimeout(timer);
                    $ionicLoading.hide();
                    var confirmPopup = $ionicPopup.confirm({
                        title: 'Something went wrong!',
                        scope: $scope,
                        buttons: [{
                            text: 'Try Again!!',
                            onTap: function(e) {
                                $state.go($state.current, {}, { reload: true });
                            }
                        }]
                    });

                });
            } else {
                notFound($scope.data.cakeCount == 0 ? true : false);
            }
        }

        function makingAPICallOnactions(param_postalcode, param_miles, param_catId) {
            console.log(param_postalcode);
            console.log(param_miles);
            if ($scope.data.bakerylist != undefined) {
                while ($scope.data.bakerylist.length > 0) {
                    $scope.data.bakerylist.pop();
                }
            }
            if ($scope.data.cakelist != undefined) {
                while ($scope.data.cakelist.length > 0) {
                    $scope.data.cakelist.pop();
                }
            }
            $scope.data.cakeCount = 0;
            $scope.data.bakeryCount = 0;
            pageno = 1;
            //$scope.noMoreItemsAvailable = false;
            $scope.data.milesdistance = miles = param_miles;
            postalcode = param_postalcode;
            hitAPIForDisplay(param_postalcode, param_miles, param_catId, false);
        }

        function hitAPIForDisplay(param_postcode, param_miles, param_catIds, param_callExternal) {
            //if (iscallAPI(param_miles, param_postcode, param_catIds)) {
            $scope.data.milesdistance = miles = param_miles;
            postalcode = param_postcode;

            setTimeout(function() {
                makeAPI_Call(bakery_pageno);
            }, 50);
            setTimeout(function() {
                _getcakes(pageno, pagesize, param_postcode, param_miles, param_catIds);
            }, 200);
        }

        function makeAPI_Call(pageno2load) {
            // clearTimeout(timer);

            if (internetcheck()) {
                // apiTimeout();
                GetBakeriesAndCakesBypostcodeAndMiles.GetBakeriesAndCakesBypostcodeAndMiles(pageno2load, bakery_pagesize,
                    postalcode, miles).then(function(response) {
                    //clearTimeout(timer);
                    var resObject = JSON.parse(response);
                    if (resObject.ErrorID == 0) {
                        $rootScope.BakeryidObject = $scope.data.bakerylist = resObject.Bakeries;
                        $scope.data.bakeryCount = resObject.BakeryCount;
                    } else {
                        // Error from API

                    }
                }, function(err) {
                    console.log(err);
                    clearTimeout(timer);
                    $ionicLoading.hide();
                    var confirmPopup = $ionicPopup.confirm({
                        template: 'Something went wrong!',
                        cssClass: 'popup_head_cust',
                        scope: $scope,
                        buttons: [{
                            text: 'Try Again!!',
                            onTap: function(e) {
                                $state.go($state.current, {}, { reload: true });
                            }
                        }]
                    });

                });
            } else {
                notFound($scope.data.cakeCount == 0 ? true : false);
            }

        }

        function _getcakes(param_pageno, param_cakecount, param_postalcode, param_miles, param_categoryIds) {
            // internet check
            if (internetcheck()) {
                apiTimeout();

                GetCakesByPostcodeAndMiles.GetCakesByPostcodeAndMiles(param_pageno, param_cakecount,
                    param_postalcode, param_miles, param_categoryIds, "", $rootScope.sortcode).then(function(response) {
                    clearTimeout(timer);
                    var responseObject = JSON.parse(response);
                    if (responseObject.ErrorID == 0) {

                        if ($scope.data.cakelist === undefined) {
                            $scope.data.cakelist = responseObject.Cakes;

                        } else {
                            console.log(responseObject.Cakes.length);
                            $.merge($scope.data.cakelist, responseObject.Cakes);
                        }
                        $scope.data.cakeCount = responseObject.CakeCount;
                        busyInLoading = false;
                        clearTimeout(timer);
                        notFound($scope.data.cakeCount == 0 ? true : false);
                    } else {
                        // Error from API
                        notFound($scope.data.cakeCount == 0 ? true : false);
                        $cordovaToast.showLongCenter(responseObject.ErrorMsg);
                    }
                }, function(err) {
                    console.log(err);
                    clearTimeout(timer);
                    $ionicLoading.hide();
                    var confirmPopup = $ionicPopup.confirm({
                        template: 'Something went wrong!',
                        cssClass: 'popup_head_cust',
                        scope: $scope,
                        buttons: [{
                            text: 'Try Again!!',
                            onTap: function(e) {
                                $state.go($state.current, {}, { reload: true });
                            }
                        }]
                    });

                });
            } else {
                notFound($scope.data.cakeCount == 0 ? true : false);
            }
        }

        function notFound(val) {
            $scope.itemNotFound = val;
            $scope.itemfound = !val;
        }

        /* api timeout*/
        function apiTimeout() {
            clearTimeout(timer);
            timer = setTimeout(function() {
                $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
                $ionicLoading.hide();
            }, delay_time);
        }

        /* Infinite Scroll */
        var busyInLoading = false;
        $scope.loadMore = function() {
            if ($cordovaNetwork.isOffline()) {
                $scope.loaderimage = false;
                $cordovaToast.showLongCenter("No internet connection!");
                return;
            } else if ($cordovaNetwork.isOnline()) {
                if (!busyInLoading) {
                    busyInLoading = true;
                    console.log($scope.data.cakeCount);
                    if ((parseInt(pageno) * pagesize) < $scope.data.cakeCount) {
                        pageno = parseInt(pageno) + 1;
                        $scope.loaderimage = true;
                        _getcakes(pageno, pagesize, $rootScope.postcode, $rootScope.selectedvalue, $rootScope.cake_catIds);
                    } else {
                        $scope.loaderimage = false;
                        if ($scope.data.cakeCount != undefined)
                            $scope.loaderimage = false;
                    }
                }
                $scope.$broadcast('scroll.infiniteScrollComplete');
                //$scope.$apply()
                return;
            }

        };
        /* Infinite Scroll End */
        // $scope.cakesClicked = function() {
        //     $scope.isHideBakerylist = true;
        // }

        $scope.businessClick = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if ($scope.updateStatus) {
                $scope.updateStatus = false;
                $state.go("app.filter_detail", {
                    'bakeryarray': $scope.data.bakerylist,
                    'singleClicked': false
                }, { 'cache': true });
            } else {
                var stateName = "app.filter_detail"
                console.log($ionicHistory.backView());
                var backFound = false;
                var historyId = $ionicHistory.currentHistoryId();
                var history = $ionicHistory.viewHistory().histories[historyId];
                for (var i = history.stack.length - 1; i >= 0; i--) {
                    if (history.stack[i].stateName == stateName) {
                        $ionicHistory.backView(history.stack[i]);
                        if (history.stack[i].stateParams.singleClicked == true) {
                            backFound = false;
                        } else {
                            backFound = true;
                            $ionicHistory.goBack();
                        }
                    }
                }
                if (!backFound) {
                    $state.go("app.filter_detail", {
                        'bakeryarray': $scope.data.bakerylist,
                        'singleClicked': false
                    }, { 'cache': true });
                }
            }
        }

        $scope.detailOfProduct = function(cakeID) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                var cakeObjInfo = { 'id': cakeID };
                $state.go("app.cakedetail", { 'cakeid': cakeObjInfo }, { 'cache': true });
            }
        };

        $scope.milesSelected = 0;

        $scope.miles = function(e) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $ionicModal.fromTemplateUrl('milesModal.html', {
                    scope: $scope,
                    animation: 'slide-in-up',
                }).then(function(modal) {
                    $scope.modal = modal;
                    $scope.modal.show();
                });
            }
        };

        $scope.closeModal = function() {
            $scope.modal.hide();
        };

        $scope.checked = function(selected) {
            console.log(selected + " selected ");
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if ($rootScope.selectedvalue === selected) {
                $scope.modal.hide();
            } else {
                $scope.updateStatus = true;
                $rootScope.selectedvalue = selected;
                $scope.modal.hide();
                // $state.go('app.searchbusiness');
                $state.reload();
            }
        };

        //cakes catgory buttin clicks
        $scope.categoryClicked = function(catClickedItem) {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    $rootScope.BakeryidObject = $scope.data.bakerylist;
                    $rootScope.cake_catIds = catClickedItem.CategoryID;
                    $scope.selectedCat = catClickedItem.CategoryName;
                    catClickedItem.bakeryCount = $scope.data.bakerylist.length;

                    $rootScope.stateName = "app.searchbusiness";
                    $state.go('app.allproducts', { 'bakeryinfo': catClickedItem });

                    setTimeout(function() {
                        $state.reload();
                    }, 50);
                }
            }
            //more cakes 

        $scope.removeHanlder = function() {
            $scope.isHideBakerylist = false;
            $scope.show_cat = true;
            $scope.selectedCat = "";
            $rootScope.cake_catIds = "";
            makingAPICallOnactions($rootScope.postcode, $rootScope.selectedvalue, $rootScope.cake_catIds, false);
            $state.reload();
        }

        $scope.handleMoreEvent = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $rootScope.BakeryidObject = $scope.data.bakerylist;
                console.log($scope.data.bakerylist);
                $state.go("app.filter", { 'backery_details': $scope.data.bakerylist });
            }
        };

        //click event of more button
        $scope.more_click = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $rootScope.BakeryidObject = $scope.data.bakerylist;
                console.log($scope.data.bakerylist);
                $state.go("app.filter", { 'backery_details': $scope.data.bakerylist });
            }

        }



        function getcount() {
            if ($rootScope.detail == undefined) {
                $scope.cartnotification = false;
            } else if ($rootScope.detail.length == 0) {
                $scope.cartnotification = true;
                $scope.count = 0;
            } else {
                $scope.cartnotification = true;
                $scope.count = $rootScope.detail.length;
            }
        };

        var isBusyWithRefresh = false;
        $scope.doRefresh = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                if (!isBusyWithRefresh) {
                    isBusyWithRefresh = true;
                    pageno = 1;
                    pagesize = 10;
                    $timeout(function() {
                        makingAPICallOnactions($rootScope.postcode, $rootScope.selectedvalue, $rootScope.cake_catIds);
                        isBusyWithRefresh = false;
                        $scope.$broadcast('scroll.refreshComplete');
                    }, 500);
                }
            }
        };
        /* header handlers and actions */
        $scope.headerEditPostalCode_ClickHandler = function(araecode) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $scope.data.areacode = $rootScope.postcode;
                $scope.editCode = true;
                setTimeout(function() {
                    // $('#code').select();
                    cordova.plugins.Keyboard.show();
                }, 50);
            }
        };

        $scope.headerSearchPostalcode_InputHandler = function(araecode) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if ($rootScope.postcode === $scope.data.areacode) {
                setTimeout(function() {
                    cordova.plugins.Keyboard.close();
                }, 50);
                return;
            } else if (!araecode) {
                $cordovaToast.showLongCenter("Please Enter Area Code");
                return;
            } else if (regPostcode.test(araecode) == false) {
                $cordovaToast.showLongBottom('Please Enter valid Postcode');
                return;
            } else {
                $rootScope.postcode = $scope.data.areacode;
                $localStorage.postcodeSelected = $rootScope.postcode;
                $scope.editCode = false;
                $scope.updateStatus = true;
                setTimeout(function() {
                    cordova.plugins.Keyboard.close();
                }, 50);
                setTimeout(function() {
                    $state.reload();
                }, 200);
            }
        };

        $scope.headerPostalSearch_CloseHandler = function() {

            $scope.editCode = false;
            setTimeout(function() {
                cordova.plugins.Keyboard.close();
            }, 50);
        }

        $scope.headerSearch_ClickHandler = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $state.go("app.searchcriteriapage");
            }
        };

        $scope.headerCart_ClickHandler = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if ($rootScope.detail.length == 0) {
                $cordovaToast.showLongBottom("Cart is empty");
            } else {
                $state.go("app.cart");
            }
        }

        // internet check
        function internetcheck() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
                return false;
            } else {
                return true;
            }
        }

        $scope.popover = $ionicPopover.fromTemplate(template, {
            scope: $scope
        });


        $ionicPopover.fromTemplateUrl('sortby-popover.html', {
            scope: $scope
        }).then(function(popover) {
            $scope.popover = popover;
        });


        $scope.openPopover = function($event) {
            $scope.popover.show($event);
        };

        $scope.closePopover = function() {
            $scope.popover.hide();
        };

        $scope.sortingCakes = function(sortValue, sortName) {
            $rootScope.sortcode = sortValue;
            $scope.sortCategoryChoose = sortName;
            $scope.popover.hide();
            $scope.data.cakelist = [];
            _getcakes(pageno, pagesize, $rootScope.postcode, $rootScope.selectedvalue, $rootScope.cake_catIds);
        };

    });
