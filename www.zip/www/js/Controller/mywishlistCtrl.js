app
    .controller(
        'mywishlistCtrl',
        function($scope, LocalStorage, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $location, $cordovaNetwork,
            $ionicSideMenuDelegate, LocalStore, $window, $ionicPlatform,
            $q, $http, $ionicLoading, $ionicModal, $cordovaNetwork, $cordovaToast) {
            $ionicSideMenuDelegate.canDragContent(false);
            //change
            $scope.myGoBack = function() {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    window.history.back();
                }
            }


        });