app.controller('billingDetailCtrl',

    function($scope, $state, $ionicPlatform, $ionicPopup, $stateParams, $ionicModal, ByPostcode, FetchAddress, $rootScope, $localStorage, $cordovaNetwork, $cordovaToast, AddUpdateCustomerAddress, $ionicSideMenuDelegate,
        $ionicLoading, $timeout) {

        $ionicPlatform.registerBackButtonAction(function(event) {
            $scope.myGoBack();
        }, 100);
        //regax for uk postal code 
        var regPostcode = /^([a-zA-Z]){1}([0-9][0-9]|[0-9]|[a-zA-Z][0-9][a-zA-Z]|[a-zA-Z][0-9][0-9]|[a-zA-Z][0-9]){1}([ ])|([0-9][a-zA-z][a-zA-z]){1}$/;

        $scope.hideLoginButton = false;
        //change
        $scope.login_btn = function(country) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $state.go('app.login');
            }
        };

        var timer;
        var delay_time = $rootScope.timer_delay;
        $scope.data = {};
        $scope.address = [];
        $scope.$on("$ionicView.beforeEnter", function(event, data) {

            var addObj = $state.params.addressObj;
            if ($rootScope.loggedin == true) {
                $scope.hideLoginButton = true;
            }
            if (addObj == null) {
                if ($rootScope.loggedin == true) {
                    deliveryadd_ID = 0;
                    $scope.data.fname = $localStorage.userDetails.First_Name;
                    $scope.data.lstname = $localStorage.userDetails.Last_Name;
                    $scope.data.email = $localStorage.userDetails.Email;
                    $scope.data.postcode = $localStorage.userDetails.Postcode;
                } else {
                    $rootScope.CustomerID = undefined;
                    deliveryadd_ID = 0;
                }
            } else {
                preFillDetails(addObj);
            }
            if ($scope.data.postcode == undefined || $scope.data.postcode == null) {
                $scope.data.postcode = $localStorage.postcodeSelected;
                console.log($localStorage.postcodeSelected);
                $scope.$apply();
            }
        });



        // $scope.$on("$ionicView.afterEnter", function(event, data) {


        // });

        function preFillDetails(addressObj) {
            console.log(addressObj);
            deliveryadd_ID = addressObj.deliveryadd_ID;
            $scope.data.fname = addressObj.deliveryadd_fName;
            $scope.data.lstname = addressObj.deliveryadd_lName;
            $scope.data.email = $localStorage.userDetails.Email;
            $scope.data.postcode = addressObj.deliveryadd_zip;
            $scope.data.mobileno = addressObj.deliveryadd_mobile;
            $scope.data.phoneno = addressObj.deliveryadd_phone;
            $scope.data.county = addressObj.deliveryadd_county;
            $scope.data.city = addressObj.deliveryadd_city;
            $scope.data.address = addressObj.deliveryadd_address;
            $scope.data.check = addressObj.IsDefaultDeliveryAdd;
        }


        $scope.choose = function(country) {
            $scope.data.country = country;
            console.log($scope.data.country);
        };

        $scope.data.country = "United Kingdom";
        $scope.submit = function(data, defaultcheckbox) {

            if (data.check == undefined) {
                data.check = false;
            }
            if (data.fname == '' || data.fname == undefined) {
                $cordovaToast.showLongBottom('Please Enter Firstname');
            } else if (data.lstname == '' || data.lstname == undefined) {
                $cordovaToast.showLongBottom('Please Enter Lastname');
            } else if (data.email == '' || data.email == undefined) {
                $cordovaToast.showLongBottom('Please Enter Email');
            } else if (!(/^([\w]+(?:\.[\w]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/.test(data.email))) {
                $cordovaToast.showLongBottom("Please enter valid Email");
            } else if (!(/^([\w]+(?:\.[\w]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/.test(data.email))) {
                $cordovaToast.showLongBottom("Please enter valid Email");
            } else if (data.postcode == '' || data.postcode == undefined) {
                $cordovaToast.showLongBottom('Please Enter Postcode');
            } else if (regPostcode.test(data.postcode) == false) {
                $cordovaToast.showLongBottom('Please Enter valid Postcode');
            } else if (data.city == '' || data.city == undefined) {
                $cordovaToast.showLongBottom('Please Enter City');
            } else if (data.county == '' || data.county == undefined) {
                $cordovaToast.showLongBottom('Please Enter County');
            } else if ($scope.data.country == '' || $scope.data.country == undefined) {
                $cordovaToast.showLongBottom('Please Enter Country');
            } else if (data.mobileno == '' || data.mobileno == undefined) {
                $cordovaToast.showLongBottom('Please Enter Mobile Number');
            } else if (data.address == '' || data.address == undefined) {
                $cordovaToast.showLongBottom('Plase Enter Address');
            } else {
                $ionicLoading.show({
                    template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                });

                var address = {
                    "deliveryadd_ID": deliveryadd_ID,
                    "deliveryadd_custID": $rootScope.CustomerID,
                    "deliveryadd_fName": data.fname,
                    "deliveryadd_lName": data.lstname,
                    "deliveryadd_Email": data.email,
                    "deliveryadd_address": data.address,
                    "deliveryadd_city": data.city,
                    "deliveryadd_county": data.county,
                    "deliveryadd_country": $scope.data.country,
                    "deliveryadd_zip": data.postcode,
                    "deliveryadd_phone": data.phoneno,
                    "deliveryadd_mobile": data.mobileno,
                    "IsDefaultDeliveryAdd": data.check
                }
                console.log(address);
                if ($rootScope.loggedin == true) {
                    if (internetcheck()) {
                        apiTimeout();
                        AddUpdateCustomerAddress.AddUpdateCustomerAddress(address).then(function(response) {
                            console.log(response);
                            clearTimeout(timer);
                            // for (var i in response) {
                            //     $scope.address.push(response[i]);
                            // }

                            if (response == 1) {
                                if (data.check) {
                                    $rootScope.billingAddress = address;
                                }
                                $ionicLoading.hide();
                                $state.go("app.shippingdetail");
                            } else if (response != 1) {
                                $cordovaToast.showLongBottom('Something went wrong please try again');
                            } else {
                                 $ionicLoading.hide();
                                $cordovaToast.showLongBottom('please check Internet connection');
                            }
                        }, function(err) {
                            console.log(err);
                            clearTimeout(timer);
                            $ionicLoading.hide();
                            var confirmPopup = $ionicPopup.confirm({
                                template: 'Something went wrong!',
                                cssClass: 'popup_head_cust',
                                scope: $scope,
                                buttons: [{
                                    text: 'Try Again!!',
                                    onTap: function(e) {
                                        $state.go($state.current, {}, { reload: true });
                                    }
                                }]
                            });

                        });
                    } else {
                        // No internet interface
                    }
                } else {
                    $rootScope.billingAddress = address;
                    $ionicLoading.hide();
                    $state.go("app.billingaddressconfirm", { 'billAddressObj': $rootScope.billingAddress });
                }
            }
        };
        //chnage
        $scope.myGoBack = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if ($rootScope.loggedin == true) {
                $state.go('app.shippingdetail');
            } else {
                $state.go('app.checkout');
            }

        };
        //change
        $scope.cancel = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                window.history.back();
            }
        }


        $ionicModal.fromTemplateUrl('addressModal.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal) {
            $scope.modal = modal;

        });

        $scope.closeModal = function() {
            $scope.modal.hide();
            $scope.$on('$destroy', function() {
                $scope.modal.remove();
            });
        };


        $scope.getSelAddress = function(description, id) {
            console.log(description);
            console.log(id);
            FetchAddress.FetchAddress(id, "enLanguageEnglish", "enContentStandardAddress", "CAKER11111", "WC17-AC14-ZR77-UW79", 123456).then(function(response) {
                console.log(response);
                if (response.ErrorNumber == 0) {
                    if (response.Results[0].Line1 != null) {
                        $scope.data.address = response.Results[0].Line1;
                    }
                    if (response.Results[0].Line2 != null) {
                        $scope.data.address = $scope.data.address + response.Results[0].Line2;
                    }
                    if (response.Results[0].Line3 != null) {
                        $scope.data.address = $scope.data.address + response.Results[0].Line3;
                    }
                    if (response.Results[0].Line4 != null) {
                        $scope.data.address = $scope.data.address + response.Results[0].Line4;
                    }
                    if (response.Results[0].Line5 != null) {
                        $scope.data.address = $scope.data.address + response.Results[0].Line5;
                    }
                    if (response.Results[0].County != null) {
                        $scope.data.county = response.Results[0].County;
                    }
                    if (response.Results[0].PostTown != null) {
                        $scope.data.city = response.Results[0].PostTown;
                    }

                    $scope.modal.hide();
                    $scope.$on('$destroy', function() {
                        $scope.modal.remove();
                    });
                }

            });

        };


        $scope.getAddress = function() {
            if($cordovaNetwork.isOffline()) {
                 $ionicLoading.hide();
                $cordovaToast.showLongCenter("No internet connection!");
            }
            else{
            $ionicLoading.show({
                noBackdrop: false,
                template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
            });

            apiTimeout();
            ByPostcode.ByPostcode($scope.data.postcode, "CAKER11111", "WC17-AC14-ZR77-UW79", 123456).then(function(response) {
                clearTimeout(timer);
                for (var i in response.Results) {
                    $scope.address.push(response.Results[i]);
                }
                $ionicLoading.hide();
                $scope.modal.show();
            }, function(err) {
                console.log(err);
                clearTimeout(timer);
                $ionicLoading.hide();
                var confirmPopup = $ionicPopup.confirm({
                    template: 'Something went wrong!',
                    cssClass: 'popup_head_cust',
                    scope: $scope,
                    buttons: [{
                        text: 'Try Again!!',
                        onTap: function(e) {
                            $state.go($state.current, {}, { reload: true });
                        }
                    }]
                });

            });
        }
        };

        function internetcheck() {
            if ($cordovaNetwork.isOffline()) {
                 $ionicLoading.hide();
                $cordovaToast.showLongCenter("No internet connection!");
                return false;
            } else {
                return true;
            }
        }
        //api timeout
        function apiTimeout() {
            $ionicLoading.hide();
            clearTimeout(timer);
            timer = setTimeout(function() {
                $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
                $ionicLoading.hide();
            }, delay_time);
        }


    });
