app.controller(
    'ShipingDetailctrl',
    function($scope, LocalStorage, $state, $timeout, $ionicHistory, WebService, $rootScope, $location,
        $ionicSideMenuDelegate, $window, $ionicPlatform, $cordovaToast, $ionicLoading, $cordovaNetwork,
        GetCustomerAddressesByCustomerID, $ionicPopup, $ionicPlatform, DeleteCustomerAddress) {

        $ionicPlatform.registerBackButtonAction(function(event) {
            $scope.myGoBack();
        }, 100);

        $scope.$on('$stateChangeSuccess', function(ev, to, toParams, from, fromParams) {

            //   alert("skd");
            $rootScope.previousState = from.name;
            $rootScope.currentState = to.name;

        });


        $ionicSideMenuDelegate.canDragContent(false);
        var resObject;
        var dafaultaddress;
        $scope.address_details = [];
        var timer;
        var delay_time = $rootScope.timer_delay;
        $scope.showFooter = $rootScope.showFooter;
        $scope.$on("$ionicView.beforeEnter", function(event, data) {
            $ionicLoading.show({
                template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
            });
            if (internetcheck()) {
                apiTimeout();
                api();
          ;
            } else {
                $ionicLoading.hide();
                $cordovaToast.showLongCenter("No internet connection!");
            }
        });

        $scope.rememberMeUserInfoCheck = function() {

            return true;
        }


        $scope.removeRow = function(Items) {
            if (Items.IsDefaultDeliveryAdd == false) {

            } else {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    DeleteCustomerAddress.DeleteCustomerAddress($rootScope.CustomerID, Items.deliveryadd_ID).then(function(response) {
                        if (response == "ok") {
                            var index = $scope.address_details.indexOf(Items);
                            $scope.address_details.splice(index, 1);

                        } else {
                            $cordovaToast.showLongBottom(response);
                        }
                    }, function(err) {
                        console.log(err);
                        clearTimeout(timer);
                        $ionicLoading.hide();
                        var confirmPopup = $ionicPopup.confirm({
                            template: 'Something went wrong!',
                            cssClass: 'popup_head_cust',
                            scope: $scope,
                            buttons: [{
                                text: 'Try Again!!',
                                onTap: function(e) {
                                    $state.go($state.current, {}, { reload: true });
                                }
                            }]
                        });

                    });
                }
            }


        }

        //back button
        //change
        $scope.myGoBack = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if ($rootScope.statename == "app.home") {
                $state.go('app.home');
            } else {
                //window.history.back();
                $state.go('app.checkout');
            }
        };

        $scope.continue = function() {
            console.log($rootScope.billingAddress);
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if (resObject.ErrorID == 1) {
                $cordovaToast.showLongCenter("Please add address");
            } else if ($scope.readyToGo != true) {
                $cordovaToast.showLongCenter("Please select address");
            } else {

                $state.go("app.billingaddressconfirm", { 'billAddressObj': $rootScope.billingAddress });
            }

        };

        $scope.addnew = function(custID) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                var id = $rootScope.CustomerID;
                delete $rootScope.addressDetail
                $rootScope.CustomerID = id;
                $rootScope.fromShipping = true;
                $state.go("app.billingdetails", { 'addressObj': null });
            }
        }

        $scope.editdata = function(addressItem) {
            if (addressItem.IsDefaultDeliveryAdd == false) {

            } else {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    $state.go("app.billingdetails", { 'addressObj': addressItem });
                }
            }

        }

        // $scope.chackaddress = function(adress, index, previousCheck) {
        //     $rootScope.billingAddress = adress;
        //     $('#name-info' + index).addClass('radio-items');
        //     for (var i in $scope.address_details) {
        //         if ($scope.address_details[i].deliveryadd_ID == adress.deliveryadd_ID) {
        //             $scope.address_details[index].IsDefaultDeliveryAdd = true;
        //         } else {
        //             $scope.address_details[i].IsDefaultDeliveryAdd = false;
        //         }
        //     }

        // };

        $scope.chackaddress = function(adress, index, previousCheck) {

            $rootScope.billingAddress = adress;
            $scope.readyToGo = true;
            //$('#name-info' + index).addClass('radio-items');
            // alert(adress.deliveryadd_ID);
            //debugger;
            if (adress.deliveryadd_ID) {
                $scope.address_details[index].IsDefaultDeliveryAdd = true;
                $scope.$apply();
            }

            for (var i in $scope.address_details) {

                if (i != index) {
                    $scope.address_details[i].IsDefaultDeliveryAdd = false;
                    $scope.$apply();
                }
            }
        };

        // internet check
        function internetcheck() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
                return false;
            } else {
                return true;
            }
        }

        //api timeout
        function apiTimeout() {
            clearTimeout(timer);
            timer = setTimeout(function() {
                $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
                $ionicLoading.hide();
                api();
            }, delay_time);
        }

     function api() {
              GetCustomerAddressesByCustomerID.GetCustomerAddressesByCustomerID($rootScope.CustomerID).then(function(response) {
                    $ionicLoading.hide();
                    console.log(response)
                    resObject = JSON.parse(response);
                    clearTimeout(timer);
                    for (var i in resObject.Customer_Addresses) {
                        var defaultAdd = resObject.Customer_Addresses[i].IsDefaultDeliveryAdd;
                        if (defaultAdd) {
                            $scope.readyToGo = true;
                            $rootScope.billingAddress = resObject.Customer_Addresses[i];
                        } else {
                            //resObject.Customer_Addresses[0].IsDefaultDeliveryAdd = true;
                        }

                        $scope.address_details.push(resObject.Customer_Addresses[i]);
                    }
                    dafaultaddress = resObject.Customer_Addresses[0];
                    $scope.address_details = resObject.Customer_Addresses;

                    if ($scope.address_details.length == 1) {
                        $ionicLoading.hide();
                        console.log($scope.address_details.length);
                        $scope.address_details[0].IsDefaultDeliveryAdd = true;
                        $rootScope.billingAddress = $scope.address_details[0];
                        $scope.readyToGo = true;
                        $scope.$apply();
                        console.log($scope.address_details);
                    }

                })
          }
    });
