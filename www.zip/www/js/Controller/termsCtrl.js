app
    .controller(
        'termsCtrl',
        function($scope, LocalStorage, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $location,
            $ionicSideMenuDelegate, LocalStore, $window, $ionicPlatform, $ionicModal,
            $q, $http, $ionicLoading, $ionicModal, $cordovaNetwork, $cordovaToast, $ionicPlatform) {


            $ionicPlatform.registerBackButtonAction(function(event) {
                $scope.myGoBack();
            }, 100);

            $ionicSideMenuDelegate.canDragContent(false);
            //change
            $scope.myGoBack = function() {
                // if ($cordovaNetwork.isOffline()) {
                //     $cordovaToast.showLongCenter("No internet connection!");
                // } else {
                    window.history.back();
                //}
            }
        });