app.controller('manage_accountCtrl', function($scope, $ionicLoading, $localStorage, $cordovaCamera, UploadCustomerPicture, $ionicActionSheet, $ionicPopup, $timeout, $state, $rootScope, $ionicPlatform, $cordovaNetwork, $cordovaToast, UpdateCustomerInformation, GetCustomerDetailByID, $cordovaCamera, $ionicActionSheet, $ionicSideMenuDelegate) {

    $ionicPlatform.registerBackButtonAction(function(event) {
        $scope.myGoBack();
    }, 100);

    var regPostcode = /^([a-zA-Z]){1}([0-9][0-9]|[0-9]|[a-zA-Z][0-9][a-zA-Z]|[a-zA-Z][0-9][0-9]|[a-zA-Z][0-9]){1}([ ])|([0-9][a-zA-z][a-zA-z]){1}$/;
    $ionicSideMenuDelegate.canDragContent(false);
    $scope.imgURI = '';
    // var userObj = {};
    var imagebsee64;
    var imagepath;
    var timer;
    var delay_time = $rootScope.timer_delay;
    //change
    $scope.myGoBack = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            window.history.back();
        }
    };

    $scope.data = {};
    $scope.$on("$ionicView.afterEnter", function(event, data) {

        // handle event
        apiTimeout();
        GetCustomerDetailByID.GetCustomerDetailByID($rootScope.CustomerID).then(function(response) {
            var jsondata = JSON.parse(response);
            clearTimeout(timer);
            var respone = JSON.stringify(response);
            console.log(respone)
            console.log(jsondata.Customer_Detail)
            $rootScope.userdata = jsondata.Customer_Detail;
            $rootScope.userdata = jsondata.Customer_Detail;
            $scope.data.fname = jsondata.Customer_Detail.customer_FirstName;
            $scope.data.lstname = jsondata.Customer_Detail.customer_surname;
            $scope.data.email = jsondata.Customer_Detail.customer_EmailID;
            $scope.data.postcode = jsondata.Customer_Detail.customer_Postcode;
            $scope.data.mobileno = jsondata.Customer_Detail.customer_Mobile;
            $scope.data.phoneno = jsondata.Customer_Detail.customer_HomeTel;
            $scope.data.address = jsondata.Customer_Detail.customer_Address;
            $scope.data.city = jsondata.Customer_Detail.customer_city;
            $scope.gendertype = jsondata.Customer_Detail.customer_gendertype;
            $scope.data.gender = jsondata.Customer_Detail.customer_gendertype;
            //  $state.go("app.home");
            if ($scope.data.postcode != undefined || $scope.data.postcode != null) {
                $scope.data.postcode = $localStorage.postcodeSelected;
            }
        });

        if ($localStorage.userFbImg != undefined) {
            $scope.imgURI = $localStorage.userFbImg;
            //$scope.$apply();
        } else {
            $scope.imgURI = "img/icon_profile.png";
        }


    });

    var deliveryadd_ID = 0;

    var IsDefaultDeliveryAdd = 1;
    var shipingData = '';
    var EditData = '';
    var customerID = $rootScope.CustomerID;


    $scope.data.selectedvalue = "United Kingdom";


    $scope.uploadProfile = function(index) {
        var hideSheet = $ionicActionSheet.show({
            buttons: [
                { text: '<b>Camera</b> ' },
                { text: 'Gallery' },
                { text: 'Cancel' }
            ],
            //destructiveText: 'Gallery',
            titleText: 'Please choose',
            cancelText: 'Cancel',
            cancel: function() {
                // add cancel code..
            },
            buttonClicked: function(index) {
                if (index == 0) {
                    var options = {
                        quality: 75,
                        destinationType: Camera.DestinationType.DATA_URL,
                        sourceType: Camera.PictureSourceType.CAMERA,
                        allowEdit: true,
                        encodingType: Camera.EncodingType.JPEG,
                        targetWidth: 300,
                        targetHeight: 300,
                        popoverOptions: CameraPopoverOptions,
                        saveToPhotoAlbum: false
                    };

                    $cordovaCamera.getPicture(options).then(function(imageData) {
                        $scope.fileURL = imageData;
                        console.log(imageData);
                        imagepath = "data:image/jpeg;base64," + imageData;
                        imagepath = "data:image/jpeg;base64," + imageData;

                        //  $scope.imgURI = imagepath;
                        UploadCustomerPicture.UploadCustomerPicture(imageData, $rootScope.CustomerID)
                            .then(function(response) {
                                var resObject = JSON.parse(response);
                                console.log(resObject);
                                $localStorage.userFbImg = resObject.SmallImage;
                                $scope.imgURI = $localStorage.userFbImg;
                                $scope.$apply();
                                $cordovaToast.showLongBottom("Profile Updated!");

                            });
                        imagebsee64 = imageData;
                        $scope.imgURI = imagepath;
                        console.log($scope.imgURI);

                    }, function(err) {
                        // An error occured. Show a message to the user
                    });
                }
                if (index == 1) {
                    var options = {
                        quality: 75,
                        destinationType: Camera.DestinationType.DATA_URL,
                        sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                        allowEdit: true,
                        encodingType: Camera.EncodingType.JPEG,
                        targetWidth: 300,
                        targetHeight: 300,
                        popoverOptions: CameraPopoverOptions,
                        saveToPhotoAlbum: false
                    };

                    $cordovaCamera.getPicture(options).then(function(imageData) {
                        $scope.fileURL = imageData;
                        console.log(imageData);
                        imagepath = "data:image/jpeg;base64," + imageData;
                        //$scope.imgURI = imagepath;
                        UploadCustomerPicture.UploadCustomerPicture(imageData, $rootScope.CustomerID)
                            .then(function(response) {
                                var resObject = JSON.parse(response);
                                console.log(resObject);
                                $localStorage.userFbImg = resObject.SmallImage;
                                $scope.imgURI = $localStorage.userFbImg;
                                $scope.$apply();
                                $cordovaToast.showLongBottom("Profile Updated!");

                            });
                        $scope.imgURI = imagepath;
                        imagebsee64 = imageData;
                        console.log($scope.imgURI);
                    }, function(err) {

                    });
                }
                if (index == 2) {
                    $timeout(function() {
                        hideSheet();
                    }, 500);
                }
                return true;
            }
        });
    };

    $scope.submit = function(data, selectedvalue, gender) {
        if ($cordovaNetwork.isOffline()) {
            $ionicLoading.hide();
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            if (data.fname == '' || data.fname == undefined) {
                $cordovaToast.showLongBottom('Please Enter Firstname');
            } else if (data.lstname == '' || data.lstname == undefined) {

                $cordovaToast.showLongBottom('Please Enter Lastname');
            } else if (data.lstname == '' || data.lstname == undefined) {

                $cordovaToast.showLongBottom('Please Enter Lastname');
            } else if (!gender) {

                $cordovaToast.showLongBottom('Please choose Gender');
            } else if (!(/^([\w]+(?:\.[\w]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/.test(data.email))) {

                $cordovaToast.showLongBottom("Please enter valid Email");
            } else if (!(/^([\w]+(?:\.[\w]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/.test(data.email))) {
                $cordovaToast.showLongBottom("Please enter valid Email");
            } else if (data.postcode == '' || data.postcode == undefined) {

                $cordovaToast.showLongBottom('Please Enter Postcode');
            } else if (regPostcode.test(data.postcode) == false) {
                $cordovaToast.showLongBottom('Please Enter valid Postcode');
            } else if (data.city == '' || data.city == undefined) {

                $cordovaToast.showLongBottom('Please Enter City');
            } else if (data.mobileno == '' || data.mobileno == undefined) {

                $cordovaToast.showLongBottom('Please Enter Mobile Number');
            } else if (data.phoneno == '' || data.phoneno == undefined) {

                $cordovaToast.showLongBottom('Please Enter Phone number');

            } else if (data.address == '' || data.address == undefined) {

                $cordovaToast.showLongBottom('Plase Enter Address');
            } else {

                if ($cordovaNetwork.isOnline()) {
                    $ionicLoading.show({
                        template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                    });
                    var address = {

                        "customer_ID": $rootScope.CustomerID,
                        "customer_gendertype": gender,
                        "customer_FirstName": data.fname,
                        "customer_surname": data.lstname,
                        "customer_EmailID": data.email,
                        "customer_HomeTel": data.phoneno,
                        "customer_Mobile": data.mobileno,
                        "customer_city": data.city,
                        "customer_Postcode": data.postcode,
                        "customer_Address": data.address,
                        "customer_state": data.city,
                        "customer_country": selectedvalue
                    }

                    console.log(address);
                    apiTimeout();
                    UpdateCustomerInformation.UpdateCustomerInformation(address).then(function(response) {
                        console.log(response);
                        clearTimeout(timer);
                        $ionicLoading.hide();
                        if (response == 1) {
                            console.log(response);
                            $cordovaToast.showLongBottom('Profile Updated');
                            window.history.back();
                        } else if (response != 1) {
                            $cordovaToast.showLongBottom('Something went wrong please try again');
                        } else {
                            $ionicLoading.hide();
                            $cordovaToast.showLongBottom('please check Internet connection');
                        }
                    }, function(err) {
                        console.log(err);
                        clearTimeout(timer);
                        $ionicLoading.hide();
                        var confirmPopup = $ionicPopup.confirm({
                            template: 'Something went wrong!',
                            cssClass: 'popup_head_cust',
                            scope: $scope,
                            buttons: [{
                                text: 'Try Again!!',
                                onTap: function(e) {
                                    $state.go($state.current, {}, { reload: true });
                                }
                            }]
                        });

                    });
                }
            }
        }
    }


    //picture
    $scope.takePicture = function(index) {
        var hideSheet = $ionicActionSheet.show({
            buttons: [
                { text: '<b>Camera</b> ' },
                { text: 'Gallery' },
                { text: 'Cancel' }
            ],
            //destructiveText: 'Gallery',
            titleText: 'Please choose',
            cancelText: 'Cancel',
            cancel: function() {
                // add cancel code..
            },
            buttonClicked: function(index) {
                if (index == 0) {
                    var options = {
                        quality: 75,
                        destinationType: Camera.DestinationType.DATA_URL,
                        sourceType: Camera.PictureSourceType.CAMERA,
                        allowEdit: true,
                        encodingType: Camera.EncodingType.JPEG,
                        targetWidth: 300,
                        targetHeight: 300,
                        popoverOptions: CameraPopoverOptions,
                        saveToPhotoAlbum: false
                    };

                    $cordovaCamera.getPicture(options).then(function(imageData) {
                        imagepath = "data:image/jpeg;base64," + imageData;
                        imagepath = "data:image/jpeg;base64," + imageData;
                        imagebsee64 = imageData;
                        $scope.imgURI = imagepath;
                        $rootScope.userimage = imagepath;
                        console.log($rootScope.userimage);
                        console.log($scope.imgURI);


                    }, function(err) {
                        // An error occured. Show a message to the user
                    });
                }
                if (index == 1) {
                    var options = {
                        quality: 75,
                        destinationType: Camera.DestinationType.DATA_URL,
                        sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                        allowEdit: true,
                        encodingType: Camera.EncodingType.JPEG,
                        targetWidth: 300,
                        targetHeight: 300,
                        popoverOptions: CameraPopoverOptions,
                        saveToPhotoAlbum: false
                    };

                    $cordovaCamera.getPicture(options).then(function(imageData) {

                        imagepath = "data:image/jpeg;base64," + imageData;
                        $scope.imgURI = imagepath;
                        $rootScope.userimage = imagepath;
                        imagebsee64 = imageData;
                        console.log($scope.imgURI);

                    }, function(err) {

                    });
                }
                if (index == 2) {
                    $timeout(function() {
                        hideSheet();
                    }, 500);
                }
                return true;
            }
        });
    }

    //api timeout
    function apiTimeout() {
        clearTimeout(timer);
        timer = setTimeout(function() {
            $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
            $ionicLoading.hide();
        }, delay_time);
    }
});
