app.controller('googleimagesCtrl', function($scope, $stateParams, $state, $timeout, $ionicHistory, WebService, $rootScope,
    $location, $localStorage, $ionicPopover, $ionicSideMenuDelegate, $window, $q, $http, $cordovaToast, $ionicLoading, $cordovaToast, $ionicModal,
    $ionicPopup, GetBakeriesAndCakesBypostcodeAndMiles, $ionicPopover, $cordovaNetwork, getgoogleprdsbykeyword, $ionicSideMenuDelegate, $cacheFactory, GetCakesByPostcodeAndMiles, GetCategories, $ionicPopup, LocalStorage) {




    $scope.$on("$ionicView.beforeEnter", function(event, data) {

    });


    $scope.$on("$ionicView.enter", function(event, data) {
        // alert($state.params.prid);
        var id = $state.params.prid;
        getgoogleprdsbykeyword.getgoogleprdsbykeyword(id).then(function(response) {

            var resObject = JSON.parse(response);
            console.log(resObject);

        });
    });
});
