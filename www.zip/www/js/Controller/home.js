app.controller('homeCtrl', function($scope, $window, $state, $timeout, $http, UploadCustomerPicture, $ionicHistory,
    $rootScope, WebService, $interval, $location, $ionicLoading,
    $cordovaNetwork, $cordovaToast, $ionicSideMenuDelegate, insertdevice, GetMilesListing,
    $ionicPlatform, $ionicPopup, $ionicActionSheet, $cordovaCamera, LocalStorage,
    $ionicModal, $cordovaGeolocation, GetCakesByPostcodeAndMiles, $ionicPopup, $stateParams, getbakerylist_bypostcode, $localStorage) {
    //alert('hell');
    var backbutton = 0;
    var timer;
    var intrerval;
    $scope.searchmiles = [];
    var timerGps;
    $scope.locationimg = true;
    $scope.$watch('online', function(newStatus) {

        //alert(newStatus);
        if (newStatus == false) {
            $scope.loaderimage = false;
            $cordovaToast.showLongCenter("No internet connection!");
        }
        if (newStatus == true) {
            getmileslisting();
        }
    });

    function getmileslisting() {
        GetMilesListing.GetMilesListing().then(function(response) {
            var resObject = JSON.parse(response);
            for (var i = 0; i < resObject.length; i++) {
                console.log(resObject[i]);
                $scope.searchmiles.push(resObject[i]);
                $localStorage.searchmiles = $scope.searchmiles[0].MilesLabel;
                $localStorage.milesvalue = $scope.searchmiles[0].MilesValue;
                console.log($scope.searchmiles);
            }
            //  console.log(resObject.length)
            //  $scope.modal.show();

        });
    }

    var regPostcode = /^([a-zA-Z]){1}([0-9][0-9]|[0-9]|[a-zA-Z][0-9][a-zA-Z]|[a-zA-Z][0-9][0-9]|[a-zA-Z][0-9]){1}([ ])|([0-9][a-zA-z][a-zA-z]){1}$/;
    var delay_time = $rootScope.timer_delay;
    $scope.data = {};
    $ionicPlatform.registerBackButtonAction(function(event) {
        window.close();
        if (backbutton == 0) {
            backbutton++;
            window.plugins.toast.showShortCenter('Press again to exit');
        } else {
            navigator.app.exitApp();
        }
    }, 100);


    // GetMilesListingResponse.GetMilesListingResponse().then(function(response) {
    //                           console.log(response)
    //                           //  $scope.modal.show();

    //                         });
    // function enableGPSAutomatically() {
    //     cordova.plugins.diagnostic.isLocationEnabled(function(enabled) {
    //         console.log("Location is " + (enabled ? "enabled" : "disabled"));
    //         if (enabled == false) {
    //             $scope.locationimgone = true;
    //             $scope.locationimg = false;
    //             $cordovaToast.showLongBottom('Please enable your GPS settings');
    //         }
    //         if (enabled == true) {
    //             $scope.locationimgone = true;
    //             $scope.locationimg = false;
    //             $cordovaToast.showLongBottom('Please enable your GPS settings');
    //         }
    //     }, function(error) {
    //         console.error("The following error occurred: " + error);
    //     });

    // }


    function apiTimeoutGps() {
        clearTimeout(timer);
        clearInterval(timerGps);
        timerGps = setTimeout(function() {
            // $cordovaToast.showLongBottom('Unable to get your gps location please click here');

            $('#tooltip').removeClass('hide_block');
            $ionicLoading.hide();
        }, delay_time);
    }

    $scope.increment = 1;

    function getGPSLocation() {

        if ($cordovaNetwork.isOnline() == false) {
            $cordovaToast.showLongCenter('No internet connection!');
            $ionicLoading.hide();
        } else {
            apiTimeoutGps();
            if (navigator.geolocation) {
                var options = {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 0
                };
                navigator.geolocation.getCurrentPosition(function(position, options) {
                    clearInterval(timerGps);

                    //clearTimeout(options.timeout);

                    // $scope.$apply(function() {
                    //     $scope.position = position;
                    //     //console.log(position);
                    //     // alert(position.coords.latitude);
                    // });



                    // console.log(p.coords.latitude);
                    // console.log(p.coords.longitude);
                    // var lat = p.coords.latitude;
                    // var long = p.coords.longitude;

                    var URL = "https://maps.googleapis.com/maps/api/geocode/json?latlng=" + $scope.position.coords.latitude + "," + $scope.position.coords.longitude + "&location_type=APPROXIMATE&result_type=postal_code&key=AIzaSyCr55s0UbYyfxyVoYN9Tq4PC3UZuxEP0rw";
                    $http.get(URL).then(function(resp) {
                        $ionicLoading.hide();

                        console.log('Success', resp); // JSON object
                        if (resp.data.results != undefined) {
                            if (resp.data.results.length > 0) {
                                if (resp.data.results[0].address_components != undefined) {
                                    if (resp.data.results[0].address_components.length > 0) {
                                        if (resp.data.results[0].address_components[0].long_name != undefined) {
                                            // $cope.data.postcode = resp.data.results[0].address_components[0].long_name;
                                            // $scope.$apply();
                                            $scope.locationimgone = false;
                                            $scope.locationimg = true;
                                            $rootScope.postcode = resp.data.results[0].address_components[0].long_name;
                                            $scope.data.postcode = $rootScope.postcode;
                                            $localStorage.postcodeSelected = $rootScope.postcode;
                                            clearInterval(intrerval);
                                            clearTimeout(timer);
                                            //$scope.$apply();
                                            console.log($rootScope.postcode);
                                            console.log($scope.data.postcode);
                                        }
                                    }
                                }
                            }
                        } else {
                            $ionicLoading.hide();
                            $cordovaToast.showLongBottom('Enable to get the location, Please enter your postalcode.');
                        }
                        console.log(resp.data.results[0].address_components[0].long_name);
                    }, function(err) {
                        console.error('ERR', err);
                    })
                }, function(err) {
                    $ionicLoading.hide();
                    $cordovaToast.showLongBottom('Enable to get the location, Please enter your postalcode.');
                });
            }
        }
        // if ($scope.increment <= 3) {
        //     setTimeout(function() {
        //         $scope.increment += 1;
        //         getGPSLocation();
        //     }, 5000);
        // }
    };

    var path = $location.path();
    $rootScope.username = "Guest";
    $rootScope.loggedin = false;
    var isGPS_processing = false;

    function isGPSEnabled() {
        cordova.plugins.diagnostic.isLocationEnabled(function(enabled) {
            console.log("Location is " + (enabled ? "enabled" : "disabled"));
            if (enabled == false) {
                //if (!isGPS_processing) {
                //isGPS_processing = true;
                cordova.plugins.diagnostic.switchToLocationSettings();
                enableGPSAuto();
                //}
            } else {
                getGPSLocation();
            }
        }, function(error) {
            console.error("The following error occurred: " + error);
        });
    }

    var alertCreated = false;

    function enableGPSAuto() {
        cordova.plugins.locationAccuracy.canRequest(function(canRequest) {
            if (canRequest) {
                cordova.plugins.locationAccuracy.request(function() {
                        console.log("Request successful");
                        $ionicLoading.hide();
                        $ionicLoading.show({
                            noBackdrop: false,
                            template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                        });

                        intrerval = setInterval(function() {
                            //isGPS_processing = false;
                            getGPSLocation();
                        }, 5000);
                        /*var Popup = $ionicPopup.confirm({
                            title: 'Cancel Order',
                            template: 'To continue, let your device turn on location using Google location services',
                            scope: $scope,
                            buttons: [
                                { text: 'No' }, {
                                    text: 'Yes',
                                    onTap: function(e) {
                                        cordova.plugins.diagnostic.switchToLocationSettings();
                                        $ionicLoading.hide();
                                        $ionicLoading.show({
                                            noBackdrop: false,
                                            template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                                        });
                                        intrerval = setInterval(function() {
                                            isGPS_processing = false;
                                            getGPSLocation();
                                        }, 5000);
                                    }
                                }
                            ]
                        });*/
                        //cordova.plugins.diagnostic.switchToLocationSettings();
                        // intrerval = setInterval(function() {
                        //     isGPS_processing = false;
                        //     getGPSLocation();
                        // }, 500);

                    }, function(error) {
                        console.error("Request failed");
                        if (error) {
                            // Android only
                            console.error("error code=" + error.code + "; error message=" + error.message + " " + cordova.plugins.locationAccuracy.requesting);
                            if (error.code !== cordova.plugins.locationAccuracy.ERROR_USER_DISAGREED) {
                                if (!alertCreated) {
                                    alertCreated = true;


                                    // if (window.confirm("To continue, let your device turn on location using Google's location services")) {
                                    //     cordova.plugins.diagnostic.switchToLocationSettings();
                                    //     $ionicLoading.hide();
                                    //     $ionicLoading.show({
                                    //         noBackdrop: false,
                                    //         template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                                    //     });
                                    //     // intrerval = setInterval(function() {
                                    //     //     isGPS_processing = false;
                                    //     //     getGPSLocation();
                                    //     // }, 5000);
                                    // }
                                }
                            }
                        }
                    }, cordova.plugins.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY // iOS will ignore this
                );
            }
        });
    }

    $scope.$on("$ionicView.loaded", function(event, data) {
        // intrerval = setInterval(function() {
        //     console.log('ankush');
        //     getGPSLocation();
        // }, 5000)
        // getmileslisting();
        setTimeout(function() {
            navigator.splashscreen.hide();
        }, 1000);
        $localStorage.milesSelected = $scope.data.miles;
        if ($localStorage.postcodeSelected) {
            $scope.data.postcode = $localStorage.postcodeSelected;
            $scope.data.miles = $localStorage.milesSelected + " Miles";
            //    $scope.$apply();
        } else {
            intrerval = setTimeout(function() {
                isGPSEnabled();
            }, 5000);
        }


    });

    $scope.$on("$ionicView.afterEnter", function(event, data) {
        //timeout for splashscreen
        var devicetypeid = 0;
        insertdevice.insertdevice($localStorage.deviceToken, $rootScope.CustomerID, devicetypeid).then(function(response) {
            console.log(response);
        });




        // intrerval = setInterval(function() {

        //     getGPSLocation();
        // }, 5000);
        getCartCount();

        //debugger;
        if ($localStorage.userDetails != null && $localStorage.userDetails.length != 0) {
            setTimeout(function() {
                $rootScope.loggedin = true;
                $rootScope.username = $localStorage.userDetails.Name;
                $rootScope.userdetail = $localStorage.userDetails;
                $rootScope.CustomerID = $localStorage.userDetails.userID;

            }, 50);
        }
        //debugger;
        if ($localStorage.userFbImg != undefined) {
            $scope.imgURI = $localStorage.userFbImg;
        } else {
            $scope.imgURI = "img/icon_profile.png";
        }

        if ($localStorage.milesSelected != undefined || $localStorage.milesSelected != null) {
            if ($localStorage.milesSelected == "This Area") {
                $scope.data.miles = $localStorage.milesSelected;;
                $rootScope.selectedvalue = $localStorage.milesvalue;
            } else if ($localStorage.milesSelected == $scope.searchmiles[0].MilesValue) {
                $scope.data.miles = $localStorage.searchmiles;
                $rootScope.selectedvalue = $scope.searchmiles[0].MilesValue;
            } else {
                $scope.data.miles = $localStorage.milesSelected + " Miles";
                $rootScope.selectedvalue = $localStorage.milesSelected;
            }
        }

    });

    $scope.logout_click = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            window.localStorage.clear();
            $ionicHistory.clearCache();
            $rootScope.loggedin = false;
            $rootScope.username = "Guest";
            $localStorage.userDetails = [];
            // $localStorage.postcodeSelected = null;
            // $localStorage.milesSelected = null;
            $localStorage.milesArray = null;
            $localStorage.userFbImg = undefined;
            $rootScope.statename = null;
            $scope.imgURI = $scope.$new(true);
            $localStorage.detail = [];
            $rootScope.detail = [];
            $scope.count = 0;
            $rootScope.cartnotificationHome = false;
            $state.go('app.home', { reload: true });
            $cordovaToast.showLongBottom('Logged out successfully!');
        }
    };

    $scope.home = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go('app.home');
        }
    };
    //chnage
    $scope.myGoBack = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        }
        $state.go("app.home");
    };


    $scope.goTo = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go('app.manage_account', { reload: true });
        }
    };

    //change
    $scope.goToManageAddress = function() {
        $rootScope.statename = "app.home";
        $rootScope.showFooter = false;
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go('app.shippingdetail', { 'nextview': null });
        }
    };
    //change
    $scope.signin = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.login");
        }
    };
    //change
    $scope.mangeAccount_Arrowclick = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.manage_account");
        }
    };



    $scope.uploadProfile = function(index) {
        var hideSheet = $ionicActionSheet.show({
            buttons: [
                { text: '<b>Camera</b> ' },
                { text: 'Gallery' },
                { text: 'Cancel' }
            ],
            //destructiveText: 'Gallery',
            titleText: 'Please choose',
            cancelText: 'Cancel',
            cancel: function() {
                // add cancel code..
            },
            buttonClicked: function(index) {
                if (index == 0) {
                    var options = {
                        quality: 75,
                        destinationType: Camera.DestinationType.DATA_URL,
                        sourceType: Camera.PictureSourceType.CAMERA,
                        allowEdit: true,
                        encodingType: Camera.EncodingType.JPEG,
                        targetWidth: 300,
                        targetHeight: 300,
                        popoverOptions: CameraPopoverOptions,
                        saveToPhotoAlbum: false
                    };

                    $cordovaCamera.getPicture(options).then(function(imageData) {
                        $scope.fileURL = imageData;
                        console.log(imageData);
                        imagepath = "data:image/jpeg;base64," + imageData;
                        imagepath = "data:image/jpeg;base64," + imageData;

                        //  $scope.imgURI = imagepath;
                        UploadCustomerPicture.UploadCustomerPicture(imageData, $rootScope.CustomerID)
                            .then(function(response) {
                                var resObject = JSON.parse(response);
                                console.log(resObject);
                                $localStorage.userFbImg = resObject.SmallImage;
                                $scope.imgURI = $localStorage.userFbImg;

                            });
                        imagebsee64 = imageData;

                        console.log($scope.imgURI);
                        //$scope.sendImage($scope.imgURI);
                    }, function(err) {
                        // An error occured. Show a message to the user
                    });
                }
                if (index == 1) {
                    var options = {
                        quality: 75,
                        destinationType: Camera.DestinationType.DATA_URL,
                        sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                        allowEdit: true,
                        encodingType: Camera.EncodingType.JPEG,
                        targetWidth: 300,
                        targetHeight: 300,
                        popoverOptions: CameraPopoverOptions,
                        saveToPhotoAlbum: false
                    };

                    $cordovaCamera.getPicture(options).then(function(imageData) {
                        $scope.fileURL = imageData;
                        console.log(imageData);
                        imagepath = "data:image/jpeg;base64," + imageData;
                        //$scope.imgURI = imagepath;
                        UploadCustomerPicture.UploadCustomerPicture(imageData, $rootScope.CustomerID)
                            .then(function(response) {
                                var resObject = JSON.parse(response);
                                console.log(resObject);
                                $localStorage.userFbImg = resObject.SmallImage;
                                $scope.imgURI = $localStorage.userFbImg;

                            });
                        $scope.imgURI = imagepath;
                        imagebsee64 = imageData;
                        console.log($scope.imgURI);
                        $scope.sendImage($scope.imgURI);
                    }, function(err) {

                    });
                }
                if (index == 2) {
                    $timeout(function() {
                        hideSheet();
                    }, 500);
                }
                return true;
            }
        });
    };


    $scope.getPostCode = function() {
        if (internetcheck()) {
            $ionicLoading.show({
                noBackdrop: false,
                template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
            });
            $('#tooltip').addClass('hide_block');
            isGPSEnabled();
        } else {
            $ionicLoading.hide();
            //$cordovaToast.showLongBottom("Please check your internet");

        }

    }

    function getCartCount() {
        if ($rootScope.detail == undefined) {
            $scope.cartnotification = true;
            $scope.count = 0;
            $rootScope.cartnotificationHome = false;
        } else if ($rootScope.detail.length == 0) {
            $scope.cartnotification = true;
            $scope.count = 0;
            $rootScope.cartnotificationHome = false;
        } else {
            $scope.cartnotification = true;
            $rootScope.cartnotificationHome = true;
            $scope.count = $rootScope.detail.length;
        }
    };

    $scope.data = {};
    console.log($scope.searchmiles);
    $scope.data.miles = 'This Area';

    // $scope.searchmiles = [{ title: "This Area", value: ".25" }, { title: "1/2 mile", value: ".5" }, {
    //     title: "1 mile",
    //     value: "1"
    // }, { title: "3 miles", value: "3" }, { title: "5 miles", value: "5" }, { title: "10 miles", value: "10" }, { title: "15 miles", value: "15" }, { title: "20 miles", value: "20" }, { title: "30 miles", value: "30" }, { title: "40 miles", value: "40" }];


    $rootScope.miles = $scope.searchmiles;
    $localStorage.milesArray = $scope.searchmiles;
    var pageno = 1;
    var pagesize = 20;
    $rootScope.pagesize = pagesize;

    $scope.search = function() { //button click
        if ($cordovaNetwork.isOnline()) {
            $localStorage.postcodeSelected = $scope.data.postcode;
            if ($localStorage.milesSelected != "This Area") {
                //var miles = $rootScope.selectedvalue.split(' ');
                //$scope.chooseMiles = miles[0].trim();

            } else {
                //$rootScope.selectedvalue = .25;
                $localStorage.milesSelected = $scope.searchmiles[0].MilesValue;
            }

            if ($scope.data.postcode == '' || $scope.data.postcode == undefined) {
                $cordovaToast.showLongBottom("Please enter postalcode");
            } else if (regPostcode.test($scope.data.postcode) == false) {
                $cordovaToast.showLongBottom('Please Enter valid Postcode');
            } else {
                if ($cordovaNetwork.isOnline()) {
                    $ionicLoading.show({
                        noBackdrop: false,
                        template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                    });
                    apiTimeout();
                    GetCakesByPostcodeAndMiles.GetCakesByPostcodeAndMiles(pageno,
                        pagesize, $localStorage.postcodeSelected, $localStorage.milesSelected).then(function(response) {
                        $ionicLoading.hide();
                        clearTimeout(timer);
                        var responseObject = JSON.parse(response);
                        if (responseObject.ErrorID == 1) {
                            $cordovaToast.showLongBottom(responseObject.ErrorMsg);
                        } else {
                            $localStorage.reDirect = true;
                            $state.go("app.searchbusiness", { 'postalcode': $localStorage.postcodeSelected, 'miles': $localStorage.milesSelected }, { cache: true });
                        }
                    }, function(err) {
                        console.log(err);
                        clearTimeout(timer);
                        $ionicLoading.hide();
                        var confirmPopup = $ionicPopup.confirm({
                            template: 'Something went wrong!',
                            cssClass: 'popup_head_cust',
                            scope: $scope,
                            buttons: [{
                                text: 'Try Again!!',
                                onTap: function(e) {
                                    $state.go($state.current, {}, { reload: true });
                                }
                            }]
                        });

                    });

                    // $localStorage.reDirect = true;
                    //$state.go("app.searchbusiness", { 'postalcode': $localStorage.postcodeSelected, 'miles': $localStorage.milesSelected }, { cache: true });
                } else {
                    $ionicLoading.hide();
                    $cordovaToast.showLongBottom("No internet connection!");
                }
            }
        } else {
            $ionicLoading.hide();
            $cordovaToast.showLongBottom("No internet connection!");
        }
    }

    $ionicModal.fromTemplateUrl('my-Modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modal = modal;
    });

    var showMile;

    $scope.selectMiles = function() {
        if ($cordovaNetwork.isOnline()) {
            // getmileslisting();
            $scope.mile = [];
            showMile = $scope.data.miles;
            console.log(showMile);
            console.log($scope.data.miles)
            if (showMile == undefined) {
                $scope.mile[0] = true;
            } else {
                for (var i = 0 in $scope.searchmiles) {
                    if ($scope.searchmiles[i].title == showMile) {
                        $scope.mile[i] = true;
                        //$("#qty" + i).attr('checked', true);
                        break;
                    }
                }
            }
            $scope.modal.show();
        } else {
            $ionicLoading.hide();
            $cordovaToast.showLongBottom("No internet connection!");
        }
    };

    $scope.closeModal = function() {
        $scope.modal.hide();
    };

    $scope.search_click = function() { //keyboard click
        if ($cordovaNetwork.isOnline()) {
            $localStorage.postcodeSelected = $scope.data.postcode;
            if ($localStorage.milesSelected) {
                // var miles = selectedvalue.split(' ');
                //$scope.chooseMiles = miles[0].trim();
            } else {

                // $rootScope.selectedvalue = .25;
                $localStorage.milesSelected = $scope.searchmiles[0].MilesValue;
            }

            if ($scope.data.postcode == '' || $scope.data.postcode == undefined) {
                $cordovaToast.showLongBottom("Please enter postalcode");
            } else if (regPostcode.test($scope.data.postcode) == false) {
                $cordovaToast.showLongBottom('Please Enter valid Postcode');
            } else {
                if ($cordovaNetwork.isOnline()) {
                    $ionicLoading.show({
                        noBackdrop: false,
                        template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                    });
                    apiTimeout();
                    GetCakesByPostcodeAndMiles.GetCakesByPostcodeAndMiles(pageno,
                        pagesize, $localStorage.postcodeSelected, $localStorage.milesSelected).then(function(response) {
                        console.log(response);
                        $ionicLoading.hide();
                        clearTimeout(timer);
                        var responseObject = JSON.parse(response);
                        if (responseObject.ErrorID == 1) {
                            $cordovaToast.showLongBottom(responseObject.ErrorMsg);
                        } else {
                            $localStorage.reDirect = true;
                            $state.go("app.searchbusiness", { 'postalcode': $localStorage.postcodeSelected, 'miles': $localStorage.milesSelected }, { cache: true });
                        }
                    }, function(err) {
                        console.log(err);
                        clearTimeout(timer);
                        $ionicLoading.hide();
                        var confirmPopup = $ionicPopup.confirm({
                            template: 'Something went wrong!',
                            cssClass: 'popup_head_cust',
                            scope: $scope,
                            buttons: [{
                                text: 'Try Again!!',
                                onTap: function(e) {
                                    $state.go($state.current, {}, { reload: true });
                                }
                            }]
                        });

                    });
                } else {
                    $ionicLoading.hide();
                    $cordovaToast.showLongBottom("No internet connection!");
                }
            }
        } else {
            $ionicLoading.hide();
            $cordovaToast.showLongBottom("No internet connection!");
        }
        $scope.modal.hide();
    };

    function internetcheck() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
            return false;
        } else {
            return true;
        }
    }

    $scope.searchMiles = function(selectedvalue) { //modal click
        if (selectedvalue == $scope.searchmiles[0].MilesValue) {
            $scope.data.miles = "This Area";
            $localStorage.milesSelected = selectedvalue;
        } else {
            $scope.data.miles = selectedvalue + ' ' + 'miles';
            $localStorage.milesSelected = selectedvalue;
        }

        console.log($scope.data.postcode);
        console.log(selectedvalue);
        $rootScope.selectedvalue = selectedvalue;
        // $localStorage.milesSelected = selectedvalue;
        $scope.modal.hide();
    };


    //api timeout
    function apiTimeout() {
        clearTimeout(timer);
        clearInterval(intrerval);
        timer = setTimeout(function() {
            $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
            $ionicLoading.hide();
        }, delay_time);
    }


    $scope.cart_click = function() {
        if ($cordovaNetwork.isOnline()) {
            if ($rootScope.detail.length == 0) {
                $cordovaToast.showLongBottom("Cart is empty");
            } else {
                $state.go("app.cart");
            }
        } else {
            $cordovaToast.showLongCenter("No internet connection!");
        }
    }

    $scope.signinpage = function() {
        if ($cordovaNetwork.isOnline()) {
            $state.go("app.login");
        } else {
            $cordovaToast.showLongCenter("No internet connection!");
        }
    };
    $scope.regiterpage = function() {
        if ($cordovaNetwork.isOnline()) {
            $state.go("app.user-register-page");
        } else {
            $cordovaToast.showLongCenter("No internet connection!");
        }
    };
});
