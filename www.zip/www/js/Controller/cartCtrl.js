app.controller('cartCtrl', function($scope, $state, WebService, $rootScope, $window, $cordovaNetwork,
    ionicDatePicker, $rootScope, $ionicModal, $localStorage,
    $timeout, GetCustomerDetailByID, $ionicPlatform, $ionicPopup, IsDeliverableToUserPostcode, $ionicScrollDelegate, $stateParams, $cordovaToast) {
    console.log($rootScope.detail);
    // console.log($rootScope.occ_detail);
    // $scope.occ = $rootScope.occ_detail;

    $ionicPlatform.registerBackButtonAction(function(event) {
        $scope.myGoBack();
    }, 100);

    window.addEventListener('native.keyboardshow', function() {
        $('#testing_footer').addClass('keyboard_footer');
    });

    window.addEventListener('native.keyboardhide', function() {
        $('#testing_footer').removeClass('keyboard_footer');
    });

    $scope.nocontent = false;
    $scope.notCompleted = false;
    var showQty;
    $scope.data = {};
    $scope.qty = [];
    $scope.dateDelShowOnView = [];
    $scope.dateShowOnView = [];
    $scope.selectQuantity = [];
    $scope.Go = [];
    $scope.dateShow = [];
    $scope.timeShow = [];
    $scope.catShow = [];
    $scope.dateDelShow = [];
    $scope.timeDelShow = [];
    $scope.catDelShow = [];
    $scope.timings = [];
    $scope.deliveryDetails = {};
    $scope.city = [];
    $scope.state = [];
    $scope.country = [];
    $scope.fname = [];
    $scope.lname = [];
    $scope.contact = [];
    $scope.address = [];
    $scope.emailid = [];
    var selectedIndex = 0;
    var typeId;
    $scope.chooseCat = false;
    $scope.chooseDel = false;
    $scope.change = true;
    $scope.modalView = false;
    $scope.selectDate = false;

    $scope.passcode = [];
    $scope.msgWrite = [];
    $scope.msgWriteDel = [];
    var timer;
    var delay_time = $rootScope.timer_delay;

    if ($rootScope.detail == undefined) {

        $scope.nocontent = true;
        $scope.footer = false;

    } else {
        $scope.maincart = true;
        $scope.footer = true;
    }

    $scope.test = {};
    $scope.test.count = 1;

    $scope.onNumberChanged = function() {

        $scope.selectedvalue = $scope.test.count;
    };


    $scope.data = {};
    var date = new Date();

    $rootScope.$on('$stateChangeSuccess', function(ev, to, toParams, from, fromParams) {
        $rootScope.previousState = from.name;
        $rootScope.currentState = to.name;
        console.log($rootScope.previousState);

    });

    $scope.$on("$ionicView.loaded", function(event, data) {

        $scope.cakeCart = $rootScope.detail;
        $localStorage.cartLength = $scope.cakeCart.length;
    });

    $scope.$on("$ionicView.beforeEnter", function(event, data) {



    });

    $scope.$on("$ionicView.enter", function(event, data) {});
    $scope.$on("$ionicView.afterEnter", function(event, data) {
        calculateTotalSum();
        $rootScope.cakeEditIndex = undefined;
        reloadContent();
        if ($localStorage.cartLength != $rootScope.detail.length) {
            $scope.cakeCart = $rootScope.detail;
            $localStorage.cartLength = $rootScope.detail.length;
            $state.reload();
        }
    });

    //back button
    //change
    $scope.myGoBack = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if ($rootScope.previousState == 'app.cakedetail') {
            $rootScope.isEdit = false;
            $rootScope.cakeEditIndex = undefined;
            if ($rootScope.detail.length < 0) {
                $state.go("app.cakedetail");
            } else {
                $state.go("app.searchbusiness");
            }
        } else if ($rootScope.previousState == 'app.home') {

            $state.go("app.home");
        } else {
            $rootScope.isEdit = false;
            $rootScope.cakeEditIndex = undefined;
            $state.go("app.searchbusiness");
        }
    }

    $scope.reloadShow = [];
    $scope.reloadDelShow = [];

    function reloadContent() {

        for (var i in $rootScope.detail) {
            if ($rootScope.detail[i].CollectionMode == 2) {
                $scope.reloadDelShow[i] = true;
                $scope.dateDelShowShowOnView[i] = $rootScope.detail[i].date;
                $scope.timeDelShow[i] = $rootScope.detail[i].time;
                $scope.catDelShow[i] = $rootScope.detail[i].Ordercollection_Occassion;
                $scope.msgDelWrite[i] = $rootScope.detail[i].Ordercollection_Remarks;
                $scope.Go[i] = $rootScope.detail[i].done;
                $scope.selectQuantity[i] = $rootScope.detail[i].quantity;
            } else {
                $scope.reloadShow[i] = true;
                console.log($rootScope.detail[i].date);
                if ($rootScope.detail[i].date != null) {
                    $scope.date = $rootScope.detail[i].date;
                }
                if ($rootScope.detail[i].time != null) {
                    $scope.time = $rootScope.detail[i].time;
                    //$scope.timeShow[i] = $rootScope.detail[i].time;
                }
                $scope.dateShowOnView[i] = $rootScope.detail[i].date;
                $scope.timeShow[i] = $rootScope.detail[i].time;
                $scope.catShow[i] = $rootScope.detail[i].Ordercollection_Occassion;
                $scope.msgWrite[i] = $rootScope.detail[i].Ordercollection_Remarks;
                $scope.Go[i] = $rootScope.detail[i].done;
                $scope.selectQuantity[i] = $rootScope.detail[i].quantity;

            }
        }
    }

    /**Quantitynumber **/
    $scope.quantity = [{

        value: 1
    }, {
        value: 2
    }, {
        value: 3
    }, {
        value: 4
    }, {
        value: 5
    }, {
        value: 6
    }, {
        value: 7
    }, {
        value: 8
    }, {
        value: 9
    }, {
        value: 10
    }];



    /* Grand total for all selected items */
    function calculateTotalSum() {
        var totalSum = 0;
        for (var selectedCake in $rootScope.detail) {
            var data = $rootScope.detail[selectedCake];
            console.log(data.total_amt);
            totalSum += ((data.total_amt) * parseInt(data.quantity));
            if (data.accessories_total_amt != undefined) {
                totalSum += data.accessories_total_amt;
            }
        }

        $rootScope.grand_total = $scope.grand_total_amt = totalSum;
    };

    /*
     * if given group is the selected group, deselect it
     * else, select the given group
     */
    $scope.toggleGroup = function(group) {
        if ($scope.isGroupShown(group)) {
            $scope.shownGroup = null;
        } else {
            $scope.shownGroup = group;
        }
    };

    /* */
    $scope.isGroupShown = function(group) {
        return $scope.shownGroup === group;
    };

    /* Quantity change event */
    /**Quantity Modal **/



    $ionicModal.fromTemplateUrl('my-quantityModal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modalQt = modal;

    });

    $scope.closeModalQt = function() {
        $scope.modalQt.hide();
        $scope.$on('$destroy', function() {
            $scope.modalQt.remove();
        });

    };


    $scope.chooseQuantity = function(index) {
        $scope.qty = [];

        selectedIndex = index;
        showQty = $scope.selectQuantity[index];
        console.log(showQty);

        if (showQty == undefined) {
            $scope.qty[0] = true;
        } else {
            for (var i = 0 in $scope.quantity) {
                if ($scope.quantity[i].value == showQty) {
                    $scope.qty[i] = true;
                    //$("#qty" + i).attr('checked', true);
                    break;
                }
            }
        }

        $scope.modalQt.show();
    };



    $scope.quantity_changeEvent = function(quantityVal) {

        $rootScope.detail[selectedIndex].quantity = quantityVal;
        $scope.selectQuantity[selectedIndex] = quantityVal;

        $('#select' + selectedIndex).hide();
        $('#select-again' + selectedIndex).show();
        calculateTotalSum();
        $scope.modalQt.hide();
        $scope.$on('$destroy', function() {
            $scope.modalQt.remove();
        });
    }

    var price;
    var selected = 1;
    $scope.new_price;
    // if ($scope.cakeCart.total_amt) {
    //     $scope.grand_total_amt = $.data.total_amt;
    // } else {
    $scope.grand_total_amt = 0;
    // }

    $scope.backeryname = $rootScope.name;

    $scope.close = function(index, amount) {

        $rootScope.detail.splice(index, 1);
        $scope.selectQuantity.splice(index, 1);
        $scope.dateShow.splice(index, 1);
        $scope.timeShow.splice(index, 1);
        $scope.catShow.splice(index, 1);
        $scope.msgWrite.splice(index, 1);
        if ($rootScope.detail.length == 0) {
            $scope.nocontent = true;
            $scope.footer = false;
        } else {
            $scope.nocontent = false;
            $scope.maincart = true;
            $scope.footer = true;
        }
        calculateTotalSum();
    }





    $scope.done = function(selectedIndex, type_id) {

        selectedIndex = selectedIndex;
        typeId = type_id;
        if (typeId == 1) {
            $rootScope.detail[selectedIndex].Ordercollection_Remarks = $scope.msgWrite[selectedIndex];
            if ($rootScope.detail[selectedIndex].Ordercollection_Date && $rootScope.detail[selectedIndex].Ordercollection_Occassion) {

                if ($scope.reloadShow[selectedIndex] == true) {
                    $('#chooseCat' + selectedIndex).hide();
                    $('#done' + selectedIndex).hide();
                } else {
                    $('#show' + selectedIndex).show();
                    $('#chooseCat' + selectedIndex).hide();
                    $('#done' + selectedIndex).hide();
                }
                $scope.Go[selectedIndex] = true;
                $rootScope.detail[selectedIndex].done = true;
            } else {
                if (!$rootScope.detail[selectedIndex].Ordercollection_Date) {
                    $cordovaToast
                        .show("Please select Date & Time ", 'short', 'center')
                        .then(function(success) {


                        }, function(error) {


                        });
                } else if (!$rootScope.detail[selectedIndex].Ordercollection_Occassion) {
                    $cordovaToast
                        .show("Please select  Occasion", 'short', 'center')
                        .then(function(success) {

                        }, function(error) {

                        });
                }
            }
        } else {
            $rootScope.detail[selectedIndex].Ordercollection_Remarks = $scope.msgWriteDel[selectedIndex];
            if ($rootScope.detail[selectedIndex].Ordercollection_Date && $rootScope.detail[selectedIndex].Ordercollection_Occassion) {
                if ($scope.reloadDelShow[selectedIndex] == true) {
                    $('#chooseDel' + selectedIndex).hide();
                    $('#chooseDel2' + selectedIndex).hide();
                    $('#msgDel' + selectedIndex).hide();
                    $('#chooseDel3' + selectedIndex).hide();
                    $('#doneDel' + selectedIndex).hide();
                    $('#delDetail' + selectedIndex).hide();
                    $('#hideDel' + selectedIndex).hide();
                    $('#hideDelImg' + selectedIndex).hide();
                } else {
                    $('#chooseDel' + selectedIndex).hide();
                    $('#chooseDel2' + selectedIndex).hide();
                    $('#msgDel' + selectedIndex).hide();
                    $('#chooseDel3' + selectedIndex).hide();
                    $('#doneDel' + selectedIndex).hide();
                    $('#delDetail' + selectedIndex).hide();
                    $('#hideDel' + selectedIndex).hide();
                    $('#hideDelImg' + selectedIndex).hide();
                    $('#showDel' + selectedIndex).show();
                }

                $scope.Go[selectedIndex] = true;
                // $rootScope.Go[selectedIndex] = true;
                $rootScope.detail[selectedIndex].done = true;
            } else {
                if (!$rootScope.detail[selectedIndex].Ordercollection_Date) {
                    $cordovaToast
                        .show("Please select Date & Time ", 'short', 'center')
                        .then(function(success) {

                        }, function(error) {

                        });
                } else if (!$rootScope.detail[selectedIndex].Ordercollection_Occassion) {
                    $cordovaToast
                        .show("Please select  Occasion", 'short', 'center')
                        .then(function(success) {

                        }, function(error) {

                        });
                }
            }
        }


    };


    $scope.checkout_click = function() {
        if ($cordovaNetwork.isOnline()) {
            $scope.notCompleted = false;

            if ($rootScope.detail) {
                for (var i in $rootScope.detail) {
                    if ($rootScope.detail[i].CollectionMode == 1) {
                        $rootScope.detail[selectedIndex].Ordercollection_Remarks = $scope.msgWrite[selectedIndex];
                    }

                    if ($scope.timeShow[i] == undefined || $scope.dateShowOnView[i] == undefined || $scope.catShow[i] == undefined) {
                        console.log($scope.timeShow[i]);
                        console.log($scope.catShow[i]);
                        var elem = parseInt($('#chooseCat' + i).parent()[0].offsetTop);
                        $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, elem, true);
                        if ($scope.dateShowOnView[i] == undefined) {
                            $('#date' + i).addClass('error-border');
                        } else {
                            $('#date' + i).removeClass('error-border');
                        }
                        if ($scope.timeShow[i] == undefined) {
                            $('#time' + i).addClass('error-border');
                        } else {
                            $('#time' + i).removeClass('error-border');
                        }
                        if ($scope.catShow[i] == undefined) {
                            $('#occassion' + i).addClass('error-border');
                        } else {
                            $('#occassion' + i).removeClass('error-border');
                        }
                        $cordovaToast
                            .show("Please fill collection details before proceed", 'short', 'center')
                            .then(function(success) {

                            }, function(error) {

                            });

                        $scope.notCompleted = true;
                        break;
                    }
                    // else if ($scope.timeDelShow[i] == undefined || $scope.dateDelShowOnView[i] == undefined || $scope.catDelShow[i] == undefined) {
                    //     var elem = parseInt($('#chooseCat' + i).parent()[0].offsetTop);
                    //     $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, elem, true);
                    //     if ($scope.dateShowOnView[i] == undefined) {
                    //         $('#datedel' + i).addClass('error-border');
                    //     } else {
                    //         $('#date' + i).removeClass('error-border');
                    //     }
                    //     if ($scope.timeShow[i] == undefined) {
                    //         $('#timedel' + i).addClass('error-border');
                    //     } else {
                    //         $('#time' + i).removeClass('error-border');
                    //     }
                    //     if ($scope.catShow[i] == undefined) {
                    //         $('#occassiondel' + i).addClass('error-border');
                    //     } else {
                    //         $('#occassion' + i).removeClass('error-border');
                    //     }
                    //     $cordovaToast
                    //         .show("Please fill delivery details before proceed", 'short', 'center')
                    //         .then(function(success) {

                    //         }, function(error) {

                    //         });

                    //     $scope.notCompleted = true;
                    //     break;
                    // } else {

                    // }
                }

            } else if ($rootScope.detail[selectedIndex].CollectionMode != undefined) {
                for (var i in $rootScope.detail) {
                    if ($rootScope.detail[i].CollectionMode == 1) {
                        $rootScope.detail[i].deliverAddress = undefined;
                        $rootScope.detail[i].Ordercollection_Remarks = $scope.msgWrite[i];
                        $rootScope.detail[i].done = true;
                        if ($rootScope.detail[i].Ordercollection_Date == undefined || $rootScope.detail[i].Ordercollection_Date == '') {
                            if ($scope.dateShowOnView[i] == undefined) {
                                $('#date' + i).addClass('error-border');
                            } else {
                                $('#time' + i).addClass('error-border');
                            }

                            $cordovaToast
                                .show("Please select Date & Time", 'short', 'center')
                                .then(function(success) {

                                }, function(error) {

                                });
                            $scope.notCompleted = true;
                            break;

                        }
                        if ($rootScope.detail[i].Ordercollection_Occassion == undefined || $rootScope.detail[i].Ordercollection_Occassion == '') {

                            $('#occasion' + i).addClass('error-border');
                            $cordovaToast
                                .show("Please select occasion", 'short', 'center')
                                .then(function(success) {

                                }, function(error) {

                                });
                            $scope.notCompleted = true;
                            break;
                        }
                    } else {
                        if ($rootScope.detail[i].CollectionMode == 2 && $rootScope.detail[i].collection.isDelivery == true) {
                            $rootScope.detail[i].Ordercollection_Remarks = $scope.msgWrite[i];
                            $rootScope.detail[i].done = true;
                            if ($rootScope.detail[i].Ordercollection_Date == undefined || $rootScope.detail[i].Ordercollection_Date == '') {
                                $cordovaToast
                                    .show("Please select  Date & Time", 'short', 'center')
                                    .then(function(success) {

                                    }, function(error) {

                                    });
                                $scope.notCompleted = true;
                                break;
                            }
                            if ($rootScope.detail[i].Ordercollection_Occassion == undefined || $rootScope.detail[i].Ordercollection_Occassion == '') {
                                $cordovaToast
                                    .show("Please select  occasion", 'short', 'center')
                                    .then(function(success) {

                                    }, function(error) {

                                    });
                                $scope.notCompleted = true;
                                break;
                            }
                            $scope.delAddressObj = {};
                            if ($scope.fname[i] == undefined || $scope.fname[i].length == 0) {
                                $cordovaToast
                                    .show("Please select first name", 'short', 'center')
                                    .then(function(success) {

                                    }, function(error) {

                                    });
                                $scope.notCompleted = true;
                                break;
                            } else {
                                $scope.delAddressObj.fname = $scope.fname[i];
                            }
                            if ($scope.lname[i] == undefined || $scope.lname[i].length == 0) {
                                $cordovaToast
                                    .show("Please select last name", 'short', 'center')
                                    .then(function(success) {

                                    }, function(error) {

                                    });
                                $scope.notCompleted = true;
                                break;
                            } else {
                                $scope.delAddressObj.lname = $scope.lname[i];
                            }
                            if ($scope.city[i] == undefined || $scope.city[i].length == 0) {
                                $cordovaToast
                                    .show("Please select city", 'short', 'center')
                                    .then(function(success) {

                                    }, function(error) {

                                    });
                                $scope.notCompleted = true;
                                break;
                            } else {
                                $scope.delAddressObj.city = $scope.city[i];
                            }
                            if ($scope.state[i] == undefined || $scope.state[i].length == 0) {
                                $cordovaToast
                                    .show("Please select state", 'short', 'center')
                                    .then(function(success) {

                                    }, function(error) {

                                    });
                                $scope.notCompleted = true;
                                break;
                            } else {
                                $scope.delAddressObj.county = $scope.state[i];
                            }

                            if ($scope.country[i] == undefined || $scope.country[i].length == 0) {
                                $cordovaToast
                                    .show("Please select country", 'short', 'center')
                                    .then(function(success) {

                                    }, function(error) {

                                    });
                                $scope.notCompleted = true;
                                break;
                            } else {
                                $scope.delAddressObj.country = $scope.country[i];
                            }
                            if ($scope.emailid[i] == undefined || $scope.emailid[i].length == 0) {
                                $cordovaToast
                                    .show("Please select Email Id", 'short', 'center')
                                    .then(function(success) {

                                    }, function(error) {

                                    });
                                $scope.notCompleted = true;
                                break;
                            } else {
                                $scope.delAddressObj.emailid = $scope.emailid[i];
                            }
                            if ($scope.contact[i] == undefined || $scope.contact[i].length == 0) {
                                $cordovaToast
                                    .show("Please select contact", 'short', 'center')
                                    .then(function(success) {

                                    }, function(error) {

                                    });
                                $scope.notCompleted = true;
                                break;
                            } else {
                                $scope.delAddressObj.contact = $scope.contact[i];
                            }

                            if ($scope.address[i] == undefined || $scope.address[i].length == 0) {
                                $cordovaToast
                                    .show("Please select address", 'short', 'center')
                                    .then(function(success) {

                                    }, function(error) {

                                    });
                                $scope.notCompleted = true;
                                break;
                            } else {
                                $scope.delAddressObj.address = $scope.address[i];
                            }
                            if ($scope.passcode[i] == undefined || $scope.passcode[i].length == 0) {
                                $cordovaToast
                                    .show("Please select zip code", 'short', 'center')
                                    .then(function(success) {

                                    }, function(error) {

                                    });
                                $scope.notCompleted = true;
                                break;
                            } else {
                                $scope.delAddressObj.passcode = $scope.passcode[i];
                            }
                            $rootScope.detail[i].deliverAddress = $scope.delAddressObj;

                        }
                    }

                }
            } else {
                // $scope.notCompleted = true;
                // $cordovaToast
                //     .show("Please choose option", 'short', 'center')
                //     .then(function(success) {

                //     }, function(error) {

                //     });


            }


            if ($scope.notCompleted != true) {
                $state.go("app.checkout");

            }
        } else {

            $cordovaToast.showLongCenter("No internet connection!");
        }
    };
    //change
    $scope.continue_click = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.searchbusiness");
        }
    };


    $scope.isDateSelected = false;

    $scope.selected = function(selectedvalue, Market_Price) {
        $scope.selectedvalue = selectedvalue;
        $scope.new_price = ($scope.selectedvalue * Market_Price);

    };

    $scope.total = function() {
            var total = 0;
            angular.forEach($scope.cartItems, function(item) {
                total += $scope.selectedvalue * item.Market_Price;
            })

            return total;
        }
        //chnage
    $scope.continuebtn = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $rootScope.isEdit = false;
                $rootScope.cakeEditIndex = undefined;
                $state.go("app.searchbusiness");
            }
        }
        /** Modal**/




    /**Time Modal**/

    $ionicModal.fromTemplateUrl('my-timeModal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modal = modal;
    });


    function convertToJSONDate(strDate) {
        var dt = new Date(strDate);
        var newDate = new Date(Date.UTC(dt.getFullYear(), dt.getMonth(), dt.getDate(), dt.getHours(), dt.getMinutes(), dt.getSeconds(), dt.getMilliseconds()));
        return '/Date(' + newDate.getTime() + ')/';
    }

    $scope.chooseTime = function(index, type_id) {
        $scope.time = [];
        selectedIndex = index;
        typeId = type_id;
        if ($scope.dateShowOnView[index] == undefined || $scope.dateShowOnView[index] == null || $scope.dateShowOnView[index] == "") {
            $cordovaToast
                .show("Please select collection date first", 'short', 'center')
                .then(function(success) {

                }, function(error) {

                });
        } else if ($scope.timings.length == 0) {
            $cordovaToast
                .show("Please select different date", 'short', 'center')
                .then(function(success) {

                }, function(error) {

                });
        } else {
            showTime = $scope.timeShow[index];

            if (showTime == undefined) {
                $scope.time[0] = true;

            } else {
                for (var i = 0 in $scope.timings) {
                    if ($scope.timings[i].label == showTime) {
                        $scope.time[i] = true;
                        //$("#qty" + i).attr('checked', true);
                        break;
                    }
                }
            }
            $scope.modal.show();

        }
    };

    // $localStorage.cakeID 
    $scope.getSelTime = function(time) {

        if (typeId == 1) {
            $rootScope.detail[selectedIndex].CollectionMode = 1;
            $scope.timeShow[selectedIndex] = time;
            var date = convertToJSONDate($scope.dateShow[selectedIndex]);
            $rootScope.detail[selectedIndex].date = $scope.dateShowOnView[selectedIndex];
            $rootScope.detail[selectedIndex].time = $scope.timeShow[selectedIndex];
            $rootScope.detail[selectedIndex].Ordercollection_Date = $scope.dateShow[selectedIndex] + "T" + $scope.timeShow[selectedIndex] + ":00";
            $('#time' + selectedIndex).removeClass('error-border');
        } else {
            $scope.timeDelShow[selectedIndex] = time;
            var date = convertToJSONDate($scope.dateDelShow[selectedIndex]);
            $rootScope.detail[selectedIndex].date = $scope.dateDelShowOnView[selectedIndex];
            $rootScope.detail[selectedIndex].time = $scope.timeDelShow[selectedIndex];
            $rootScope.detail[selectedIndex].Ordercollection_Date = $scope.dateDelShow[selectedIndex] + "T" + $scope.timeDelShow[selectedIndex] + ":00";
            $('#timedel' + selectedIndex).removeClass('error-border');
        }
        $scope.modal.hide();

    };

    $scope.closeModal = function() {
        $scope.modal.hide();
    };

    /**category Modal**/

    $ionicModal.fromTemplateUrl('my-catModal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modal_cat = modal;
    });

    $scope.chooseCategory = function(index, type_id) {
        $scope.cat = [];
        selectedIndex = index;
        typeId = type_id;
        if ($scope.categories.length == 0) {
            $cordovaToast
                .show("Please select date first", 'short', 'center')
                .then(function(success) {

                }, function(error) {

                });
        } else {
            showCat = $scope.catShow[index];
            console.log(showCat);
            if (showCat == undefined) {
                $scope.cat[0] = true;
                //$scope.$apply();
            } else {
                for (var i = 0 in $scope.categories) {
                    if ($scope.categories[i].CategoryName == showCat) {
                        $scope.cat[i] = true;
                        //$scope.$apply();
                        break;
                    }
                }
            }
            $scope.modal_cat.show();
        }
    };

    $scope.closeCatModal = function() {
        $scope.modal_cat.hide()
    };

    $scope.getSelCat = function(cat) {

        if (typeId == 1) {
            $rootScope.detail[selectedIndex].CollectionMode = 1;
            $scope.catShow[selectedIndex] = cat;
            $rootScope.detail[selectedIndex].Ordercollection_Occassion = $scope.catShow[selectedIndex];
            $('#occassion' + selectedIndex).removeClass('error-border');
        } else {
            $scope.catDelShow[selectedIndex] = cat;
            $rootScope.detail[selectedIndex].Ordercollection_Occassion = $scope.catDelShow[selectedIndex];
            $('#occassiondel' + selectedIndex).removeClass('error-border');
        }
        $scope.modal_cat.hide();
    };



    /*Date Picker **/

    var datePickerObj = {};


    $scope.callDatePicker = function(index, type_id) {
        var startSpecialTime;
        var endSpecialTime;
        selectedIndex = index;
        typeId = type_id;
        var datesTobeDisabled = (parseInt($rootScope.detail[index].cakedetails.Preparationday) * 1000 * 60 * 60 * 24);
        console.log(datesTobeDisabled);
        // var currentTime = newDate().getHours();
        // if(currentTime<$rootScope.detail[index].storeTimings)
        var date = new Date();
        var dateFrom = new Date(date.getTime() + datesTobeDisabled);
        var dateTo = new Date(date.getTime() + 1000 * 60 * 60 * 24 * 365);
        var datePickerObj = {
            inputDate: dateFrom,
            titleLabel: 'Select a Date',
            setLabel: 'Set',
            closeLabel: 'Close',
            mondayFirst: true,
            weeksList: ["S", "M", "T", "W", "T", "F", "S"],
            monthsList: ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"],
            templateType: 'popup',
            from: dateFrom,
            to: dateTo,
            showTodayButton: false,
            dateFormat: 'MMMM dd  yyyy',
            closeOnSelect: false,
            disableWeekdays: $rootScope.detail[selectedIndex].storeClosedDays, //storeClosedDays
            disabledDates: $rootScope.detail[selectedIndex].storeClosedSpecialDays,
            callback: function(val) { //Mandatory
                if (!val) {
                    $cordovaToast
                        .show("Choose Collection Date First!", 'short', 'center')
                        .then(function(success) {

                        }, function(error) {

                        });
                } else {

                    var date = new Date(val);
                    var isSpecialDay = false;
                    $scope.inputDate = val;
                    var currentDateCheck, day;
                    var selectedDate = date;
                    $scope.date = date;
                    $scope.datepicker = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate();

                    for (var i in $rootScope.detail[selectedIndex].storeSpecialTimings) {
                        if (new Date($scope.datepicker) == $rootScope.detail[selectedIndex].storeSpecialTimings[i].date) {
                            startSpecialTime = $rootScope.detail[selectedIndex].storeSpecialTimings[i].opentime;
                            endSpecialTime = $rootScope.detail[selectedIndex].storeSpecialTimings[i].closetime;
                            isSpecialDay = true;
                            break;
                        }
                    };

                    var date_show = date.getDate();
                    if (date_show < 10) {
                        date_show = "0" + date_show;
                    }
                    var month_show = (date.getMonth() + 1);
                    if (month_show < 10) {
                        month_show = "0" + month_show;
                    }
                    $scope.datepickerShow = date_show + '-' + month_show + '-' + date.getFullYear();
                    day = selectedDate.getDay() + 1;

                    // CurrentDate issue
                    var todayDate = new Date();
                    // var currentHours = todayDate.getHours();
                    // for (var k in $rootScope.detail[selectedIndex].storeTimings) {
                    //     if (day == $rootScope.detail[selectedIndex].storeTimings[k].webstoreTiming_dayid) {
                    //         if (currentHours >= $rootScope.detail[selectedIndex].storeTimings[k].webstoreTiming_to) {
                    //             $cordovaToast.show("bakery has been closed now", 'short', 'center')
                    //                 .then(function(success) {

                    //                 }, function(error) {

                    //                 });

                    //         }
                    //     }
                    // }

                    if (selectedDate.setHours(0, 0, 0, 0) == todayDate.setHours(0, 0, 0, 0)) {
                        currentDateCheck = true;
                    } else {
                        currentDateCheck = false;
                    }
                    $scope.isDateSelected = true;

                    if (typeId == 1) {

                        $scope.dateShow[selectedIndex] = $scope.datepicker;
                        $scope.dateShowOnView[selectedIndex] = $scope.datepickerShow;
                        $("#date" + index).removeClass('error-border');

                    } else {

                        $scope.dateDelShow[selectedIndex] = $scope.datepicker;
                        $scope.dateDelShowShowOnView[selectedIndex] = $scope.datepickerShow;
                        $("#datedel" + index).removeClass('error-border');
                    }
                    if (isSpecialDay == true) {
                        getSpecialDaysTimings(currentDateCheck, startSpecialTime, endSpecialTime, selectedIndex);
                    } else {
                        getStoreTimings(currentDateCheck, day, selectedIndex);
                    }

                }
            }
        };

        ionicDatePicker.openDatePicker(datePickerObj);
    };



    /**Cake Detail Modal**/

    $scope.showModalDetail = function(shape, type, size, object, accessoriesObject, accessoryCost, imageurl) {
        console.log(shape);
        console.log(type);
        console.log(size);
        console.log(object);
        console.log(accessoriesObject);
        $scope.imageUpload = imageurl;
        console.log(imageurl);
        $scope.shape = shape;
        $scope.type = type;
        $scope.size = size;
        //check 
        // for (var i = 0; i < object.cakeOptions.length; i++) {
        //     console.log(object.cakeOptions[i]);
        //     if (object.cakeOptions[i].shortname == 'You can also upload an image') {
        //         object.cakeOptions[i].shortname = null;
        //     }
        // }
        $scope.cakeOptions = object.cakeOptions;

        $scope.accessoriesObj = accessoriesObject;
        console.log($scope.accessoriesObj);
        if (accessoryCost == 0) {
            console.log('array');
            $scope.isAccessory = false;
        } else {
            $scope.isAccessory = true;
        }
        console.log($scope.cakeOptions);
        $ionicModal.fromTemplateUrl('templates/cartViewDetailModal.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal) {
            $scope.modal2 = modal;
            $scope.modal2.show();
        });

    };

    $scope.closeModal2 = function() {
        $scope.modal2.hide();
        $scope.isAccessory = false;

    };


    function getSpecialDaysTimings(isCurrentDate, startTime, endTime, index) {

        if (isCurrentDate) {
            var currentHr = new Date().getHours();
            var currentMin = new Date().getMinutes();
            if (currentMin > 0) {
                currentHr = currentHr + 1;
            }
            if (currentHr < startTime) {
                startTime = startTime + 2;
            } else {
                currentHr = currentHr + 2;
                startTime = currentHr;
            }
            if (startTime >= endTime) {
                $scope.showError = true;
                $scope.errorMsg = "Can't collect cakes on current date";
            } else {
                var j = 0;
                $scope.showError = false; //for making index
                for (var i = startTime; i <= endTime; i++) {
                    $scope.timings.push({ id: j, label: (i < 10 ? ("0" + i + ":00") : (i + ":00")) });
                    j++;
                }
            }
        } else {
            var j = 0;
            $scope.showError = false; //for making index
            for (var i = startTime; i <= endTime; i++) {
                $scope.timings.push({ id: j, label: (i < 10 ? ("0" + i + ":00") : (i + ":00")) });
                j++;
            }
        }
    }

    function getStoreTimings(isCurrentDate, dayInInt, selectedIndex) {
        if ((dayInInt + 6) % 7 == 0) {
            dayInInt = 7;
        } else {
            dayInInt = (dayInInt + 6) % 7;
        }
        while ($scope.timings.length > 0) {
            $scope.timings.pop();
        }
        var storeTimings = $rootScope.detail[selectedIndex].storeTimings;
        var result = $.grep(storeTimings, function(e) {
            return e.webstoreTiming_dayid === dayInInt;
        });

        if (result.length != 0) {
            if (!result[0].webstoreTiming_isclosed) {
                var startTime = result[0].webstoreTiming_from;
                var endTime = result[0].webstoreTiming_to;
                if (isCurrentDate) {
                    var currentHr = new Date().getHours();
                    var currentMin = new Date().getMinutes();
                    if (currentMin > 0) {
                        currentHr = currentHr + 1;
                    }
                    if (currentHr < startTime) {
                        startTime = startTime + 2;
                    } else {
                        currentHr = currentHr + 2;
                        startTime = currentHr;
                    }
                    if (startTime >= endTime) {
                        $scope.showError = true;
                        $scope.errorMsg = "Can't collect cakes on current date";
                    } else {
                        var j = 0;
                        $scope.showError = false; //for making index
                        for (var i = startTime; i <= endTime; i++) {
                            $scope.timings.push({ id: j, label: (i < 10 ? ("0" + i + ":00") : (i + ":00")) });
                            j++;
                        }
                    }
                } else {
                    var j = 0;
                    $scope.showError = false; //for making index
                    for (var i = startTime; i <= endTime; i++) {
                        $scope.timings.push({ id: j, label: (i < 10 ? ("0" + i + ":00") : (i + ":00")) });
                        j++;
                    }
                }
            } else {
                $scope.showError = true;
                $scope.errorMsg = "Bakery is closed for selected date, Please choose other date";
            }
        }

        $scope.modalView = true;
    }



    $scope.catOpen = function(selectedIndex, type_id) {
        $rootScope.detail[selectedIndex].CollectionMode = type_id;

        if ($rootScope.detail[selectedIndex].date) {
            reloadContent();
        };

        $('#chooseDel' + selectedIndex).hide();
        $('#chooseDel2' + selectedIndex).hide();
        $('#chooseDel3' + selectedIndex).hide();
        $('#delDetail' + selectedIndex).hide();
        $('#doneDel' + selectedIndex).hide();
        $('#msgDel' + selectedIndex).hide();
        $('#chooseCat' + selectedIndex).show();
        $('#done' + selectedIndex).show();

    }

    $scope.delOpen = function(selectedIndex, type_id, check, item) {
        typeId = type_id;
        if ($rootScope.detail[selectedIndex].date) {
            reloadContent();
        };

        if (check == true) {
            $('#chooseCat' + selectedIndex).hide();
            $('#done' + selectedIndex).hide();
            $('#chooseDel' + selectedIndex).show();
            $rootScope.detail[selectedIndex].CollectionMode = type_id;
        } else {
            // $('#chooseCat' + selectedIndex).hide();
            // $('#done' + selectedIndex).hide();
            $cordovaToast.show("Sorry for inconvenience!!! We can not offer delivery for this item at this moment.", 'short', 'center')
                .then(function(success) {
                    $('#chk_c_' + selectedIndex).attr('checked', true);
                }, function(error) {

                });


            $rootScope.detail[selectedIndex].CollectionMode = type_id;
        }
    }

    $scope.editPasscode = function(selectedIndex, type_id, cake_id) {

        if ($scope.passcode[selectedIndex] == undefined || $scope.passcode[selectedIndex] == '') {
            $cordovaToast
                .show("Please fill passcode", 'short', 'center')
                .then(function(success) {

                }, function(error) {

                });
            $scope.change = false;
        } else {
            apiTimeout();
            IsDeliverableToUserPostcode.IsDeliverableToUserPostcode($scope.passcode[selectedIndex], cake_id)
                .then(function(response) {

                    var resObject = JSON.parse(response);
                    console.log(resObject);

                    clearTimeout(timer);

                    if (resObject.IsDeliverable == false) {
                        $cordovaToast
                            .show("Try another passcode", 'short', 'center')
                            .then(function(success) {

                            }, function(error) {

                            });
                    } else {
                        if ($rootScope.userdetail.userID) {
                            apiTimeout();
                            GetCustomerDetailByID.GetCustomerDetailByID($rootScope.userdetail.userID)
                                .then(function(response) {

                                    var resObject = JSON.parse(response);
                                    console.log(resObject);
                                    clearTimeout(timer);


                                    if (resObject.Customer_Detail.customer_Address) {
                                        $scope.address[selectedIndex] = resObject.Customer_Detail.customer_Address;
                                    }
                                    if (resObject.Customer_Detail.customer_Mobile) {
                                        $scope.contact[selectedIndex] = resObject.Customer_Detail.customer_Mobile;
                                    }
                                    if (resObject.Customer_Detail.customer_city) {
                                        $scope.city[selectedIndex] = resObject.Customer_Detail.customer_city;
                                    }
                                    if (resObject.Customer_Detail.customer_state) {
                                        $scope.state[selectedIndex] = resObject.Customer_Detail.customer_state;
                                    }
                                    if (resObject.Customer_Detail.customer_country) {
                                        $scope.country[selectedIndex] = resObject.Customer_Detail.customer_country;
                                    }
                                });
                        }
                        if ($rootScope.userdetail.length != 0) {
                            $scope.fname[selectedIndex] = $rootScope.userdetail.First_Name;
                            $scope.lname[selectedIndex] = $rootScope.userdetail.Last_Name;
                            $scope.emailid[selectedIndex] = $rootScope.userdetail.Email;
                        }
                        $('#chooseDel2' + selectedIndex).show();
                        $('#chooseDel3' + selectedIndex).show();
                        $('#delDetail' + selectedIndex).show();
                    }
                    $scope.change = false;
                });
        }

    };


    $scope.editCake = function(_cakeId, CakeShapeTitle, CakeTypeTitle, cake_size, cakeOptions, editIndex, editText) {
        //for qoutes cake details edit
        console.log(_cakeId);
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if (_cakeId == undefined) {
            $state.go('app.customer_requrments');
        } else {
            $rootScope.mseTextValue = editText.edittext;
            $rootScope.cakeEditIndex = editIndex;
            console.log($rootScope.cakeEditIndex);
            $rootScope.isEdit = true;
            var cakeObjInfo = { 'id': _cakeId };
            $state.go("app.cakedetail", { 'cakeid': cakeObjInfo, 'editTextMes': editText.edittext, 'image': editText.imgURI }, { 'cache': true });
        }

    };

    /* apitimeout*/
    function apiTimeout() {
        clearTimeout(timer);
        timer = setTimeout(function() {
            $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
            $ionicLoading.hide();
        }, delay_time);
    }
});
