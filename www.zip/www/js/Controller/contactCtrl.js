app
    .controller(
        'contactCtrl',
        function($scope, LocalStorage, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $location, $cordovaNetwork,
            $ionicSideMenuDelegate, LocalStore, $window, $ionicPlatform, $ionicModal,
            $q, $http, $ionicLoading, $ionicModal, $cordovaNetwork, $cordovaToast) {
            $ionicSideMenuDelegate.canDragContent(false);
            $scope.data = {};
            $scope.searchmiles = [{ title: "General Question", value: "1" }, { title: "Technical Questions", value: "2" }, {
                title: "Order Status/Tracking#?",
                value: "3"
            }, { title: "Shipping Discrepancies", value: "4" }, { title: "Submit Repeat Orders", value: "5" }, { title: "Call to take order", value: "6" }, { title: "Request a Quote", value: "7" }, { title: "Items not listed on the website", value: "8" }, { title: "Feedback/Suggestion", value: "9" }];
            $scope.myGoBack = function() {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    window.history.back();
                }
            };
            //change
            $scope.submit = function(data) {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else if (data.fname == '' || data.fname == undefined) {
                    $cordovaToast.showLongBottom('please enter Name');
                } else if (data.company_name == '' || data.company_name == undefined) {
                    $cordovaToast.showLongBottom('Please Enter company_name');
                } else if (data.postcode == '' || data.postcode == undefined) {
                    $cordovaToast.showLongBottom('Please Enter postcode');
                } else if (data.mobile == '' || data.mobile == undefined) {
                    $cordovaToast.showLongBottom('Please Enter Contact Details');
                } else if (data.email == '' || data.email == undefined) {

                    $cordovaToast.showLongBottom('Please Enter Email');
                } else if (!(/^([\w]+(?:\.[\w]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/.test(data.email))) {

                    $cordovaToast.showLongBottom("Please enter valid Email");
                } else if (data.comments == '' || data.comments == undefined) {

                    $cordovaToast.showLongBottom('Please Enter Comments & Suggestions ');
                } else {
                    console.log("done");

                }

            }

        });