app.controller('faliureCtrl', function($scope, LocalStorage, $state, $timeout, $ionicHistory,
    WebService, $ionicSideMenuDelegate, LocalStore, $window, $ionicModal,
    $q, $http, $ionicPlatform, $ionicLoading, $cordovaNetwork, $cordovaToast, $rootScope) {

    $ionicSideMenuDelegate.canDragContent(false);
    //chnage
    $scope.myGoBack = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.billingaddressconfirm", { 'billAddressObj': $rootScope.billingAddress });
        }
    }

});