app.controller('billingaddressconfirmCtrl', function($scope, $state, $stateParams, $localStorage, $rootScope,
    $cordovaNetwork, PaypalService, AddUpdateCustomerAddress, $ionicSideMenuDelegate, $timeout,
    $ionicLoading, $ionicPlatform, $cordovaToast, $ionicPopup, OrderDetails, $ionicLoading, SaveConfirmedOrderFromJson) {

    var timer;
    var delay_time = $rootScope.timer_delay;

    $ionicPlatform.registerBackButtonAction(function(event) {
        $scope.myGoBack();
    }, 100);


    $scope.$on("$ionicView.afterEnter", function(event, data) {
        $scope.addObj = $state.params.billAddressObj;
        $scope.totalamount = $rootScope.grand_total;
    });

    var selectedoption;
    var payMentCheckBoxValue = 2;
    //var orders = '{"orders":{"Order":[{"CustomerID":1,"BakeryID":31,"TotalPrice":36.0,"TotalPriceWithoutShippingCharges":26.0,"ShippingCharges":10.0,"CustomerName":"Gaurav Bhatt","CustomerEmail":"gaurav82chd@gmail.com","PaymentGatewayName":"paypal","Product_ID":87,"Product_Qty":1,"Size_Price":26.0,"Product_Name":"Red Velvet Cake (a58fab8134)","Product_Image":"http://localhost:22506/CakerStreet/img/commingsoon_cake.jpg","Shape_ID":8,"Shape_Text":"Round","Type_ID":1,"Size_ID":36,"CollectionMode":2,"Ordercollection_Date":"2016-12-30T16:00:00","Ordercollection_Occassion":"Birthday","Ordercollection_Remarks":"Test Remarks","TransactionID":"PAY-83K56535AN6982254","ShippingDetail":{"FirstName":"Gaurav","LastName":"Bhatt","EmailID":"gaurav82chd@gmail.com","Address":"38 Ash Grove","City":"Hounslow","County":"Moddlesex","Country":"United kindom","Zip":"TW5 9DR","Phone":"9872441394"},"OrderAttributes":[{"flavour_type_ID":1,"parent_Att_ID":117,"Att_IDs":"120","data_optionaltext":"","viewType":1,"data_text":"","att_totalPrice":0.0,"attwise_Price":"0","displayOrder":0},{"flavour_type_ID":1,"parent_Att_ID":118,"Att_IDs":"122","data_optionaltext":"","viewType":1,"data_text":"","att_totalPrice":0.0,"attwise_Price":"0","displayOrder":1},{"flavour_type_ID":1,"parent_Att_ID": 75,"Att_IDs":"77", "data_optionaltext": "","viewType":1,"data_text":"","att_totalPrice":0, "attwise_Price":"0","displayOrder":2},{"flavour_type_ID":1,"parent_Att_ID": 78,"Att_IDs":"197","data_optionaltext":"","viewType":1,"data_text":"Text To Put On Cake","att_totalPrice":0,"attwise_Price":"0","displayOrder":3},{"flavour_type_ID":1,"parent_Att_ID":81,"Att_IDs":"","data_optionaltext":"","viewType":3,"data_text":"Would you like to add a message onto the cake?","att_totalPrice":0.0,"attwise_Price":"","displayOrder":4}, {"flavour_type_ID":1,"parent_Att_ID": 201,"Att_IDs":"203","data_optionaltext":"","viewType":1,"data_text": "","att_totalPrice":0,"attwise_Price":"0","displayOrder":5}]}],"BillingDetail":{"FirstName":"Ankusb","LastName":"Thakur","Address":"Sample","EmailID":"abcde@gmail.com","City":"London","County":"London","Country":"united kingdom","Zip":"SW17 9JN","Phone": "0000000000"}}}';
    //change
    $scope.myGoBack = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if ($scope.addObj.deliveryadd_custID == undefined || $scope.addObj.deliveryadd_custID == null && $rootScope.loggedin != true) {
            $state.go("app.billingdetails", { 'addressObj': null });
        } else {
            $state.go('app.shippingdetail');
        }
    };

    $scope.cancel = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $scope.myGoBack();
        }
    };

    function updateAPIAfterPayment(cakesOrderInfoObj) {

        if (internetcheck() == true) {
            apiTimeout();
            SaveConfirmedOrderFromJson.SaveConfirmedOrderFromJson(cakesOrderInfoObj).then(function(response) {
                clearTimeout(timer);
                var responseObj = JSON.parse(response);
                if (responseObj.ErrorID == 0) {
                    $ionicLoading.hide();
                    $state.go('app.thanks');
                    $cordovaToast.showLongBottom("Your order has been registered!");
                } else {
                    $ionicLoading.hide();
                    $state.go('app.faliure');
                }

            }, function(err) {
                clearTimeout(timer);
                $ionicLoading.hide();
                var confirmPopup = $ionicPopup.confirm({
                    template: 'Something went wrong!',
                    cssClass: 'popup_head_cust',
                    scope: $scope,
                    buttons: [{
                        text: 'Try Again!!',
                        onTap: function(e) {
                            $state.go($state.current, {}, { reload: true });
                        }
                    }]
                });

            });
        } else {


        }

    };

    //variable declartion 
    function saveOrder(transactionID) {
        var order = {};
        var ordersArray = [];
        var custId = 0;
        var firstname = $rootScope.billingAddress.deliveryadd_fName;
        var emailid = $rootScope.billingAddress.deliveryadd_Email;

        if ($rootScope.loggedin == true) {
            custId = parseInt($rootScope.userdetail.userID);
            firstname = $rootScope.userdetail.First_Name;
            emailid = $localStorage.userDetails.Email;
        }
        for (var selectedCake in $rootScope.detail) {
            var data = $rootScope.detail[selectedCake];


            var orderchild = {};
            var orderObj = {};
            orderObj.CustomerID = custId; //CustomerID
            orderObj.BakeryID = data.bakerysummary.BakeryID; //BakeryID
            orderObj.TotalPrice = (parseFloat(data.total_amt) + parseFloat(data.collection.ByHandDeliveryPrice)); //TotalPrice
            orderObj.TotalPriceWithoutShippingCharges = (data.total_amt); // Total Price 
            orderObj.ShippingCharges = (data.collection.ByHandDeliveryPrice);
            orderObj.CustomerName = firstname; //CustomerName
            orderObj.CustomerEmail = emailid; //CustomerEmail
            orderObj.PaymentGatewayName = "paypal"; //PaymentGatewayName
            orderObj.Product_ID = data.cakedetails.ProductID; //Product_ID
            orderObj.Product_Qty = data.quantity; //Product_Qty
            orderObj.Size_Price = (data.cakesizeOption.CakePrice); //Size_Price
            orderObj.Product_Name = data.cakedetails.Title; //Product_Name
            orderObj.Product_Image = data.imgs[0].SmallImage; //Product_Image
            orderObj.Shape_ID = data.cakeshape.CakeShapeID; //Shape_ID
            orderObj.Shape_Text = data.cakeshape.CakeShapeTitle; //Shape_Text
            orderObj.Type_ID = data.caketype.CakeTypeID; //Type_ID
            orderObj.Size_ID = data.cakesizeOption.SizeID; //Size_ID
            orderObj.CollectionMode = data.CollectionMode; //Collection mode
            orderObj.Ordercollection_Date = data.Ordercollection_Date; //Ordercollection_Date
            orderObj.Ordercollection_Occassion = data.Ordercollection_Occassion; //Ordercollection_Occassion
            orderObj.Ordercollection_Remarks = (data.Ordercollection_Remarks == undefined ? "" : data.Ordercollection_Remarks); //Ordercollection_Remarks
            orderObj.TransactionID = transactionID; //TransactionID
            var attsArray = [];
            var nextIndexForAccessories = 1;
            for (var i in data.cakeOptions) {
                var attributeObj = {};
                attributeObj.flavour_type_ID = data.cakeOptions[i].flavour_type_id; // flavour_type_ID
                attributeObj.parent_Att_ID = data.cakeOptions[i].flavourID; // parent_Att_ID
                if (data.cakeOptions[i].viewTypeID === 3 || data.cakeOptions[i].viewTypeID === 2) {
                    attributeObj.Att_IDs = ""; // Att_IDs                        
                    attributeObj.data_optionaltext = data.cakeOptions[i].selectedVal; // data_optionaltext
                    attributeObj.viewType = data.cakeOptions[i].viewTypeID; // viewType
                    attributeObj.data_text = data.cakeOptions[i].title; // data_text
                    var num = 0;
                    attributeObj.att_totalPrice = 0; // att_totalPrice
                    attributeObj.attwise_Price = ""; // attwise_Price
                } else {
                    var selectedOption = data.cakeOptions[i].selectedIndex; // Selected Option
                    var selObject = data.cakeOptions[i].options[selectedOption];
                    attributeObj.Att_IDs = selObject.FlavourID.toString(); // Att_IDs                       
                    attributeObj.data_optionaltext = ""; // data_optionaltext
                    attributeObj.viewType = data.cakeOptions[i].viewTypeID; // viewType
                    attributeObj.data_text = ""; // data_text
                    attributeObj.att_totalPrice = parseFloat(selObject.ExtraPrice); // att_totalPrice
                    attributeObj.attwise_Price = selObject.ExtraPrice.toString(); // attwise_Price
                }
                attributeObj.displayOrder = parseInt(i);
                attsArray.push(attributeObj);
                nextIndexForAccessories = i;
            }
            nextIndexForAccessories = parseInt(nextIndexForAccessories) + 1;
            for (var i in data.accessories) {
                for (var a in data.accessories[i].value) {
                    if (data.accessories[i].value[a].selected != undefined) {
                        var accessoriesObj = {};
                        accessoriesObj.flavour_type_ID = 3; // flavour_type_ID
                        accessoriesObj.parent_Att_ID = data.accessories[i].value[a].product_id; // parent_Att_ID
                        accessoriesObj.Att_IDs = 0; // Att_IDs                       
                        accessoriesObj.data_optionaltext = data.accessories[i].value[a].qty; // qty accessories
                        accessoriesObj.viewType = 0; // viewType
                        accessoriesObj.data_text = data.accessories[i].value[a].product_name; // accessory choose name
                        accessoriesObj.att_totalPrice = parseInt(data.accessories[i].value[a].qty) * parseFloat(data.accessories[i].value[a].product_StartingPrice); // total price of selected values
                        accessoriesObj.attwise_Price = data.accessories[i].value[a].product_StartingPrice; // single object price
                        accessoriesObj.displayOrder = parseInt(nextIndexForAccessories);
                        attsArray.push(accessoriesObj);
                        nextIndexForAccessories = parseInt(nextIndexForAccessories) + 1;
                    }
                }

            }

            var delAddress = {};

            if (data.deliverAddress == undefined) {
                // Delivery Address
                /*delAddress.FirstName = firstname; //FirstName
                delAddress.LastName = ""; //LastName
                delAddress.EmailID = emailid; //EmailID
                delAddress.Address = ""; //Address
                delAddress.City = ""; //City
                delAddress.County = ""; //County
                delAddress.Country = ""; //Country
                delAddress.Zip = ""; //Zip
                delAddress.Phone = ""; //Phone*/

                delAddress.FirstName = $rootScope.billingAddress.deliveryadd_fName; //FirstName
                delAddress.LastName = $rootScope.billingAddress.deliveryadd_lName; //LastName
                delAddress.EmailID = $rootScope.billingAddress.deliveryadd_Email; //EmailIDdeliveryadd_address
                delAddress.Address = $rootScope.billingAddress.deliveryadd_address; //Address
                delAddress.City = $rootScope.billingAddress.deliveryadd_city; //City
                delAddress.County = $rootScope.billingAddress.deliveryadd_county; //County
                delAddress.Country = $rootScope.billingAddress.deliveryadd_country; //Country
                delAddress.Zip = $rootScope.billingAddress.deliveryadd_zip; //Zip
                delAddress.Phone = $rootScope.billingAddress.deliveryadd_mobile; //Phone
            } else {
                // Delivery Address
                delAddress.FirstName = data.deliverAddress.fname; //FirstName
                delAddress.LastName = data.deliverAddress.lName; //LastName
                delAddress.EmailID = data.deliverAddress.emailid; //EmailID
                delAddress.Address = data.deliverAddress.address; //Address
                delAddress.City = data.deliverAddress.city; //City
                delAddress.County = data.deliverAddress.county; //County
                delAddress.Country = data.deliverAddress.country; //Country
                delAddress.Zip = data.deliverAddress.passcode; //Zip
                delAddress.Phone = data.deliverAddress.contact; //Phone

            }
            orderObj.ShippingDetail = delAddress;
            orderObj.OrderAttributes = attsArray;
            ordersArray.push(orderObj);
        }

        order.Order = ordersArray;
        /* Orders */

        //var address = $rootScope.address[0];
        /* Billing Details */
        var billingDetails = {};
        billingDetails.FirstName = $rootScope.billingAddress.deliveryadd_fName; //FirstName
        billingDetails.LastName = $rootScope.billingAddress.deliveryadd_lName; //LastName
        billingDetails.EmailID = $rootScope.billingAddress.deliveryadd_Email; //EmailIDdeliveryadd_address
        billingDetails.Address = $rootScope.billingAddress.deliveryadd_address; //Address
        billingDetails.City = $rootScope.billingAddress.deliveryadd_city; //City
        billingDetails.County = $rootScope.billingAddress.deliveryadd_county; //County
        billingDetails.Country = $rootScope.billingAddress.deliveryadd_country; //Country
        billingDetails.Zip = $rootScope.billingAddress.deliveryadd_zip; //Zip
        billingDetails.Phone = $rootScope.billingAddress.deliveryadd_mobile; //Phone
        order.BillingDetail = billingDetails;

        return order;
    };


    $scope.payAmount = function(choice) {
        if ($cordovaNetwork.isOffline()) {
            $ionicLoading.hide();
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            payMentCheckBoxValue = choice;
        }
    };

    $scope.payyNow = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if ($rootScope.grand_total == 0) {
            $cordovaToast.showLongBottom("Amount 0 can not be processed");
            return;
        } else if (payMentCheckBoxValue == 1) {
            PaypalService.initPaymentUI().then(function() {
                PaypalService.makePayment($rootScope.grand_total, "Total Amount").then(function(response) {
                    var transactionid = response.response.id;
                    var obj = saveOrder(transactionid);
                    /* var orders = {};
                     orders.orders = obj;*/
                    $ionicLoading.show({
                        noBackdrop: false,
                        template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                    });
                    $cordovaToast.showLongBottom("Transaction successful!");
                    updateAPIAfterPayment(JSON.stringify(obj));

                }, function(error) {

                    $cordovaToast.showLongBottom("Transaction Canceled");
                    return;
                });

            });
        } else if (payMentCheckBoxValue == 2) {
            $state.go('app.stripayment');
        }
    }

    // cancel click 
    $scope.cancel = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $scope.myGoBack();
            }
        }
        // internet check
    function internetcheck() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
            return false;
        } else {
            return true;
        }
    };

    function apiTimeout() {
        clearTimeout(timer);
        timer = setTimeout(function() {
            $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
            $ionicLoading.hide();
        }, delay_time);
    };

});
