app.controller('allproductsCtrl', function($scope, $stateParams, $state, $timeout, GetBakeriesAndCakesBypostcodeAndMiles, GetCakesByPostcodeAndMiles, $rootScope, $location, $ionicSideMenuDelegate, $window, $ionicPlatform, GetCategories, $timeout, $filter, $ionicHistory,
    $q, $http, $cordovaNetwork, $ionicPlatform, $ionicPopup, $cordovaToast, $ionicPopover, $ionicLoading, $cordovaNetwork, $ionicModal, getbakeryProducts_byBakeryid, $localStorage
) {

    $ionicPlatform.registerBackButtonAction(function(event) {
        $scope.myGoBack();
    }, 100);
    var categoriesid = {};
    var regPostcode = /^([a-zA-Z]){1}([0-9][0-9]|[0-9]|[a-zA-Z][0-9][a-zA-Z]|[a-zA-Z][0-9][0-9]|[a-zA-Z][0-9]){1}([ ])|([0-9][a-zA-z][a-zA-z]){1}$/;
    $ionicSideMenuDelegate.canDragContent(false);
    $scope.noitem = false;
    $scope.itemNotFound = false;
    $scope.numbers = [];
    $scope.productname = "";
    $scope.isdtNameDisabled = true;
    $scope.title = "";
    $scope.list = [];
    var pageno = 1;
    var pagesize = 10;
    var timer;
    var miles = $rootScope.selectedvalue;
    var postalcode = $rootScope.postcode;
    var delay_time = $rootScope.timer_delay;
    $scope.visualCategories = [];
    $scope.titlepostcode = true;
    $scope.editbtn = true;
    $scope.searchoption = false;
    $scope.data = {};
    $scope.data.cakelist = [];
    $scope.data.milesdistance = miles;
    var addMultipleCategoriesid;
    $scope.$on("$ionicView.loaded", function(event, data) {

        var pageno = 1;

    });

    $scope.$on("$ionicView.beforeEnter", function(event, data) {
        $rootScope.sortcode = 0;
        $scope.sortCategoryChoose = "Relevance";
    });

    var IsbakeryProducts = false;
    $scope.$on("$ionicView.enter", function(event, data) {
        $scope.loaderimage = true;
        IsbakeryProducts = false;
        while ($scope.data.cakelist.length > 0) {
            $scope.data.cakelist.pop();
        }
        pageno = 1;
        pagesize = 10;

        if ($state.params.bakeryinfo != null || $state.params.bakeryinfo != undefined) {

            if ($state.params.bakeryinfo != null && $state.params.bakeryinfo.bakeryCount != undefined) {
                $scope.bakery_Count = $state.params.bakeryinfo.bakeryCount;
            } else {
                $scope.bakery_Count = 1;
            }


            if ($localStorage.bakeryInfo !== $state.params.bakeryinfo) {
                if ($state.params.bakeryinfo != null && $state.params.bakeryinfo.bakeryCount != undefined) {
                    $scope.bakery_Count = $state.params.bakeryinfo.bakeryCount;
                } else {
                    $scope.bakery_Count = 1;
                }
                $localStorage.bakeryInfo = $state.params.bakeryinfo;
                if ($localStorage.bakeryInfo.webstore_ID != null) {

                    $scope.bakery_Count = $localStorage.bakeryarray.length;
                    IsbakeryProducts = true;
                         $scope.$watch('online', function(newStatus) { 
                          if(newStatus==false){
                       $scope.loaderimage = false;
                        $cordovaToast.showLongCenter("No internet connection!");
                       }
                       if(newStatus==true){
                         getCakesForBakery(1);
                       }
                        });
                 
                }
            }
        }

        if ($rootScope.cake_catIds != null && IsbakeryProducts == false) {

            $scope.cake_ids = $rootScope.cake_catIds;
            if ($scope.bakery_Count == undefined) {
                //$rootScope.BakeryidObject = $state.params.bakeryinfo;
                if ($state.params.bakeryinfo != null && $state.params.bakeryinfo.bakeryCount != undefined) {
                    $scope.bakery_Count = $state.params.bakeryinfo.bakeryCount;
                } else {
                    $scope.bakery_Count = 1;
                }

            };
               $scope.$watch('online', function(newStatus) { 
                          if(newStatus==false){
                       $scope.loaderimage = false;
                        $cordovaToast.showLongCenter("No internet connection!");
                       }
                       if(newStatus==true){
                        makingAPICallOnactions($rootScope.postcode, $rootScope.selectedvalue, $rootScope.cake_catIds);
                       }
                        });
           
        }

        getCartCount();
    });

    $scope.$on("$ionicView.afterEnter", function(event, data) {

    });

    $scope.myGoBack = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            if ($rootScope.stateName == "app.filter_detail") {
                $state.go("app.filter_detail");
            } else if ($rootScope.stateName == "app.searchbusiness") {
                $state.go("app.searchbusiness");
            } else {

            }
            //$ionicHistory.goBack();
        }
    };

    function getCakesForBakery(pageNo) {

        if (internetcheck()) {
            apiTimeout();
            getbakeryProducts_byBakeryid.getbakeryProducts_byBakeryid(pageNo, pagesize, $localStorage.bakeryInfo.webstore_ID)
                .then(function(response) {
                      $scope.loaderimage = false;
                    clearTimeout(timer);
                    var jsondata = JSON.parse("{" + response + "}");
                    $scope.data.cakeCount = jsondata.data.TotalRows;
                    for (var i = 0; i < jsondata.data.BakeryProducts.length; i++) {
                        var productObj = {};
                        productObj.product_ID = jsondata.data.BakeryProducts[i].id;
                        productObj.product_image1 = jsondata.data.BakeryProducts[i].image_link;
                        productObj.webstore_IsCollectable = $localStorage.bakeryInfo.webstore_IsCollectable;
                        productObj.webstore_IsDeliverable = $localStorage.bakeryInfo.webstore_IsDeliverable;
                        productObj.webstore_city = $localStorage.bakeryInfo.webstore_city;
                        productObj.API_Miles = $localStorage.bakeryInfo.API_Miles;
                        productObj.product_startingtPrice = jsondata.data.BakeryProducts[i].Market_Price;
                        $scope.data.cakelist.push(productObj);
                    };
                    busyInLoading = false;
                }, function(err) {
                    clearTimeout(timer);
                    $ionicLoading.hide();
                    var confirmPopup = $ionicPopup.confirm({
                        template: 'Something went wrong!',
                        cssClass: 'popup_head_cust',
                        scope: $scope,
                        buttons: [{
                            text: 'Try Again!!',
                            onTap: function(e) {
                                $state.go($state.current, {}, { reload: true });
                            }
                        }]
                    });

                });

        } else {
            // error 
        }

    }

    /* Click cake */
    $scope.cakeDetails_ClickHandler = function(cakeID) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                var cakeObjInfo = { 'id': cakeID };
                $state.go("app.cakedetail", { 'cakeid': cakeObjInfo });
            }
        }
        /* Cart click */
    $scope.headerCart_ClickHandler = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if ($rootScope.detail.length == 0) {
            $cordovaToast.showLongBottom("Cart is empty");
        } else {
            $state.go("app.cart");
        }
    };
    /* API section */

    function makingAPICallOnactions(param_postalcode, param_miles, param_catId) {
        if ($scope.data.cakelist != undefined) {
            while ($scope.data.cakelist.length > 0) {
                $scope.data.cakelist.pop();
            }
        }
        $scope.data.cakeCount = 0;
        pageno = 1;
        $scope.noMoreItemsAvailable = false;
        $scope.data.milesdistance = miles = param_miles;
        postalcode = param_postalcode;
        hitAPIForDisplay(param_postalcode, param_miles, param_catId, false);
    }

    function hitAPIForDisplay(param_postcode, param_miles, param_catIds, param_callExternal) {
        $scope.data.milesdistance = miles = param_miles;
        postalcode = param_postcode;
        setTimeout(function() {
            _getcakes(pageno, pagesize, param_postcode, param_miles, param_catIds);
        }, 200);
    }

    function _getcakes(param_pageno, param_cakecount, param_postalcode, param_miles, param_categoryIds) {
        IsbakeryProducts = false;
        if (internetcheck()) {
            apiTimeout();
            //change
            GetCakesByPostcodeAndMiles.GetCakesByPostcodeAndMiles(param_pageno, param_cakecount,
                param_postalcode, param_miles, param_categoryIds, "", $rootScope.sortcode).then(function(response) {
                var responseObject = JSON.parse(response);
                clearTimeout(timer);
                  $scope.loaderimage = false;
                if (responseObject.ErrorID == 0) {

                    if ($scope.data.cakelist === undefined) {
                          $scope.loaderimage = false;
                        $scope.data.cakelist = responseObject.Cakes;
                    } else {
                          $scope.loaderimage = false;
                        $.merge($scope.data.cakelist, responseObject.Cakes);
                    }
                    $scope.data.cakeCount = responseObject.CakeCount;
                      $scope.loaderimage = false;
                    busyInLoading = false;
                    notFound($scope.data.cakeCount == 0 ? true : false);
                } else {
                    // Error from API
                    notFound($scope.data.cakeCount == 0 ? true : false);
                    $scope.loaderimage = false;
                }
                clearTimeout(timer);
            }, function(err) {
                clearTimeout(timer);
                $ionicLoading.hide();
                var confirmPopup = $ionicPopup.confirm({
                    template: 'Something went wrong!',
                    cssClass: 'popup_head_cust',
                    scope: $scope,
                    buttons: [{
                        text: 'Try Again!!',
                        onTap: function(e) {
                            $state.go($state.current, {}, { reload: true });
                        }
                    }]
                });

            });

        } else {
              $scope.loaderimage = false;
            notFound($scope.data.cakeCount == 0 ? true : false);
        }

    }

    function notFound(val) {
        $scope.itemNotFound = val;
    }

    /* Infinite Scroll */
    var busyInLoading = false;
    $scope.loadMore = function() {
        //if($scope.data.cakeCount != undefined){
         if ($cordovaNetwork.isOffline()) {
                $scope.loaderimage = false;
                $cordovaToast.showLongCenter("No internet connection!");
        }
        else{
        if (!busyInLoading) {
            busyInLoading = true;
            if ((parseInt(pageno) * pagesize) < $scope.data.cakeCount) {
                pageno = parseInt(pageno) + 1;
                $scope.loaderimage = true;
                $scope.noMoreItemsAvailable = false;
                if (IsbakeryProducts) {
                    getCakesForBakery(pageno);
                } else {
                    _getcakes(pageno, pagesize, $rootScope.postcode, $rootScope.selectedvalue, $rootScope.cake_catIds);
                }

            } else {
                $scope.loaderimage = false;
                if ($scope.data.cakeCount != undefined)
                    $scope.loaderimage = false;
                $scope.noMoreItemsAvailable = true;
            }
        }
        $scope.$broadcast('scroll.infiniteScrollComplete');
    }
    };
    //timeout
    function apiTimeout() {
        clearTimeout(timer);
        timer = setTimeout(function() {
            $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
            $ionicLoading.hide();
        }, delay_time);
    }

    $scope.handleMoreEvent = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.filter", { 'backery_details': $rootScope.BakeryidObject });
        }
    }

    function getCartCount() {
        if ($rootScope.detail == undefined) {
            $scope.cartnotification = true;
            $scope.count = 0;
        } else if ($rootScope.detail.length == 0) {
            $scope.cartnotification = true;
            $scope.count = 0;
        } else {
            $scope.cartnotification = true;
            $scope.count = $rootScope.detail.length;
        }
    }
    $scope.headerPostalSearch_CloseHandler = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $scope.editCode = false;
                setTimeout(function() {
                    cordova.plugins.Keyboard.close();
                }, 50);
            }
        }
        //modal open
    $scope.milesSelected = 0;
    $scope.miles_clickhandler = function(e) {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $ionicModal.fromTemplateUrl('templates/milesradiobutton.html', {
                scope: $scope,
                animation: 'fade-in-up',
            }).then(function(modal) {
                $scope.modal = modal;
                $scope.modal.show();
            });
        }
    }
    $scope.closeModal = function() {
        $scope.modal.hide();
    };
    $scope.checked = function(selected) {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if ($rootScope.selectedvalue === selected) {
            return;
        } else {
            $scope.updateStatus = true;
            $rootScope.selectedvalue = selected;
            $scope.modal.hide();
            $state.go('app.searchbusiness');
        }
    }


    $scope.businessClick = function() {
         if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            }
            else{
        $state.go("app.filter_detail", {
            'bakeryarray': null
        }, { 'cache': true });
    }
    };

    $scope.headerSearch_ClickHandler = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.searchcriteriapage");
        }
    };

    $scope.headerSearchPostalcode_InputHandler = function(text) {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if (!text) {
            $cordovaToast.showLongCenter("Please Enter Area Code");
            return;
        } else if (regPostcode.test(text) == false) {
            $cordovaToast.showLongBottom('Please Enter valid Postcode');
            return;
        } else if (text.length != 0) {
            $rootScope.postcode = text;
            $localStorage.postcodeSelected = $rootScope.postcode;
            $scope.editCode = false;
            setTimeout(function() {
                cordova.plugins.Keyboard.close();
                $state.go("app.searchbusiness");
            }, 50);

        } else {
            $cordovaToast.showLongBottom("Please enter valid postalcode");
        }
    }

    $scope.headerEditPostalCode_ClickHandler = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $scope.postalText = $rootScope.postcode;
            $scope.editCode = true;
            setTimeout(function() {
                // $('#code').select();
                cordova.plugins.Keyboard.show();
            }, 50);
        }
    };

    // internet check
    function internetcheck() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
            return false;
        } else {
            return true;
        }
    }

    $scope.popover = $ionicPopover.fromTemplate(template, {
        scope: $scope
    });


    $ionicPopover.fromTemplateUrl('sortby-popover.html', {
        scope: $scope
    }).then(function(popover) {
        $scope.popover = popover;
    });


    $scope.openPopover = function($event) {
        $scope.popover.show($event);
    };

    $scope.closePopover = function() {
        $scope.popover.hide();
    };

    $scope.sortingCakes = function(sortValue, sortName) {
        $rootScope.sortcode = sortValue;
        $scope.sortCategoryChoose = sortName;
        $scope.popover.hide();
        $scope.data.cakelist = [];
        _getcakes(pageno, pagesize, $rootScope.postcode, $rootScope.selectedvalue, $rootScope.cake_catIds);
    };

});
