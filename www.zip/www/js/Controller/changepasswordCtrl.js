app
    .controller(
        'changepasswordCtrl',
        function($scope, LocalStorage, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $location,
            $ionicSideMenuDelegate, LocalStore, $window, $ionicPlatform, $ionicModal,
            $q, $http, $cordovaToast, $ionicLoading, $ionicModal, $cordovaNetwork) {
            $ionicSideMenuDelegate.canDragContent(false);
            $scope.data = {};
            //change
            $scope.goBack = function() {
                    if ($cordovaNetwork.isOffline()) {
                        $cordovaToast.showLongCenter("No internet connection!");
                    } else {
                        $state.go("app.home");
                    }
                }
                //change
            $scope.changePassword = function(data) {
                    if ($cordovaNetwork.isOffline()) {
                        $cordovaToast.showLongCenter("No internet connection!");
                    } else if ($scope.data.oPssword == '') {
                        $cordovaToast.showLongBottom('Please Enter Password');
                    } else if ($scope.data.nPssword == '') {
                        $cordovaToast.showLongBottom("Please enter new Password");
                    } else if ($scope.data.cPssword == '') {
                        $cordovaToast.showLongBottom("Please confirm password");
                    } else {
                        $state.go("app.home");
                    }
                }
                // $scope.changePassword = function(data) {
                //     document.addEventListener('deviceready', initApp, false);

            //     // facebookConnectPlugin.login(Array strings of permissions, Function success, Function failure)

            //     var fbLoginSuccess = function(userData) {
            //         alert("UserInfo: " + JSON.stringify(userData));
            //     }

            //     function initApp() {
            //         facebookConnectPlugin.login(["public_profile"],
            //             fbLoginSuccess,
            //             function(error) { alert("" + error) }
            //         );
            //     }

            // }
        });