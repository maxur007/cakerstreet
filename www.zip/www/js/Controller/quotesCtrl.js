app.controller('quotesCtrl', function($scope, LocalStorage, $state, $timeout, $ionicHistory,
    WebService, $rootScope, $location, $filter,
    $ionicSideMenuDelegate, LocalStore, LocalStorage, $window, $ionicPlatform, $ionicModal,
    $q, $http, $ionicPlatform, $ionicLoading, $ionicModal, $cordovaNetwork, $cordovaToast,
    getCustomrequirementList_byCustID, GetCakedetailByCakeID, generateProductbyQuoteID) {

    $ionicPlatform.registerBackButtonAction(function(event) {
        $scope.myGoBack();
    }, 100);

    console.log($rootScope.occ_detail);
    $ionicSideMenuDelegate.canDragContent(false);
    var pageno = 1;
    var pagesize = 10;
    //change
    $scope.newary = [];
    $scope.new_ary = [];
    $scope.data = {};

    console.log($rootScope.detail);
    // $scope.data.cakedetails = [];

    $scope.myGoBack = function() {
        // if ($cordovaNetwork.isOffline()) {
        //     $cordovaToast.showLongCenter("No internet connection!");
        // } else {
        window.history.back();
        // }
    }
    $scope.$on("$ionicView.afterEnter", function(event, data) {

        $ionicLoading.show({
            noBackdrop: false,
            template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
        });
        $scope.noitem = false;
        var customerID = $rootScope.CustomerID;
        console.log(customerID);
        getquotes(pageno);
    });

    function getquotes(pageno) {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            getCustomrequirementList_byCustID.getCustomrequirementList_byCustID($rootScope.CustomerID, pageno, pagesize).then(function(response) {
                console.log(response);
                $scope.header = true;
                console.log(JSON.parse(response));
                $scope.result = JSON.parse(response);
                console.log($scope.result.length);
                $ionicLoading.hide();
                busyInLoading = false;
                if ($scope.result.length == 0) {
                    $scope.noitem = true;
                    $scope.header = false;
                } else {
                    $scope.noitem = false;
                    $scope.header = true;
                    for (let i = 0; i < $scope.result.length; i++) {
                        console.log($scope.result[i].CRF_Images.length);
                        $scope.postcode = $scope.result[i].CRF_Postcode;
                        $scope.name = $scope.result[i].category_Name;
                        for (let j = 0; j < $scope.result[i].CRF_Quotes.length; j++) {
                            console.log($scope.result[i].CRF_Quotes[j]);
                            $scope.newary.push($scope.result[i].CRF_Quotes[j]);
                            console.log($scope.newary);
                            if ($scope.newary.length == 0) {

                            } else {
                                for (let j = 0; j < $scope.newary.length; j++) {
                                    var newm_dates = $scope.newary[j].crfQuote_modifiedOn;
                                    var converted_date = parseInt(newm_dates.substring(newm_dates.lastIndexOf("(") + 1, newm_dates.lastIndexOf(")")));
                                    var date1 = $filter('date')(new Date(converted_date), 'dd-MM-yyyy');
                                    var hour3 = hourwithAMPM(converted_date);
                                    $scope.new_mdate = date1 + '  ' + hour3;
                                    console.log($scope.new_mdate);
                                }
                            }
                        }
                        console.log($scope.result[i].CRF_Quotes.length);
                        // console.log(JSON.parse());
                        // for (let i = 0; i < $scope.result.CRF_Images.length; i++) {
                        //     console.log($scope.result.CRF_Images);
                        // }
                        // for (let i = 0; i < $scope.result.CRF_Quotes.length; i++) {
                        //     console.log($scope.result.CRF_Quotes);
                        // }
                        var create_date = $scope.result[i].CRF_createdOn;
                        var converted_date = parseInt(create_date.substring(create_date.lastIndexOf("(") + 1, create_date.lastIndexOf(")")));
                        var date1 = $filter('date')(new Date(converted_date), 'dd-MM-yyyy');
                        var hour1 = hourwithAMPM(converted_date);
                        $scope.newdate = date1 + ' ' + hour1;
                        console.log($scope.newdate);
                        var date_new = $scope.result[i].CRF_datetime;
                        var converted_date = parseInt(date_new.substring(date_new.lastIndexOf("(") + 1, date_new.lastIndexOf(")")));
                        var date2 = $filter('date')(new Date(converted_date), 'dd-MM-yyyy');
                        var hour2 = hourwithAMPM(converted_date);
                        $scope.newdate_occ = date2 + " " + hour2;
                        $scope.dated_ls = date2 + "T"
                        console.log($scope.newdate_occ);
                    }
                }
            })
        }

    }
    $scope.buynow = function(Quotes) {
        for (let i = 0; i < $scope.result.length; i++) {
            if ($scope.result[i].order_id == Quotes.order_id) {
                var date_new = Quotes.crfQuote_modifiedOn;
                var converted_date = parseInt(date_new.substring(date_new.lastIndexOf("(") + 1, date_new.lastIndexOf(")")));
                var date2 = $filter('date')(new Date(converted_date), 'dd-MM-yyyy');
                var hour2 = hourwithAMPM(converted_date);
                $scope.date_occ = date2;
                console.log($scope.date_occ);
                console.log(hour2);
                $scope.data.date = $scope.date_occ;
                $scope.data.time = hour2;
                console.log(Quotes.crfQuote_ID);
                var QuoteID = Quotes.crfQuote_ID;
                console.log(QuoteID);
                $scope.data.total_amt = Quotes.crfQuote_totalPrice;
                generateProductbyQuoteID.generateProductbyQuoteID(QuoteID).then(function(response) {
                    console.log(response);
                    $scope.res = response;
                    console.log($scope.res);
                    method2($scope.res);
                    console.log($scope.data);
                })
            }
        }
    }

    function method2(pid) {
        console.log(pid);
        GetCakedetailByCakeID.GetCakedetailByCakeID(pid).then(function(response) {
            var resObject = JSON.parse(response);
            $scope.data.accessoriesCount = resObject.CakeDetail.AccessoryCount; //count accessories
            $scope.data.cakedetails = resObject.CakeDetail;
            sharelink = resObject.CakeDetail.WebProductUrl;
            $scope.data.imgs = resObject.ProductImages;
            $scope.data.bakerysummary = resObject.BakerySummary;
            $scope.bakeryId = $scope.data.bakerysummary.BakeryID; //Id of bakery
            $scope.data.cakeshape = resObject.CakeShape;
            $scope.data.caketype = resObject.CakeType;
            $scope.data.collection = resObject.CollectionAndDelivery;
            productId = resObject.CakeDetail.ProductID;
            $scope.data.storeTimings = resObject.WebstoreTiming;
            $scope.data.postcode = $scope.postcode;
            $scope.data.Ordercollection_Occassion = $scope.name;
            $scope.data.Ordercollection_Date = $scope.newdate_occ;
            $scope.data.quantity = 1;
            console.log($scope.data);

            // "imgURI": Quotes.webstore_logo,
            //         "cake_size": $scope.result[i].CRF_Size,
            //         "accessories_total_amt": 0,
            //         "date": date_occ,
            //         "postcode": $scope.result[i].CRF_Postcode,
            //         "time": hour2,
            //         "Ordercollection_Occassion": $scope.result[i].category_Name,
            //         "Ordercollection_Date": $scope.newdate_occ,
            //         "quantity": 1,
            $rootScope.detail = $rootScope.detail.concat($scope.data);
            console.log($rootScope.detail);
            console.log($rootScope.detail.length);
            $state.go('app.cart');
        })
    }

    function hourwithAMPM(dateInput) {
        var d = new Date(dateInput);
        var ampm = (d.getHours() >= 12) ? "PM" : "AM";
        var hours = (d.getHours() >= 12) ? d.getHours() - 12 : d.getHours();
        console.log(hours);
        return hours + ':' + d.getMinutes() + ' ' + ampm;
    }
    // //loadmore 
    // var busyInLoading = false;
    // $scope.loadMore = function() {
    //     if ($cordovaNetwork.isOffline()) {
    //         $scope.loaderimage = false;
    //         $cordovaToast.showLongCenter("No internet connection!");
    //     } else {
    //         if (!busyInLoading) {
    //             busyInLoading = true;

    //             //need variaablw eith total values in api or response
    //             if ((parseInt(pageno) * pagesize) < $scope.re) {
    //                 pageno = parseInt(pageno) + 1;
    //                 $scope.loaderimage = true;
    //                 getquotes(pageno);
    //             } else {
    //                 $scope.loaderimage = false;
    //                 if ($scope.data.cakeCount != undefined)
    //                     $scope.loaderimage = false;
    //             }
    //         }
    //         $scope.$broadcast('scroll.infiniteScrollComplete');
    //     }
    // };



    // function formatDate(date) {
    //     var date = 1507613347;
    //     console.log(date);
    //     var hours = date.getHours();
    //     var minutes = date.getMinutes();
    //     var ampm = hours >= 12 ? 'pm' : 'am';
    //     hours = hours % 12;
    //     hours = hours ? hours : 12; // the hour '0' should be '12'
    //     minutes = minutes < 10 ? '0' + minutes : minutes;
    //     var strTime = hours + ':' + minutes + ' ' + ampm;
    //     $scope.formattedDate = date.getMonth() + 1 + "/" + date.getDate() + "/" + date.getFullYear() + " " + strTime;
    // }

});
