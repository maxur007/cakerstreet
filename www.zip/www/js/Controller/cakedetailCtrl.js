app.controller(
    'cakedetailCtrl',
    function($scope, $state, $stateParams, $timeout, $cordovaCamera, $ionicScrollDelegate, $rootScope, $location, $ionicScrollDelegate, $cordovaSocialSharing,
        $ionicSideMenuDelegate, $localStorage, $window, $q, $http, $ionicLoading, $ionicPlatform, $cordovaNetwork,
        $ionicActionSheet, GetCakeAttributesListByCakeID, $ionicPopup, GetAccessoriesByBakeryID, UploadOrderPicture, $cordovaToast, $ionicModal, $ionicScrollDelegate, $ionicSlideBoxDelegate, $cordovaKeyboard, GetCakedetailByCakeID) {

        window.addEventListener('native.keyboardshow', function() {
            //$ionicScrollDelegate.$getByHandle('toThisPosition').scrollBottom(true);
            //debugger;
            if ($('#scrollDestination').parent()[0] != undefined) {
                var elem = parseInt($('#scrollDestination').parent()[0].offsetTop);
                $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, elem, true);
            }
            $('#testing_footer').addClass('keyboard_footer');
        });

        window.addEventListener('native.keyboardhide', function() {
            //$ionicScrollDelegate.$getByHandle('toThisPosition').scrollBottom(true);
            //debugger;
            $('#testing_footer').removeClass('keyboard_footer');
        });
        $scope.$watch('online', function(newStatus) {

            //  alert(newStatus);
            if (newStatus == false) {
                $scope.internetOff = true;
            }
        });
        $ionicPlatform.registerBackButtonAction(function(event) {
            $scope.myGoBack();
        }, 100);

        $ionicSideMenuDelegate.canDragContent(false);
        //  $scope.data.imgURI = '';
        $scope.showContinue = false;

        var sharelink;

        $scope.data = {
            "date": null,
            "postcode": null,
            "time": null,
            "flag_var": null
        };
        console.log($scope.data);
        $scope.data.cakeOptions = [];
        $scope.data.selectcakesizeoption = 1;
        $scope.accordion = false;
        $scope.showContent = false;
        var pageno = 1;
        var pagesize = 10;
        var selectedIndex;
        $scope.isEdit = false;
        $scope.qty = [];

        var accessoriesCost;

        $rootScope.$on('$stateChangeSuccess', function(ev, to, toParams, from, fromParams) {
            $rootScope.previousState = from.name;
            $rootScope.currentState = to.name;
        });

        var userObj = {};
        var imagebsee64;
        var imagepath;
        var productId;
        var sizeId;
        $scope.optionalText = true;
        $scope.selectQuantity = [];

        var timer;
        var delay_time = $rootScope.timer_delay;


        $scope.$on("$ionicView.beforeEnter", function(event, data) {
            $ionicLoading.show({
                template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
            });
        });

        $scope.$on("$ionicView.afterEnter", function(event, data) {
            $localStorage.cakeOptionsStored = [];

            $scope.data.accessories_total_amt = 0;
            //   $rootScope.isEdit = false;
            $scope.data.total_amt = 0;
            if ($state.params.cakeid != null || $state.params.cakeid != undefined) {
                //if ($localStorage.cakeID !== $state.params.cakeid.id) {
                $scope.showContent = false;
                $localStorage.cakeID = $state.params.cakeid.id;
                $scope.imgURI = '';
                // $scope.data = {};
                $scope.data = {
                    "date": null,
                    "postcode": null,
                    "time": null,
                    "flag_var": null
                };
                $scope.data.cakeId = $localStorage.cakeID;
                $scope.data.selectcakesizeoption = 1;
                $scope.accordion = false;
                $scope.data.cakeOptions = [];

                if ($scope.data.cake_sizelist != undefined) {
                    while ($scope.data.cake_sizelist.length > 0) {
                        $scope.data.cake_sizelist.pop();
                    }
                    $cordovaKeyboard.hideAccessoryBar(true)

                    $cordovaKeyboard.disableScroll(true)

                    $cordovaKeyboard.close()

                    var isVisible = $cordovaKeyboard.isVisible()
                }

                isSizeAPILoadedOnce = false;
                $('#selectedOption').empty();
                $('#selectedOption').append("<div class=\"col\"><img style=\"width: 20px;margin-right: 15px;vertical-align: sub;\"" +
                    "src=\"img/hamburger.png\">Select Cake Size / Portion</div>");

                if ($scope.data.cakeOptions != undefined) {
                    while ($scope.data.cakeOptions.length > 0) {
                        $scope.data.cakeOptions.pop();
                    }
                }

                $scope.textTitle = false;
                $scope.edittext = false;
                $scope.typemessege = false;
                $scope.btnshow = false;
                $scope.imageUpload = false;
                $scope.accordin = false;
                $scope.$watch('online', function(newStatus) {
                    if (newStatus == false) {
                        $cordovaToast.showLongCenter("No internet connection!");
                    }
                    if (newStatus == true) {
                        callAPI($localStorage.cakeID, $state.params.editTextMes, $state.params.image);
                    }
                });

                //  callAPI($localStorage.cakeID,$state.params.editTextMes,$state.params.image);

                //}
            } else {
                callAPI($localStorage.cakeID, $state.params.editTextMes, $state.params.image);
            }

            getCartCount();

        });


        //change
        $scope.myGoBack = function() {
            $rootScope.isEdit = false;
            $rootScope.cakeEditIndex = undefined;
            if ($cordovaNetwork.isOffline()) {
                $ionicLoading.hide();
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $state.go("app.searchbusiness");
            }
        }

        function callAPI(cakeid, messageName, image) {
            if ($cordovaNetwork.isOffline()) {
                $ionicLoading.hide();
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $scope.internetOff = false;

                if ($rootScope.isEdit == true) {
                    for (var i = 1; i < 20; i++) {
                        if ($('#mainAcc_' + i) != undefined) {
                            $('#mainAcc_' + i).addClass('disabledbutton');
                        }
                    }
                    isSizeAPILoadedOnce = true;
                    // $scope.data = {};
                    $scope.data = {
                        "date": null,
                        "postcode": null,
                        "time": null,
                        "flag_var": null
                    };
                    $scope.data.cakeOptions = [];
                    $scope.isEdit = true;
                    $scope.optionalText = false;
                    $scope.data.edittext = messageName;
                    $scope.data.imgURI = image;
                    $scope.data.accessoriesCount = $rootScope.detail[$rootScope.cakeEditIndex].accessoriesCount; //count accessories
                    $scope.data.cakedetails = $rootScope.detail[$rootScope.cakeEditIndex].cakedetails;
                    sharelink = $rootScope.detail[$rootScope.cakeEditIndex].cakedetails.WebProductUrl;
                    $scope.data.imgs = $rootScope.detail[$rootScope.cakeEditIndex].imgs;
                    $scope.data.bakerysummary = $rootScope.detail[$rootScope.cakeEditIndex].bakerysummary;
                    $scope.bakeryId = $rootScope.detail[$rootScope.cakeEditIndex].bakerysummary.BakeryID; //Id of bakery
                    if ($rootScope.detail[$rootScope.cakeEditIndex].flavourExclude != undefined) {
                        $scope.data.flavourExclude = $rootScope.detail[$rootScope.cakeEditIndex].flavourExclude;
                    }

                    $scope.data.cakeshape = $rootScope.detail[$rootScope.cakeEditIndex].cakeshape;
                    $scope.data.caketype = $rootScope.detail[$rootScope.cakeEditIndex].caketype;
                    $scope.data.collection = $rootScope.detail[$rootScope.cakeEditIndex].collection;
                    productId = $rootScope.detail[$rootScope.cakeEditIndex].cakedetails.ProductID;
                    $scope.data.storeTimings = $rootScope.detail[$rootScope.cakeEditIndex].storeTimings;
                    $scope.data.storeClosedDays = $rootScope.detail[$rootScope.cakeEditIndex].storeClosedDays;
                    $scope.data.storeClosedSpecialDays = $rootScope.detail[$rootScope.cakeEditIndex].storeClosedSpecialDays;
                    $scope.data.storeSpecialTimings = $rootScope.detail[$rootScope.cakeEditIndex].storeSpecialTimings;
                    $scope.data.quantity = $rootScope.detail[$rootScope.cakeEditIndex].quantity;
                    $scope.data.cake_sizelist = $rootScope.detail[$rootScope.cakeEditIndex].cake_sizelist;
                    getOpenImageslide($scope.data.imgs);
                    $scope.showContent = true;
                    $scope.textTitle = true;
                    $scope.edittext = true;
                    $scope.typemessege = true;
                    $scope.btnshow = true;
                    $scope.imageUpload = true;
                    $scope.accordin = true;
                    sizeSelection($rootScope.detail[$rootScope.cakeEditIndex].cakesizeOption, 'size');
                    //getListData();

                } else {
                    apiTimeout();
                    $ionicLoading.hide();
                    console.log(cakeid);
                    GetCakedetailByCakeID.GetCakedetailByCakeID(cakeid).then(function(response) {
                        var resObject = JSON.parse(response);
                        clearTimeout(timer);
                        $scope.data.accessoriesCount = resObject.CakeDetail.AccessoryCount; //count accessories

                        $scope.data.cakedetails = resObject.CakeDetail;
                        sharelink = resObject.CakeDetail.WebProductUrl;
                        $scope.data.imgs = resObject.ProductImages;
                        $scope.data.bakerysummary = resObject.BakerySummary;
                        $scope.bakeryId = $scope.data.bakerysummary.BakeryID; //Id of bakery

                        //

                        $scope.data.cakeshape = resObject.CakeShape;
                        $scope.data.caketype = resObject.CakeType;
                        $scope.data.collection = resObject.CollectionAndDelivery;
                        productId = resObject.CakeDetail.ProductID;
                        $scope.data.storeTimings = resObject.WebstoreTiming;
                        $scope.data.storeClosedDays = _getCloseWeekDaysForBakery(resObject.WebstoreTiming);
                        $scope.data.storeClosedSpecialDays = _getClosedDaysForSpecialDays(resObject.WebstoreSpecialDays);
                        $scope.data.storeSpecialTimings = _getSpecialDaysTimings(resObject.WebstoreSpecialDays);
                        $scope.data.quantity = 1;
                        $scope.data.cake_sizelist = resObject.CakeSizes;
                        getOpenImageslide($scope.data.imgs);
                        $scope.showContent = true;
                        if ($scope.data.accessoriesCount > 0) {
                            $scope.showContinue = true;
                        } else {
                            $scope.showContinue = false;
                        }

                        setTimeout(function() {
                            sizeSelection($scope.data.cake_sizelist[0], 'size');
                        }, 1000)
                    }, function(err) {


                        clearTimeout(timer);
                        $ionicLoading.hide();
                        var confirmPopup = $ionicPopup.confirm({
                            template: 'Something went wrong!',
                            cssClass: 'popup_head_cust',
                            scope: $scope,
                            buttons: [{
                                text: 'Try Again!!',
                                onTap: function(e) {
                                    $state.go($state.current, {}, { reload: true });
                                }
                            }]
                        });

                    });
                }
            }
        }

        function _getCloseWeekDaysForBakery(storeTimings) {
            var resultClosedDays = $.grep(storeTimings, function(e) {
                return e.webstoreTiming_isclosed === true;
            });
            var closedDays = [];
            for (var i in resultClosedDays) {
                closedDays.push(resultClosedDays[i].webstoreTiming_dayid);
            }
            return closedDays;
        }

        function _getSpecialDaysTimings(specialDays) {
            var resultClosedDays = $.grep(specialDays, function(e) {
                return e.webstoreSpecialDays_isclosed === false;
            });
            var specialDaysTiming = [];
            for (var i in resultClosedDays) {
                specialDaysTiming.push({ 'date': new Date(resultClosedDays[i].webstoreSpecialDay_Date), 'opentime': resultClosedDays[i].webstoreSpecialDay_from, 'closetime': resultClosedDays[i].webstoreSpecialDay_to });
            }
            return specialDaysTiming;
        }

        function _getClosedDaysForSpecialDays(specialDays) {
            var resultClosedDays = $.grep(specialDays, function(e) {
                return e.webstoreSpecialDays_isclosed === true;
            });
            var closedSpecialDays = [];
            for (var i in resultClosedDays) {
                closedSpecialDays.push(new Date(resultClosedDays[i].webstoreSpecialDay_Date));
            }
            return closedSpecialDays;
        }
        /*
         * if given group is the selected group, deselect it
         * else, select the given group
         */
        $scope.toggleGroup = function(group, index) {
            if (index != undefined) {
                console.log($('#mainAcc_' + index).css('opacity') + " -------------");
                var opacityVal = $('#mainAcc_' + index).css('opacity');
                if (opacityVal != 1) {
                    return;
                }
            }
            if ($scope.isGroupShown(group)) {
                $scope.shownGroup = null;
                setScrollView(group, true);
            } else {
                $scope.shownGroup = group;
                setScrollView(group, false);
            }
        };

        $scope.isGroupShown = function(group) {
            return $scope.shownGroup === group;
        };

        function setScrollView(eleId, isClose) {
            setTimeout(function() {
                if ($('#' + eleId).parent()[0] != undefined) {

                    var elem = parseInt($('#' + eleId).parent()[0].offsetTop);
                    var sze = parseInt($('#size').parent()[0].offsetTop);
                    if (isClose) {
                        if (eleId === 'size') {
                            $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, elem, true);
                        } else {
                            if (sze > (elem - 210)) {
                                $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, sze, true);
                            } else {
                                $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, elem - 210, true);
                            }
                        }
                    } else {
                        if (eleId === 'size') {
                            $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, elem, true);
                        } else {
                            if (sze > (elem - 210)) {

                            } else {
                                $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, elem - 210, true);
                            }
                        }
                    }
                }
            }, 100);
        }
        // Size API loaded once
        var isSizeAPILoadedOnce = false;

        function sizeSelection(cakeOptionSel, group) {
            //window.plugins.spinnerDialog.show(null, null, true);

            $ionicLoading.hide();
            $scope.data.cakesizeOption = cakeOptionSel;
            $scope.data.cake_price = Number(cakeOptionSel.CakePrice);
            $scope.data.cake_size = cakeOptionSel.SizeTitle;
            $scope.textTitle = true;
            $scope.edittext = true;
            $scope.typemessege = true;
            $scope.btnshow = true;
            $scope.imageUpload = true;
            $scope.accordin = true;
            sizeId = cakeOptionSel.SizeID;



            setTimeout(function() {
                $('#selectedOption').empty();
                $('#selectedOption').empty();

                // $ionicLoading.show({
                //     template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                // });
                $('#selectedOption').append("<div class=\"col col-10 size-portion l-height\"><img class=\"icon_tick\" src=\" img/check.png\"></div>" +

                    "<div class=\"col col-33 size-portion item-body l-height\">" + cakeOptionSel.SizeTitle + "</div>" +
                    "<div class=\"col size-portion item-body l-height\"><span>" + cakeOptionSel.CakeMinPortion + " - " + cakeOptionSel.CakeMaxPortion + "</span></div>" +
                    "<div class=\"col col-25 size-portion item-body l-height price-red\">£" + Number(cakeOptionSel.CakePrice) + "</div>");

            }, 200);
            for (var i = 0; i < 20; i++) {
                if ($('#optionsDiv_' + i) != undefined) {
                    $('#optionsDiv_' + i).empty();
                }
            }
            $('.acc_category_outer').empty();
            //Size API loaded once /next time no need to load
            //if (!isSizeAPILoadedOnce) {
            $ionicLoading.show({
                template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
            });
            if ($scope.data.cakeOptions != undefined) {
                while ($scope.data.cakeOptions.length > 0) {
                    $scope.data.cakeOptions.pop();
                }
            }
            if ($scope.data.fullRub != undefined) {
                while ($scope.data.fullRub.length > 0) {
                    $scope.data.fullRub.pop();
                }
            }
            //if ($localStorage.cakeOptionsStored.length == 0) {
            getListData();
            /*} else {
                $scope.data.cakeOptions = $localStorage.cakeOptionsStored;
                $scope.$apply();
            }*/

            //API Hit
            //} else {
            //window.plugins.spinnerDialog.hide();
            // $ionicLoading.hide();
            //}
            $('#mainAcc_0').removeClass('disabledbutton');
            for (var i = 1; i < 20; i++) {
                if ($('#mainAcc_' + i) != undefined) {
                    $('#mainAcc_' + i).addClass('disabledbutton');
                }
            }
            calculateCost();
        }

        $scope.sizeChangeEvent = function(event, cakeOptionSel, group) {
            sizeSelection(cakeOptionSel, group);
            // calculateAccessoriessCost();
            if ($scope.isGroupShown(group)) {
                $scope.shownGroup = null;
                setScrollView(group, true);
            } else {
                $scope.shownGroup = group;
                setScrollView(group, false);
            }
        }

        // for (var i in $rootScope.detail[$rootScope.cakeEditIndex].cakeOptions) {
        //                       $scope.data.cakeOptions[i].selectedVal = $rootScope.detail[$rootScope.cakeEditIndex].cakeOptions[i].selectedVal;
        //                       $scope.data.cakeOptions[i].selectedOption = $rootScope.detail[$rootScope.cakeEditIndex].cakeOptions[i].selectedOption;
        //                       $scope.data.cakeOptions[i].selectedPrice = $rootScope.detail[$rootScope.cakeEditIndex].cakeOptions[i].selectedPrice;
        //                       //$scope.data.cakeOptions[i].selectedIndex = optionIndex;
        //                   }
        var collectionOpt = [];

        function getListData() {

            if ($rootScope.isEdit == true) {
                $ionicLoading.hide();
                $scope.data.cakeOptions = $rootScope.detail[$rootScope.cakeEditIndex].cakeOptions;
                $localStorage.cakeOptionsStored = [];
                //  console.log($scope.data.cakeOptions.length);

                if ($rootScope.detail[$rootScope.cakeEditIndex].Accessory != undefined) {
                    $scope.isVisible = true;
                    $scope.addAccessories();
                    $('#qtyScroll').show();
                    var elem = parseInt($('#qtyScroll')[0].offsetTop);
                    $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, elem, true);
                    //calculateAccessoriessCost();
                } else {
                    $rootScope.isEdit = false;
                }
                calculateCost();
                setTimeout(function() {
                    for (var i = 0; i < 20; i++) {
                        if ($('#mainAcc_' + i) != undefined) {
                            $('#mainAcc_' + i).removeClass('disabledbutton');
                        }
                    }

                    for (var i in $scope.data.cakeOptions) {
                        var fID = $scope.data.cakeOptions[i].options[$scope.data.cakeOptions[i].selectedIndex].FlavourID;
                        _getExcludedFlavourID(fID);
                        $localStorage.cakeOptionsStored.push($scope.data.cakeOptions[i]);
                    }

                }, 1000);

            } else {
                apiTimeout();
                GetCakeAttributesListByCakeID.GetCakeAttributesListByCakeID(productId, sizeId).then(function(response) {
                    isSizeAPILoadedOnce = true;
                    var responseObject = JSON.parse(response);
                    clearTimeout(timer);
                    $ionicLoading.hide();
                    if (responseObject.FlavourExclude != undefined) {
                        $scope.data.flavourExclude = responseObject.FlavourExclude;
                    }

                    for (var i in responseObject.CakeFlavour) {
                        var customOptions = {};
                        customOptions.title = responseObject.CakeFlavour[i].FlavourTitle;
                        customOptions.shortname = responseObject.CakeFlavour[i].FlavourShortName;
                        customOptions.options = responseObject.CakeFlavour[i].CakeFlavourChoice;
                        customOptions.viewTypeID = responseObject.CakeFlavour[i].Attribute_ViewTypeID; // 1 -selection, 2 - image upload, 3- message box
                        customOptions.flavourID = responseObject.CakeFlavour[i].FlavourID;
                        customOptions.flavour_type_id = responseObject.CakeFlavour[i].flavour_Type;
                        customOptions.isMandate = responseObject.CakeFlavour[i].lnkAtt_Mandatorytype;
                        $scope.data.cakeOptions.push(customOptions);

                        collectionOpt.push(customOptions);
                        $localStorage.cakeOptionsStored.push(customOptions);

                        if ($rootScope.cakeEditIndex != null) {
                            $('#qtyScroll').hide();
                            $scope.isVisible = false;
                            if ($scope.data.accessoriesCount > 0) {
                                $scope.showContinue = true;
                            } else {
                                $scope.showContinue = false;
                            }
                        }

                    }
                    setTimeout(function() {
                        $('#mainAcc_0').removeClass('disabledbutton');
                    }, 1000);

                    setScrollView("size", false);
                    //window.plugins.spinnerDialog.hide();
                }, function(err) {

                    clearTimeout(timer);
                    $ionicLoading.hide();
                    var confirmPopup = $ionicPopup.confirm({
                        template: 'Something went wrong!',
                        cssClass: 'popup_head_cust',
                        scope: $scope,
                        buttons: [{
                            text: 'Try Again!!',
                            onTap: function(e) {
                                $state.go($state.current, {}, { reload: true });
                            }
                        }]
                    });

                });
            }

        };

        function resetOptionToQuestion(index) {
            var nextEnabled = (index + 1);
            var removeDisabled = false;
            for (var i = nextEnabled; i <= $scope.data.cakeOptions.length; i++) {
                if ($scope.data.cakeOptions[i] != undefined) {
                    if ($scope.data.cakeOptions[i].viewTypeID == 1) {

                        var id = $scope.data.cakeOptions[i].flavourID;
                        $('#chk_' + id + "_" + $scope.data.cakeOptions[i].selectedIndex).attr('checked', false);

                        $scope.data.cakeOptions[i].selectedVal = undefined;
                        $scope.data.cakeOptions[i].selectedPrice = 0;
                        $('#opt_' + id).empty();
                        $('#opt_' + id).append('<div style="padding-top:3px;" class="col col-10">' +
                            '<img class="img-ham" src="img/hamburger.png"></div>' +
                            '<div class="col font-sm">' + $scope.data.cakeOptions[i].title + '</div>');
                        if (!removeDisabled) {
                            $('#mainAcc_' + i).removeClass('disabledbutton');
                            removeDisabled = true;
                        } else {
                            $('#mainAcc_' + i).addClass('disabledbutton');
                        }

                    }
                }
            }
            calculateCost();
        }

        function selectionEvent(listObject, id, index, optionIndex) {
            var opacityVal = $('#' + listObject.FlavourID).css('opacity');
            if (opacityVal != 1) {
                return;
            }

            $scope.showAccessories = true;
            $('#opt_' + id).empty();
            $('#opt_' + id).append(
                "<div style=\"padding-top:3px;\" class=\"col col-10 size-portion item-body\"><img class=\"icon_tick\" src=\" img/check.png\"></div>" +
                "<div class=\"col size-portion item-body\"> " + listObject.FlavourTitle + "</div>" +
                "<div class=\"col col-20 size-portion item-body\">" + (listObject.ExtraPrice == 0 ? "" : "£" + Number(listObject.ExtraPrice)) + "</div>");

            $('#chk_' + id + "_" + optionIndex).attr('checked', true);


            $scope.data.cakeOptions[index].selectedVal = listObject.FlavourTitle + "  " + Number(listObject.ExtraPrice);
            $scope.data.cakeOptions[index].selectedOption = listObject.FlavourTitle;
            $scope.data.cakeOptions[index].selectedPrice = Number(listObject.ExtraPrice);
            $scope.data.cakeOptions[index].selectedIndex = optionIndex;

            if ($scope.isGroupShown(id)) {
                $scope.shownGroup = null;
                setScrollView(id, false);
            } else {
                $scope.shownGroup = id;
                setScrollView(id, true);
            }
            $('#main_' + id).removeClass('error-border');
            var nextEnabled = (index + 1);
            for (var i = nextEnabled; i <= $scope.data.cakeOptions.length; i++) {
                if ($scope.data.cakeOptions[i] != undefined) {
                    if ($scope.data.cakeOptions[i].viewTypeID == 1) {
                        $('#mainAcc_' + i).removeClass('disabledbutton');
                        if (diabledOptionsColl[index] != undefined) {
                            for (var k in diabledOptionsColl[index]) {
                                $('#' + diabledOptionsColl[index][k]).removeClass('hide_block');
                            }
                            diabledOptionsColl[index] = [];
                        }
                        _getExcludedFlavourID(listObject.FlavourID, index);
                        break;
                    }
                }
            }
            resetOptionToQuestion(index);
            calculateCost();
        }
        var diabledOptionsColl = [];
        // var FlavourExclude = [{ "flavourExclude_ID1": 1085, "flavourExclude_ID2": 1089 }, { "flavourExclude_ID1": 1086, "flavourExclude_ID2": 1091 }, { "flavourExclude_ID1": 1086, "flavourExclude_ID2": 1092 }, { "flavourExclude_ID1": 1089, "flavourExclude_ID2": 1083 }, { "flavourExclude_ID1": 1090, "flavourExclude_ID2": 1082 }, { "flavourExclude_ID1": 1090, "flavourExclude_ID2": 1083 }, { "flavourExclude_ID1": 1091, "flavourExclude_ID2": 1081 }, { "flavourExclude_ID1": 1092, "flavourExclude_ID2": 1081 }];

        function _getExcludedFlavourID(flavourID, index) {
            var results = $.grep($scope.data.flavourExclude, function(e) {
                return e.flavourExclude_ID2 === flavourID;
            });
            var disabledIDs = [];
            for (var i in results) {
                var div2Disable = results[i].flavourExclude_ID1;
                disabledIDs.push(div2Disable);
                $('#' + div2Disable).addClass('hide_block');
            }
            diabledOptionsColl[index] = disabledIDs;
        }

        $scope.selectionChangeEvent = function(event, listObject, id, index, optionIndex) {

            selectionEvent(listObject, id, index, optionIndex);
        }

        function calculateCost() {
            $scope.data.total_amt = Number($scope.data.cake_price);
            for (var i in $scope.data.cakeOptions) {
                if ($scope.data.cakeOptions[i].viewTypeID == 1) {
                    if ($scope.data.cakeOptions[i].selectedVal != undefined) {
                        $scope.data.total_amt += Number($scope.data.cakeOptions[i].selectedPrice);
                    }
                }
            }
            //calculateAccessoriessCost();
            $scope.data.accessoriesSum = $scope.data.total_amt;
            calculateAccessoriessCost();
        }

        function validateForm() {
            var errObject = { 'label': '', 'success': true, 'id': '' };
            if ($scope.data.cake_size === null || $scope.data.cake_size === undefined) {
                errObject.label = "Select Cake Size / Portion";
                errObject.success = false;
                errObject.id = 'size';
            } else {
                for (var i in $scope.data.cakeOptions) {
                    if ($scope.data.cakeOptions[i].viewTypeID == 1) {
                        if ($scope.data.cakeOptions[i].selectedVal == undefined) {
                            errObject.label = $scope.data.cakeOptions[i].title;
                            errObject.success = false;
                            errObject.id = $scope.data.cakeOptions[i].flavourID;
                            break;
                        }
                    }
                }
            }
            return errObject;
        }


        /** Quantity Modal **/

        var previousQty;
        var keyQty;
        var parentIndex;
        var selectedIndex;
        $scope.accessoryArray = [];



        $ionicModal.fromTemplateUrl('my-quantityModal.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function(modal) {
            $scope.modalQty = modal;
        });

        $scope.openQty = function(key, selectedindex, price, parentindex) {
            keyQty = key;
            selectedIndex = selectedindex;
            parentIndex = parentindex;

            $scope.qty = [];
            showQty = $("#qty" + "_" + selectedindex + "_" + parentIndex).text();
            if (showQty == undefined) {
                $scope.qty[0] = true;
            } else {
                for (var i = 0 in $rootScope.quantity) {
                    if ($rootScope.quantity[i].value == showQty) {
                        $scope.qty[i] = true;
                        //$("#qty" + i).attr('checked', true);
                        break;
                    }
                }
            }
            $scope.modalQty.show();
        };

        // $scope.$on('modal.shown', function() {
        //     setTimeout(function() {
        //         $scope.createQtyArray();
        //     }, 500);
        // });

        $scope.closeModalQt = function() {
            $scope.modalQty.hide();
        };


        function calculateAccessoriessCost() {

            $scope.data.accessories_total_amt = 0;
            if ($scope.data.accessories != undefined) {
                for (var i in $scope.data.accessories) {
                    for (var a in $scope.data.accessories[i].value) {
                        if ($scope.data.accessories[i].value[a].selected != undefined) {
                            $scope.data.accessories_total_amt += parseInt($scope.data.accessories[i].value[a].qty) * parseFloat($scope.data.accessories[i].value[a].product_StartingPrice);
                        }
                    }
                }
                $scope.data.accessoriesSum = $scope.data.total_amt + $scope.data.accessories_total_amt;

            }
        }


        $scope.callAccessoriesFun = function(key, index, parentIndex) {
            var result = $.grep($scope.data.accessories, function(e) {
                return e.key == key;
            });

            if (result[0].value[index].product_quantity <= parseInt($("#qty" + "_" + index + "_" + parentIndex).text())) {
                $cordovaToast.show("Please choose quantity less than" + result[0].value[index].product_quantity, 'short', 'center')
                    .then(function(success) {

                    }, function(error) {

                    });
            } else {
                if ($("#qty" + "_" + index + "_" + parentIndex).text() == "") {
                    $("#qty" + "_" + index + "_" + parentIndex).text('0');
                } else {
                    result[0].value[index].selected = true;
                    result[0].value[index].qty = parseInt($("#qty" + "_" + index + "_" + parentIndex).text());
                    calculateAccessoriessCost();
                }
            }
            $('#testing_footer').removeClass('keyboard_footer');
        };


        $scope.quantity_changeEvent = function(value) {
            $("#qty" + "_" + selectedIndex + "_" + parentIndex).text(value);
            $scope.callAccessoriesFun(keyQty, selectedIndex, parentIndex);
            $scope.modalQty.hide();
        };

        $scope.AccessoryTitle = [];
        $scope.fullAccessoryArray = [];

        $scope.fullRub = [];

        $scope.addAccessories = function() {
            // var elem = parseInt($('.acc_category_outer').parent()[0].offsetTop);
            // $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, elem, true);

            if ($rootScope.isEdit == true) {
                $scope.data.Accessory = $rootScope.detail[$rootScope.cakeEditIndex].Accessory;
                for (var i in $scope.data.Accessory) { //Title Array
                    if ($scope.AccessoryTitle[$scope.data.Accessory[i].Accossory_Title] == null) {
                        $scope.AccessoryTitle[$scope.data.Accessory[i].Accossory_Title] = $scope.data.Accessory[i].Accossory_Title;
                    }
                }
                // loop
                for (var k in $scope.AccessoryTitle) {
                    var result = $.grep($scope.data.Accessory, function(e) {
                        return e.Accossory_Title == k;
                    });
                    $scope.fullRub.push({
                        'key': k,
                        'value': result
                    });
                }

                $scope.data.accessories = $scope.fullRub;

                // calculateAccessoriessCost();
                $rootScope.isEdit = false;

            } else {
                $ionicLoading.show({
                    noBackdrop: false,
                    template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                });
                apiTimeout();


                GetAccessoriesByBakeryID.GetAccessoriesByBakeryID($scope.bakeryId, pageno, pagesize).then(function(response) {
                    clearTimeout(timer);
                    $ionicLoading.hide();

                    var resObject = JSON.parse(response);
                    console.log(resObject);
                    $scope.data.Accessory = resObject.Accessories;

                    for (var i in $scope.data.Accessory) { //Title Array
                        if ($scope.AccessoryTitle[$scope.data.Accessory[i].Accossory_Title] == null) {
                            $scope.AccessoryTitle[$scope.data.Accessory[i].Accossory_Title] = $scope.data.Accessory[i].Accossory_Title;
                        }
                    }
                    // loop
                    for (var k in $scope.AccessoryTitle) {
                        var result = $.grep($scope.data.Accessory, function(e) {
                            return e.Accossory_Title == k;
                        });
                        $scope.fullRub.push({
                            'key': k,
                            'value': result
                        });
                    }

                    $scope.data.accessories = $scope.fullRub;
                }, function(err) {
                    console.log(err);
                    clearTimeout(timer);
                    $ionicLoading.hide();
                    var confirmPopup = $ionicPopup.confirm({
                        template: 'Something went wrong!',
                        cssClass: 'popup_head_cust',
                        scope: $scope,
                        buttons: [{
                            text: 'Try Again!!',
                            onTap: function(e) {
                                $state.go($state.current, {}, { reload: true });
                            }
                        }]
                    });

                });
            }


        };

        $scope.isVisible = false;

        $scope.getIndex = function(indexScroll, parent) {
            //debugger;
            // var elem = parseInt($('#cardScroll' + "_" + indexScroll + "_" + parent).parent()[0].offsetTop);
            // $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, elem, true);
            // $('#testing_footer').addClass('keyboard_footer');


        };

        $scope.add_cart = function() {
            var valid = validateForm();
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if (valid.success == false) {
                $cordovaToast.showLongCenter(valid.label);
                $('#main_' + valid.id).addClass('error-border');
                setScrollView(valid.id, false);
            } else {
                if ($scope.data.accessoriesCount != 0 && $scope.isVisible != true) {
                    $scope.isVisible = true
                    $scope.addAccessories();
                    $('#qtyScroll').show();
                    var elem = parseInt($('#qtyScroll')[0].offsetTop);
                    $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, elem, true);
                } else {
                    if ($rootScope.cakeEditIndex != undefined) {
                        $rootScope.detail[$rootScope.cakeEditIndex] = $scope.data;
                        $rootScope.cartcount = $rootScope.detail.length;
                        //  $localStorage.detail = $rootScope.detail;

                        console.log($localStorage.detail);
                        getCartCount();
                        $rootScope.isEdit = false;
                        $rootScope.cakeEditIndex = undefined;
                        $state.go("app.cart", { 'cakeid': $localStorage.cakeID });
                        $cordovaToast.showLongCenter("Saved changes");
                    } else {
                        $rootScope.detail.push($scope.data);
                        $rootScope.cartcount = $rootScope.detail.length;
                        // $localStorage.detail = $rootScope.detail;

                        getCartCount();
                        $rootScope.isEdit = false;
                        $rootScope.cakeEditIndex = undefined;
                        $state.go("app.searchbusiness");
                    }


                }

            }
        }


        $scope.continue = function() {
            var valid = validateForm();
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if (valid.success == false) {
                $cordovaToast.showLongCenter(valid.label);
                $('#main_' + valid.id).addClass('error-border');
                setScrollView(valid.id, false);
            } else {
                if ($scope.data.accessoriesCount != 0 && $scope.isVisible != true) {
                    $scope.isVisible = true
                    $scope.addAccessories();
                    $('#qtyScroll').show();
                    var elem = parseInt($('#qtyScroll')[0].offsetTop);
                    $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, elem, true);
                    $scope.showContinue = false;
                } else {

                }

            }
        }


        $scope.buy_now = function() {

            var valid = validateForm();
            console.log($rootScope.detail);

            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if (valid.success == false) {
                $cordovaToast.showLongCenter(valid.label);
                $('#main_' + valid.id).addClass('error-border');
                setScrollView(valid.id, false);
            } else {
                if ($scope.data.accessoriesCount != 0 && $scope.isVisible != true) {
                    $scope.isVisible = true
                    $scope.addAccessories();
                    $('#qtyScroll').show();
                    var elem = parseInt($('#qtyScroll')[0].offsetTop);
                    $ionicScrollDelegate.$getByHandle("scrollHandler").scrollTo(0, elem, true);
                } else {
                    if ($rootScope.cakeEditIndex != undefined) {
                        $rootScope.detail[$rootScope.cakeEditIndex] = $scope.data;
                        $rootScope.cartcount = $rootScope.detail.length;
                        $localStorage.detail = $rootScope.detail;

                        getCartCount();
                        $rootScope.isEdit = false;
                        $rootScope.cakeEditIndex = undefined;
                        $state.go("app.cart", { 'cakeid': $localStorage.cakeID });
                        $cordovaToast.showLongCenter("Saved changes");
                    } else {
                        $rootScope.detail.push($scope.data);
                        $rootScope.cartcount = $rootScope.detail.length;
                        $localStorage.detail = $rootScope.detail;

                        getCartCount();
                        $rootScope.isEdit = false;
                        $rootScope.cakeEditIndex = undefined;
                        $state.go("app.cart", { 'cakeid': $localStorage.cakeID });
                    }

                }

            }
        }

        $scope.goTo = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if ($rootScope.detail.length == 0) {
                $cordovaToast.showLongBottom("Cart is empty");
            } else {
                $state.go("app.cart");
            }
        };

        function getCartCount() {
            if ($rootScope.detail == undefined) {
                $scope.cartnotification = true;
                $scope.count = 0;
            } else if ($rootScope.detail.length == 0) {
                $scope.cartnotification = true;
                $scope.count = 0;
            } else {
                $scope.cartnotification = true;
                $scope.count = $rootScope.detail.length;
            }
        }
        $scope.share = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $cordovaSocialSharing.share("The easiest way to pick a cake for your special day", 'Caker Street', null, sharelink);
            }
        }

        $scope.Add = function(index) {
            if ($scope.data.edittext == '' || $scope.data.edittext == undefined) {
                $cordovaToast.showLongCenter("Type your message");
            } else {
                $scope.data.cakeOptions[index].selectedOption = $scope.data.edittext;
                $scope.optionalText = false;
            }

        }

        $scope.Clear = function(group) {
            $scope.data.edittext = '';
        }

        $scope.editHandler = function() {
            $scope.optionalText = true;
        };


        $scope.takePicture = function(index) {
            var hideSheet = $ionicActionSheet.show({
                buttons: [
                    { text: '<b>Camera</b> ' },
                    { text: 'Gallery' },
                    { text: 'Cancel' }
                ],
                //destructiveText: 'Gallery',
                titleText: 'Please choose',
                cancelText: 'Cancel',
                cancel: function() {
                    // add cancel code..
                },
                buttonClicked: function(index) {
                    if (index == 0) {
                        var options = {
                            quality: 75,
                            destinationType: Camera.DestinationType.DATA_URL,
                            sourceType: Camera.PictureSourceType.CAMERA,
                            allowEdit: true,
                            encodingType: Camera.EncodingType.JPEG,
                            targetWidth: 300,
                            targetHeight: 300,
                            popoverOptions: CameraPopoverOptions,
                            saveToPhotoAlbum: false
                        };

                        $cordovaCamera.getPicture(options).then(function(imageData) {
                            imagepath = "data:image/jpeg;base64," + imageData;
                            imagepath = "data:image/jpeg;base64," + imageData;
                            UploadOrderPicture.UploadOrderPicture(imageData)
                                .then(function(response) {
                                    var resObject = JSON.parse(response);



                                });
                            imagebsee64 = imageData;
                            $scope.data.imgURI = imagepath;
                            $scope.data.cakeOptions[index].selectedVal = $scope.data.imgURI;
                            $scope.data.images[index].selectedOption = $scope.data.imgURI;
                            //  $scope.data.cakeOptions[index].selectedOption= $scope.data.imgURI;

                            //$scope.sendImage($scope.imgURI);
                        }, function(err) {
                            // An error occured. Show a message to the user
                        });
                    }
                    if (index == 1) {
                        var options = {
                            quality: 75,
                            destinationType: Camera.DestinationType.DATA_URL,
                            sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                            allowEdit: true,
                            encodingType: Camera.EncodingType.JPEG,
                            targetWidth: 300,
                            targetHeight: 300,
                            popoverOptions: CameraPopoverOptions,
                            saveToPhotoAlbum: false
                        };

                        $cordovaCamera.getPicture(options).then(function(imageData) {

                            imagepath = "data:image/jpeg;base64," + imageData;
                            UploadOrderPicture.UploadOrderPicture(imageData)
                                .then(function(response) {

                                    var resObject = JSON.parse(response);


                                });
                            $scope.data.imgURI = imagepath;

                            imagebsee64 = imageData;
                            $scope.data.cakeOptions[index].selectedVal = $scope.data.imgURI;
                            $scope.data.images[index].selectedOption = $scope.data.imgURI;

                            // $scope.sendImage($scope.imgURI);
                        }, function(err) {

                        });
                    }
                    if (index == 2) {
                        $timeout(function() {
                            hideSheet();
                        }, 500);
                    }
                    return true;
                }
            });
        }


        //open model slide box
        function getOpenImageslide(images) {

            $scope.aImages = [];
            for (var i = 0; i < images.length; i++) {
                $scope.aImages.push({ 'src': images[i].SmallImage });
                $scope.aImages.push({ 'src': images[i].LargeImage });
                $scope.imagelength = $scope.aImages.length;

            }

            $ionicModal.fromTemplateUrl('image-modal.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function(modal) {
                $scope.modal = modal;
            });

            $scope.openModal = function() {
                $ionicSlideBoxDelegate.slide(0);
                $scope.modal.show();
            };
            $scope.closeModal = function() {
                $scope.modal.hide();
            };

            $scope.next = function() {
                $ionicSlideBoxDelegate.next();
            };

            $scope.previous = function() {
                $ionicSlideBoxDelegate.previous();
            };

            $scope.goToSlide = function(index) {
                $scope.modal.show();
                $ionicSlideBoxDelegate.slide(index);
            }

            // Called each time the slide changes
            $scope.slideChanged = function(index) {
                $scope.slideIndex = index;
            };
        }
        // window.addEventListener('native.keyboardshow', keyboardShowHandler);

        // function keyboardShowHandler(e) {
        //     alert('Keyboard height is: ' + e.keyboardHeight);
        // }

        //api timeout
        function apiTimeout() {
            clearTimeout(timer);
            timer = setTimeout(function() {
                $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
                $ionicLoading.hide();
            }, delay_time);
        }


    });
