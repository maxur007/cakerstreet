 app.controller('stripeCtrl', function($scope, $stateParams, $state,
     $timeout, GetBakeriesAndCakesBypostcodeAndMiles, GetCakesByPostcodeAndMiles, $rootScope, $location, $ionicSideMenuDelegate, $window, $ionicPlatform, GetCategories, $timeout, $filter, $cordovaNetwork, $q, $http, $cordovaToast,
     $ionicPopup, $ionicLoading, SaveConfirmedOrderFromJson,
     $ionicModal, getbakeryProducts_byBakeryid, $localStorage, OrderDetails) {
     var previousState;
     console.log($rootScope.detail);
     window.addEventListener('native.keyboardshow', function() {

         $('#testing_footer').addClass('keyboard_footer');
     });

     window.addEventListener('native.keyboardhide', function() {

         $('#testing_footer').removeClass('keyboard_footer');
     });
     $scope.$on('$stateChangeSuccess', function(ev, to, toParams, from, fromParams) {
         //   alert("skd");
         // $rootScope.previousState = from.name;
         // $localStorage.previousState = $rootScope.previousState;
         previousState = from.name;
         console.log($localStorage.previousState);
         // $rootScope.currentState = to.name;

     });
     var timer;
     var delay_time = $rootScope.timer_delay;
     $scope.cardType = {};
     $scope.card = {};
     $scope.span_month = true;
     $scope.span_year = true;

     var timerSaveFirst;
     var timerSaveSecond;

     //change
     $scope.myGoBack = function() {
         if ($cordovaNetwork.isOffline()) {
             $cordovaToast.showLongCenter("No internet connection!");
         } else if (previousState == 'app.checkout' || previousState == 'app.login' || previousState == 'app.user-register-page') {
             $state.go("app.checkout");
         } else {
             // window.history.back();
             $state.go("app.billingaddressconfirm", { 'billAddressObj': $rootScope.billingAddress });
         }
     };

     //month Array
     $scope.month_array = [{ title: "Jan", value: "01" }, { title: "Feb", value: "02" }, {
             title: "Mar",
             value: "03"
         }, { title: "April", value: "04" }, { title: "May", value: "05" }, { title: "June", value: "06" }, { title: "July", value: "07" },
         { title: "Aug", value: "08" }, { title: "Sep", value: "09" }, { title: "Oct", value: "10" }, { title: "Nov", value: "11" }, { title: "Dec", value: "12" }
     ];

     //month modal
     $ionicModal.fromTemplateUrl('month.html', {
         scope: $scope,
         animation: 'slide-in-up'
     }).then(function(modal) {
         $scope.modalMonth = modal;
     });

     var showmonth;
     $scope.selectmonth_handler = function() {
         $scope.months = [];
         if (showmonth == undefined) {
             $scope.months[0] = true;
         } else {
             for (var i = 0 in $scope.month_array) {
                 if ($scope.month_array[i].title == showmonth) {
                     $scope.months[i] = true;

                     break;
                 }
             }
         }
         $scope.modalMonth.show();
     };

     $scope.closeModal = function() {
         $scope.modalMonth.hide();
     };

     $scope.select_month = function(selectedvalue) { //modal click
         $scope.card.exp_month = selectedvalue;
         $scope.modalMonth.hide();
         $scope.span_month = false;
     };
     //year modal
     var showyear;
     $ionicModal.fromTemplateUrl('year.html', {
         scope: $scope,
         animation: 'slide-in-up'
     }).then(function(modal) {
         $scope.modalYear = modal;
     });
     $scope.year = [];
     showyear = new Date().getFullYear();
     var c_year = showyear + 30;
     $scope.selectyear_handler = function() {

         for (var i = showyear; i <= c_year; i++) {
             $scope.year.push(i);
         }
         $scope.modalYear.show();
     };
     console.log($scope.year);

     $scope.closeModalYear = function() {
         $scope.modalYear.hide();
     };
     $scope.select_year = function(selectedvalue) {
         console.log(selectedvalue);
         $scope.card.exp_year = selectedvalue;
         console.log($scope.card.exp_month);
         $scope.modalYear.hide();
         $scope.span_year = false;
     }


     $scope.card.amount = $rootScope.grand_total;
     console.log($scope.card.amount);

     $scope.makeStripePayment = makeStripePayment;

     function makeStripePayment(_cardInformation) {

         console.log(_cardInformation);
         if ($cordovaNetwork.isOffline()) {
             $cordovaToast.showLongCenter("No internet connection!");
         } else if (!_cardInformation.number) {
             $cordovaToast.showLongBottom("Please enter  Card Number");
             return;
         } else if (!_cardInformation.exp_month) {
             $cordovaToast.showLongBottom("Please enter  Expire Month of Card");
         } else if (!_cardInformation.exp_year) {
             $cordovaToast.showLongBottom("Please enter  Expire Year of Card");
         } else if (!_cardInformation.cvc) {
             $cordovaToast.showLongBottom("Please enter  CVV Number");
             return;
         } else if (!window.stripe) {
             $cordovaToast.showLongBottom("stripe plugin not installed");
             return;
         } else if (!_cardInformation) {
             $cordovaToast.showLongBottom("Invalid Card Data");
             return;
         } else {
             $ionicLoading.show({
                 noBackdrop: false,
                 template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
             });
             stripe.charges.create({
                     // amount is in cents so * 100
                     amount: (_cardInformation.amount) * 100,
                     currency: 'GBP',
                     card: {
                         "number": _cardInformation.number,
                         "exp_month": _cardInformation.exp_month,
                         "exp_year": _cardInformation.exp_year,
                         "cvc": _cardInformation.cvc,
                         "name": ""
                     },
                     description: ""
                 },
                 function(response) {

                     if (response.error) {
                         $ionicLoading.hide();
                         console.log(response.error.message);
                         console.log(response.error);
                         $cordovaToast.showLongBottom(response.error.message);
                         return;
                     } else {
                         //  $scope.paymentForm = false;
                         var transactionid = response.id;
                         var obj = saveOrder(transactionid);
                         //  $cordovaToast.showLongBottom("Transaction successful!");
                         $localStorage.saveOrderobj = obj;
                         updateAPIAfterPayment(JSON.stringify(obj));
                     }
                 },
                 function(response) {
                     $cordovaToast.showLongBottom(JSON.stringify(response));
                     // $cordovaToast.showLongBottom("Invalid card number.Please use valid card number.")
                 } // error handler
             );
         }

     }

     function updateAPIAfterPayment(cakesOrderInfoObj) {

         if (internetcheck() == true) {
             apiSaveOrderTimeout();
             apiSaveOrderDelayTimeout();
             SaveConfirmedOrderFromJson.SaveConfirmedOrderFromJson(cakesOrderInfoObj).then(function(response) {
                 console.log(response);
                 clearTimeout(timerSaveFirst);
                 clearTimeout(timerSaveSecond);
                 //$scope.confirmPopup2.close();
                 var responseObj = JSON.parse(response);
                 if (responseObj.ErrorID == 0) {
                     $ionicLoading.hide();
                     $state.go('app.thanks');
                     $cordovaToast.showLongBottom("Your order has been registered!");
                 } else {
                     $ionicLoading
                         .hide();
                     $state.go('app.faliure');
                 }

             }, function(err) {
                 console.log(err);
                 clearTimeout(timer);
                 clearTimeout(timerSaveFirst);
                 clearTimeout(timerSaveSecond);
                 //                 $scope.confirmPopup2.close();
                 $ionicLoading.hide();
                 var confirmPopup = $ionicPopup.confirm({
                     template: 'Something went wrong!',
                     cssClass: 'popup_head_cust',
                     scope: $scope,
                     buttons: [{
                         text: 'Try Again!!',
                         onTap: function(e) {
                             $ionicLoading.show({
                                 noBackdrop: false,
                                 template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                             });
                             updateAPIAfterPayment(JSON.stringify($localStorage.saveOrderobj));
                             confirmPopup.close();

                             //$state.go($state.current, {}, { reload: true });
                         }
                     }]
                 });

             });
         } else {


         }

     };


     //variable declartion 
     function saveOrder(transactionID) {
         var order = {};
         var ordersArray = [];
         var custId = 0;
         var firstname = $rootScope.billingAddress.deliveryadd_fName;
         var emailid = $rootScope.billingAddress.deliveryadd_Email;

         if ($rootScope.loggedin == true) {
             custId = parseInt($rootScope.userdetail.userID);
             firstname = $rootScope.userdetail.First_Name;
             emailid = $localStorage.userDetails.Email;
         }
         for (var selectedCake in $rootScope.detail) {
             var data = $rootScope.detail[selectedCake];
             var orderchild = {};
             var orderObj = {};
             orderObj.CustomerID = custId; //CustomerID
             orderObj.BakeryID = data.bakerysummary.BakeryID; //BakeryID
             orderObj.TotalPrice = ((parseFloat(data.total_amt) * (data.quantity)) + parseFloat(data.collection.ByHandDeliveryPrice) + parseFloat(data.accessories_total_amt)); //TotalPrice
             orderObj.TotalPriceWithoutShippingCharges = (data.total_amt) * (data.quantity) + parseFloat(data.accessories_total_amt); // Total Price 
             orderObj.ShippingCharges = (data.collection.ByHandDeliveryPrice);
             orderObj.CustomerName = firstname; //CustomerName
             orderObj.CustomerEmail = emailid; //CustomerEmail
             orderObj.PaymentGatewayName = "paypal"; //PaymentGatewayName
             orderObj.Product_ID = data.cakedetails.ProductID; //Product_ID
             orderObj.Product_Qty = data.quantity; //Product_Qty
             orderObj.Size_Price = (data.cakesizeOption.CakePrice); //Size_Price
             orderObj.Product_Name = data.cakedetails.Title; //Product_Name
             orderObj.Product_Image = data.imgs[0].SmallImage; //Product_Image
             orderObj.Shape_ID = data.cakeshape.CakeShapeID; //Shape_ID
             orderObj.Shape_Text = data.cakeshape.CakeShapeTitle; //Shape_Text
             orderObj.Type_ID = data.caketype.CakeTypeID; //Type_ID
             orderObj.Size_ID = data.cakesizeOption.SizeID; //Size_ID
             orderObj.CollectionMode = data.CollectionMode; //Collection mode
             orderObj.Ordercollection_Date = data.Ordercollection_Date; //Ordercollection_Date
             orderObj.Ordercollection_Occassion = data.Ordercollection_Occassion; //Ordercollection_Occassion
             orderObj.Ordercollection_Remarks = (data.Ordercollection_Remarks == undefined ? "" : data.Ordercollection_Remarks); //Ordercollection_Remarks
             orderObj.TransactionID = transactionID; //TransactionID
             var attsArray = [];
             var nextIndexForAccessories = 1;
             for (var i in data.cakeOptions) {
                 var attributeObj = {};
                 attributeObj.flavour_type_ID = data.cakeOptions[i].flavour_type_id; // flavour_type_ID
                 attributeObj.parent_Att_ID = data.cakeOptions[i].flavourID; // parent_Att_ID
                 if (data.cakeOptions[i].viewTypeID === 3 || data.cakeOptions[i].viewTypeID === 2) {
                     attributeObj.Att_IDs = ""; // Att_IDs                        
                     attributeObj.data_optionaltext = data.cakeOptions[i].selectedVal; // data_optionaltext
                     attributeObj.viewType = data.cakeOptions[i].viewTypeID; // viewType
                     attributeObj.data_text = data.cakeOptions[i].title; // data_text
                     var num = 0;
                     attributeObj.att_totalPrice = 0; // att_totalPrice
                     attributeObj.attwise_Price = ""; // attwise_Price
                 } else {
                     var selectedOption = data.cakeOptions[i].selectedIndex; // Selected Option
                     var selObject = data.cakeOptions[i].options[selectedOption];
                     attributeObj.Att_IDs = selObject.FlavourID.toString(); // Att_IDs                       
                     attributeObj.data_optionaltext = ""; // data_optionaltext
                     attributeObj.viewType = data.cakeOptions[i].viewTypeID; // viewType
                     attributeObj.data_text = ""; // data_text
                     attributeObj.att_totalPrice = parseFloat(selObject.ExtraPrice); // att_totalPrice
                     attributeObj.attwise_Price = selObject.ExtraPrice.toString(); // attwise_Price
                 }
                 attributeObj.displayOrder = parseInt(i);
                 attsArray.push(attributeObj);
                 nextIndexForAccessories = i;
             }
             nextIndexForAccessories = parseInt(nextIndexForAccessories) + 1;
             for (var i in data.accessories) {
                 for (var a in data.accessories[i].value) {
                     if (data.accessories[i].value[a].selected != undefined) {
                         var accessoriesObj = {};
                         accessoriesObj.flavour_type_ID = 3; // flavour_type_ID
                         accessoriesObj.parent_Att_ID = data.accessories[i].value[a].product_id; // parent_Att_ID
                         accessoriesObj.Att_IDs = 0; // Att_IDs                       
                         accessoriesObj.data_optionaltext = data.accessories[i].value[a].qty; // qty accessories
                         accessoriesObj.viewType = 0; // viewType
                         accessoriesObj.data_text = data.accessories[i].value[a].product_name; // accessory choose name
                         accessoriesObj.att_totalPrice = parseInt(data.accessories[i].value[a].qty) * parseFloat(data.accessories[i].value[a].product_StartingPrice); // total price of selected values
                         accessoriesObj.attwise_Price = data.accessories[i].value[a].product_StartingPrice; // single object price
                         accessoriesObj.displayOrder = parseInt(nextIndexForAccessories);
                         attsArray.push(accessoriesObj);
                         nextIndexForAccessories = parseInt(nextIndexForAccessories) + 1;
                     }
                 }

             }

             var delAddress = {};

             if (data.deliverAddress == undefined) {
                 // Delivery Address
                 /*delAddress.FirstName = firstname; //FirstName
                 delAddress.LastName = ""; //LastName
                 delAddress.EmailID = emailid; //EmailID
                 delAddress.Address = ""; //Address
                 delAddress.City = ""; //City
                 delAddress.County = ""; //County
                 delAddress.Country = ""; //Country
                 delAddress.Zip = ""; //Zip
                 delAddress.Phone = ""; //Phone*/

                 delAddress.FirstName = $rootScope.billingAddress.deliveryadd_fName; //FirstName
                 delAddress.LastName = $rootScope.billingAddress.deliveryadd_lName; //LastName
                 delAddress.EmailID = $rootScope.billingAddress.deliveryadd_Email; //EmailIDdeliveryadd_address
                 delAddress.Address = $rootScope.billingAddress.deliveryadd_address; //Address
                 delAddress.City = $rootScope.billingAddress.deliveryadd_city; //City
                 delAddress.County = $rootScope.billingAddress.deliveryadd_county; //County
                 delAddress.Country = $rootScope.billingAddress.deliveryadd_country; //Country
                 delAddress.Zip = $rootScope.billingAddress.deliveryadd_zip; //Zip
                 delAddress.Phone = $rootScope.billingAddress.deliveryadd_mobile; //Phone
             } else {
                 // Delivery Address
                 delAddress.FirstName = data.deliverAddress.fname; //FirstName
                 delAddress.LastName = data.deliverAddress.lName; //LastName
                 delAddress.EmailID = data.deliverAddress.emailid; //EmailID
                 delAddress.Address = data.deliverAddress.address; //Address
                 delAddress.City = data.deliverAddress.city; //City
                 delAddress.County = data.deliverAddress.county; //County
                 delAddress.Country = data.deliverAddress.country; //Country
                 delAddress.Zip = data.deliverAddress.passcode; //Zip
                 delAddress.Phone = data.deliverAddress.contact; //Phone

             }
             orderObj.ShippingDetail = delAddress;
             orderObj.OrderAttributes = attsArray;
             ordersArray.push(orderObj);
         }

         order.Order = ordersArray;
         /* Orders */

         //var address = $rootScope.address[0];
         /* Billing Details */
         var billingDetails = {};
         billingDetails.FirstName = $rootScope.billingAddress.deliveryadd_fName; //FirstName
         billingDetails.LastName = $rootScope.billingAddress.deliveryadd_lName; //LastName
         billingDetails.EmailID = $rootScope.billingAddress.deliveryadd_Email; //EmailIDdeliveryadd_address
         billingDetails.Address = $rootScope.billingAddress.deliveryadd_address; //Address
         billingDetails.City = $rootScope.billingAddress.deliveryadd_city; //City
         billingDetails.County = $rootScope.billingAddress.deliveryadd_county; //County
         billingDetails.Country = $rootScope.billingAddress.deliveryadd_country; //Country
         billingDetails.Zip = $rootScope.billingAddress.deliveryadd_zip; //Zip
         billingDetails.Phone = $rootScope.billingAddress.deliveryadd_mobile; //Phone
         order.BillingDetail = billingDetails;

         return order;
     };



     //api timeout
     function apiTimeout() {
         clearTimeout(timer);
         timer = setTimeout(function() {
             $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
             $ionicLoading.hide();
         }, delay_time);
     }
     // internet check
     function internetcheck() {
         if ($cordovaNetwork.isOffline()) {
             $cordovaToast.showLongCenter("No internet connection!");
             return false;
         } else {
             return true;
         }
     }

     //list
     $scope.items = $rootScope.detail;


     function apiSaveOrderTimeout() {
         clearTimeout(timerSaveFirst);
         timerSaveFirst = setTimeout(function() {
             $cordovaToast.showLongBottom('Response is taking long time.Please  wait while we process your order');
             $ionicLoading.hide();
         }, 15000);
     }

     function apiSaveOrderDelayTimeout() {
         clearTimeout(timerSaveSecond);
         timerSaveSecond = setTimeout(function() {
             // $cordovaToast.showLongBottom('Oops! we could not confirm your order.It could be due to slow network');
             $ionicLoading.hide();
             $scope.confirmPopup2 = $ionicPopup.confirm({
                 title: 'No Connection',

                 templateUrl: 'templates/stripe_error.html',
                 scope: $scope,
                 buttons: [{
                     text: 'Try Again!!',
                     onTap: function(e) {
                         updateAPIAfterPayment(JSON.stringify($localStorage.saveOrderobj));
                         $scope.confirmPopup2.close();
                     }
                 }]

             });
         }, 30000);

     }
 });
