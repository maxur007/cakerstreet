app
    .controller(
        'FiltersearchCtrl',
        function($scope, LocalStorage, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $location, $ionicSideMenuDelegate, $window, $ionicPlatform,
            $cordovaToast, $ionicLoading, $cordovaNetwork, $cordovaToast, GetCustomerAddressesByCustomerID) {
            var timer;
            var delay_time = $rootScope.timer_delay;
            $ionicSideMenuDelegate.canDragContent(false);
            var editcustmer = $rootScope.address;
            var CustomerID = $rootScope.userdetail.userID;
            apiTimeout();
            GetCustomerAddressesByCustomerID.GetCustomerAddressesByCustomerID(CustomerID).then(function(response) {
                console.log(response);
                clearTimeout(timer);
                var resObject = JSON.parse(response);
                $rootScope.address_details = resObject.Customer_Addresses;
                console.log($rootScope.address_details);

            });
            //console.log($scope.address_details);
            //change
            $scope.myGoBack = function() {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    $ionicHistory.goBack();
                }
            };

            //variable declartion
            $scope.continue = function() {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {

                    $state.go("app.checkout");
                }

            }

            $scope.addnew = function() {
                var uid = $rootScope.userdetail.userID;
                delete $rootScope.userdetail
                    //  $rootScope.$emit("logout");
                $rootScope.userdetail.userID = uid;
                $rootScope.CustomerID = uid;
                $state.go("app.shippingaddress");
            }
            $scope.editdata = function() {
                    if ($cordovaNetwork.isOffline()) {
                        $cordovaToast.showLongCenter("No internet connection!");
                    } else {
                        $state.go("app.shippingaddress", { editData: { editableData: editcustmer } });
                    }
                }
                //api timeout
            function apiTimeout() {
                clearTimeout(timer);
                timer = setTimeout(function() {
                    $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
                    $ionicLoading.hide();
                }, delay_time);
            }

        });
