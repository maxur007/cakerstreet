app.controller('backerydetailfilterCtrl', function($scope, $state, $timeout, $cordovaNetwork, $ionicPopover,
    WebService, $rootScope, $location, GetCakesListByPostcodeAndFilters, getbakeryProducts_byBakeryid,
    $ionicSideMenuDelegate, LocalStorage, $window, $ionicPlatform, $ionicModal,
    $q, $http, $ionicPlatform, $ionicPopup, $cordovaNetwork, $ionicSlideBoxDelegate, $cordovaToast, $localStorage, $ionicLoading) {

    $ionicPlatform.registerBackButtonAction(function(event) {
        $scope.myGoBack();
    }, 100);
    var regPostcode = /^([a-zA-Z]){1}([0-9][0-9]|[0-9]|[a-zA-Z][0-9][a-zA-Z]|[a-zA-Z][0-9][0-9]|[a-zA-Z][0-9]){1}([ ])|([0-9][a-zA-z][a-zA-z]){1}$/;
    $scope.noitem = false;
    $scope.productname = "";
    $scope.isdtNameDisabled = true;
    $scope.itemNotFound = false;

    $scope.title = "";
    $scope.list = [];
    var pageno = 1;
    var pagesize = 10;
    var busyInLoading = false;
    var timer;
    var delay_time = $rootScope.timer_delay;
    $scope.cake_count = 0;
    $ionicPopup,
    $scope.search_miles = $rootScope.miles;
    $scope.data = {};
    $scope.data.milesdistance = miles;
    $scope.titlepostcode = true;
    $scope.editbtn = true;
    $scope.searchoption = false;
    $scope.noMoreItemsAvailable = false;
    $scope.bakeryIds = [];
    var miles = $rootScope.selectedvalue;
    var postalcode = $rootScope.postcode;
    $scope.data = {};

    $scope.$on("$ionicView.loaded", function(event, data) {

    });

    $scope.$on("$ionicView.beforeEnter", function(event, data) {
        $rootScope.sortcode = 0;
        $scope.sortCategoryChoose = "Relevance";
    });

    $scope.$on("$ionicView.enter", function(event, data) {
        $scope.loaderimage = true;
        $scope.itemNotFound = false;

    });

    $scope.$on("$ionicView.afterEnter", function(event, data) {

        $scope.itemNotFound = false;
        if ($state.params.filter_object == null) {
            $state.params.filter_object = $localStorage.filter_object;
        } else {
            $localStorage.filter_object = $state.params.filter_object;
        }

        //$scope.loaderimage = true;
        if ($rootScope.isBack != true || data.fromCache == false) {
            if ($localStorage.filter_object != null || $localStorage.filter_object != undefined) {
                $scope.bakeryIds = $localStorage.filter_object.bakeryids.split(",");
                $scope.bakery_Count = $scope.bakeryIds.length;
                if ($scope.data.cakelist != undefined) {
                    while ($scope.data.cakelist.length > 0) {
                        $scope.data.cakelist.pop();
                    }
                }
                 $scope.$watch('online', function(newStatus) { 
                          if(newStatus==false){
                       $scope.loaderimage = false;
                        $cordovaToast.showLongCenter("No internet connection!");
                       }
                       if(newStatus==true){
                         getlistForCakes();
                       }
                        });
              
            } else {
                $ionicLoading.hide();
                $scope.bakery_Count = 0;
                $scope.data.cakeCount = 0;
                notFound($scope.data.cakeCount == 0 ? true : false);
            }
        } else {
            $ionicLoading.hide();
        }
        $rootScope.isBack = false;
        getCartCount();
    });
    //change
    $scope.myGoBack = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.searchbusiness");
        }
    };

    $scope.bakeryDetailedInfo = [];

    function getlistForCakes() {
        if (internetcheck()) {
            apiTimeout();
            GetCakesListByPostcodeAndFilters.GetCakesListByPostcodeAndFilters($localStorage.filter_object).then(function(response) {
                $ionicLoading.hide();
                clearTimeout(timer);
                $scope.loader = false;
                var responseObject = JSON.parse(response);
                if (responseObject.ErrorID == 0) {

                    if ($scope.data.cakelist === undefined) {
                        $scope.data.cakelist = responseObject.Cakes;
                    } else {
                        $.merge($scope.data.cakelist, responseObject.Cakes);
                    }
                    $scope.data.cakeCount = responseObject.CakeCount;
                    clearTimeout(timer);
                    busyInLoading = false;
                    // $scope.loaderimage = true;
                    notFound($scope.data.cakeCount == 0 ? true : false);
                } else {
                    notFound($scope.data.cakeCount == 0 ? true : false);
                }
            }, function(err) {
                clearTimeout(timer);
                $ionicLoading.hide();
                var confirmPopup = $ionicPopup.confirm({
                    title: 'Something went wrong!',
                    scope: $scope,
                    buttons: [{
                        text: 'Try Again!!',
                        onTap: function(e) {
                            $state.go($state.current, {}, { reload: true });
                        }
                    }]
                });

            });
        } else {
            $ionicLoading.hide();
            notFound($scope.data.cakeCount == 0 ? true : false);
        }

    }

    $scope.businessClick = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.filter_detail", {
                'bakeryarray': null
            }, { 'cache': true });
        }
    }

    function notFound(val) {
        $scope.itemNotFound = val;
        $scope.itemfound = !val;
        $scope.loaderimage = false;
        $ionicLoading.hide();
    }
    /* Infinite Scroll */


    $scope.loadMore = function() {
         if ($cordovaNetwork.isOffline()) {
                $scope.loaderimage = false;
                $cordovaToast.showLongCenter("No internet connection!");
        }
        else{
        if (!busyInLoading) {
            busyInLoading = true;
            if ((parseInt(pageno) * pagesize) < $scope.data.cakeCount) {
                pageno = parseInt(pageno) + 1;
                $scope.loaderimage = true;
                $scope.noMoreItemsAvailable = false;
                $localStorage.filter_object.pageno = pageno;
                getlistForCakes();
            } else {
                $scope.loaderimage = false;
                if ($scope.data.cakeCount != undefined)
                    $scope.loaderimage = false;
                $scope.noMoreItemsAvailable = true;
            }
        }
        $scope.$broadcast('scroll.infiniteScrollComplete');
    }
    };


    /* Click cake */
    $scope.cakeDetails_ClickHandler = function(cakeID) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                var cakeObjInfo = { 'id': cakeID };
                $state.go("app.cakedetail", { 'cakeid': cakeObjInfo });
            }
        }
        //miles clicked
    $scope.milesSelected = 0;

    $scope.miles = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $ionicModal.fromTemplateUrl('templates/filtermodal.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function(modal) {
                $scope.modal = modal;
                $scope.modal.show();
            });
        }
    }
    $scope.closeModal = function() {
        $scope.modal.hide();
    };
    $scope.checkedvalue = function(selected) {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if ($rootScope.selectedvalue === selected) {
            $scope.modal.hide();
        } else {
            $scope.updateStatus = true;
            $rootScope.selectedvalue = selected;
            $scope.modal.hide();
            $state.go("app.searchbusiness");
        }

    }

    //filter click
    $scope.handleMoreEvent = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.filter", { 'backery_details': $rootScope.BakeryidObject });
        }
    }

    function getCartCount() {
        if ($rootScope.detail == undefined) {
            $scope.cartnotification = true;
            $scope.count = 0;
        } else if ($rootScope.detail.length == 0) {
            $scope.cartnotification = true;
            $scope.count = 0;
        } else {
            $scope.cartnotification = true;
            $scope.count = $rootScope.detail.length;
        }
    }

    /* header handlers and actions */
    $scope.headerEditPostalCode_ClickHandler = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $scope.postalText = $rootScope.postcode;
            $scope.editCode = true;
            setTimeout(function() {
                // $('#code').select();
                //$('#code').focus();
                cordova.plugins.Keyboard.show();
            }, 50);
        }
    };

    $scope.headerSearchPostalcode_InputHandler = function(text) {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if (!text) {
            $cordovaToast.showLongCenter("Please Enter Area Code");
            return;
        } else if (regPostcode.test(text) == false) {
            $cordovaToast.showLongBottom('Please Enter valid Postcode');
            return;
        } else if (text.length != 0) {
            $rootScope.postcode = text;
            $localStorage.postcodeSelected = $rootScope.postcode;
            $scope.editCode = false;
            setTimeout(function() {
                cordova.plugins.Keyboard.close();
                $state.go("app.searchbusiness");
            }, 50);
        }

    }

    $scope.headerPostalSearch_CloseHandler = function() {
        $scope.editCode = false;
        setTimeout(function() {
            cordova.plugins.Keyboard.close();
        }, 50);
    }

    $scope.headerSearch_CloseHandler = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $scope.editbtn = true;
            $scope.titlepostcode = true;
            $scope.searchoption = false;
            $scope.maindiv = false;
        }
    }

    $scope.headerSearch_ClickHandler = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection! ");
        } else {
            $state.go("app.searchcriteriapage");
        }
    }

    $scope.headerCart_ClickHandler = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if ($rootScope.detail.length == 0) {
            $cordovaToast.showLongBottom("Cart is empty");
        } else {
            $state.go("app.cart");
        }
    }

    $scope.headerSearch_InputHandler = function(searchcontent) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $rootScope.searchTextHeadercontent = searchcontent;
                $state.go("app.searchcriteriapage");
            }
        }
        // internet check
    function internetcheck() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
            return false;
        } else {
            return true;
        }
    }

    //api timeout
    function apiTimeout() {
        clearTimeout(timer);
        timer = setTimeout(function() {
            $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
            $ionicLoading.hide();
        }, delay_time);
    }

    //chnange
    $scope.headerCart_ClickHandler = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if ($rootScope.detail.length == 0) {
            $cordovaToast.showLongBottom("Cart is empty");
        } else {
            $state.go("app.cart");
        }
    }

    $scope.popover = $ionicPopover.fromTemplate(template, {
        scope: $scope
    });


    $ionicPopover.fromTemplateUrl('sortby-popover.html', {
        scope: $scope
    }).then(function(popover) {
        $scope.popover = popover;
    });


    $scope.openPopover = function($event) {
        $scope.popover.show($event);
    };

    $scope.closePopover = function() {
        $scope.popover.hide();
    };

    $scope.sortingCakes = function(sortValue, sortName) {
        $rootScope.sortcode = sortValue;
        $scope.sortCategoryChoose = sortName;
        $scope.popover.hide();
        $scope.data.cakelist = [];
        $state.params.filter_object.sortcode = $rootScope.sortcode;
        getlistForCakes();
    };


});
