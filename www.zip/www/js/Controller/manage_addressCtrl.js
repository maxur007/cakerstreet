app
    .controller(
        'manage_addressCtrl',
        function($scope, LocalStorage, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $location, $cordovaNetwork,
            $ionicSideMenuDelegate, LocalStore, $window, $ionicPlatform, $ionicModal,
            $q, $http, $ionicLoading, $ionicModal, $cordovaNetwork, $cordovaToast) {
            $ionicSideMenuDelegate.canDragContent(false);
            //chnage
            $scope.goBack = function() {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {

                    $state.go("app.home");
                }
            }


        });