app.controller('thanksCtrl', function($scope, $rootScope, $state, $timeout, $ionicHistory,
    WebService, $ionicSideMenuDelegate, LocalStore, LocalStorage, $window, $ionicModal,
    $q, $http, $ionicPlatform, $ionicLoading, $localStorage, $cordovaNetwork, $cordovaToast) {

    $ionicSideMenuDelegate.canDragContent(false);

    $ionicPlatform.registerBackButtonAction(function(event) {
        $state.go("app.searchbusiness");
    }, 100);


    $scope.$on("$ionicView.afterEnter", function(event, data) {
        // var cakeLength = $rootScope.detail.length;
        // for (var i = (cakeLength - 1); i >= 0; i--) {
        //     if ($rootScope.detail[i] != undefined) {
        //         console.log($rootScope.detail[i].done);
        //         if ($rootScope.detail[i].done == true) {
        //             $rootScope.detail.splice(i, 1);
        //         }
        //     }
        // }
        $rootScope.detail = [];
        $localStorage.detail = [];

    });

    $scope.continuebtn = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.searchbusiness");
        }
    };
    //change
    $scope.myGoBack = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.searchbusiness");
        }
    };

});
