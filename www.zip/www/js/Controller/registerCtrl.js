app
    .controller(
        'userRegisterCtrl',
        function($scope, $ionicPopup, LocalStorage, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $location, $stateParams,
            $ionicSideMenuDelegate, LocalStore, $window, $ionicPlatform,
            $q, $http, $cordovaToast, $ionicPlatform, $ionicLoading, $ionicModal,
            $localStorage, GetUserDetailByFacebookID, AddOnCustomerSocialMediaID,
            $cordovaOauth, $ionicLoading, $cordovaNetwork, CustomerRegistration, insertdevice) {
            console.log($rootScope.checkoutStage);
            $ionicPlatform.registerBackButtonAction(function(event) {
                $scope.myGoBack();
            }, 100);
            var timer;
            var delay_time = $rootScope.timer_delay;
            $ionicSideMenuDelegate.canDragContent(false);
            var uid;
            $scope.disableView = false;
            //change
            var deviceID = $localStorage.deviceToken;
            console.log(deviceID);

            $scope.data = {};
            var fbid = '';
            //console.log($localStorage.previousState);
            $rootScope.$on('$stateChangeSuccess', function(ev, to, toParams, from, fromParams) {

                $rootScope.previousState = from.name;
                $rootScope.currentState = to.name;
            });
            if ($localStorage.previousState == 'app.billingdetails') {
                $rootScope.billingdetailState = true
            }
            //change
            $scope.myGoBack = function() {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    window.history.back();
                }
            };

            $scope.search_click = function() {
                if ($cordovaNetwork.isOnline()) {
                    if ($scope.data.fname == '' || $scope.data.fname == undefined) {
                        $cordovaToast.showLongBottom('Please Enter Firstname');
                    } else if ($scope.data.lname == '' || $scope.data.lname == undefined) {
                        $cordovaToast.showLongBottom('Please Enter lastname');

                    } else if ($scope.data.email == '' || $scope.data.email == undefined) {
                        $cordovaToast.showLongBottom('Please Enter Email');

                    } else if (!(/^([\w]+(?:\.[\w]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/.test($scope.data.email))) {
                        $cordovaToast.showLongBottom("Please enter valid email");
                    } else if ($scope.data.password == '' || $scope.data.password == undefined) {
                        $cordovaToast.showLongBottom("Please enter password");
                    } else if ($scope.data.password.length < 6) {
                        $cordovaToast.showLongBottom("Password should be at least 6 characters");
                    } else if ($scope.data.password == '' || $scope.data.password == undefined) {
                        $cordovaToast.showLongBottom("Please enter password");
                    } else if ($scope.data.password != $scope.data.confirm_password) {
                        $cordovaToast.showLongBottom("Confirm Passwords don't match");
                    } else {
                        cordova.plugins.Keyboard.close();
                        $ionicLoading.show({
                            template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                        });
                        apiTimeout();
                        CustomerRegistration.CustomerRegistration($scope.data.email, $scope.data.fname, $scope.data.lname, $scope.data.password, fbid).then(function(response) {
                            console.log(response);
                            clearTimeout(timer);
                            var jsondata = JSON.parse("{" + response + "}");
                            console.log(jsondata.data.User[0]);
                            console.log(jsondata.data.User[0].userID);
                            console.log(jsondata.data.User[0].Name);
                            $ionicLoading.hide();


                            //console.log(jsondata.data);
                            if (jsondata.data.User[0].userID == '0') {
                                $ionicLoading.hide();
                                $rootScope.loggedin = false;
                                $rootScope.username = " Guest";
                                $cordovaToast.showLongBottom(jsondata.data.User[0].Error);

                            } else if ($rootScope.billingdetailState == true) {
                                $ionicLoading.hide();
                                $rootScope.loggedin = true;
                                $rootScope.userdetail = jsondata.data.User[0];
                                $localStorage.userDetails = $rootScope.userdetail;
                                console.log($rootScope.userdetail);
                                $rootScope.username = jsondata.data.User[0].Name;

                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                $rootScope.showFooter = true;
                                $state.go("app.shippingdetail");
                            } else if ($rootScope.checkoutStage == true) {
                                $ionicLoading.hide();
                                $rootScope.loggedin = true;
                                $rootScope.userdetail = jsondata.data.User[0];
                                $localStorage.userDetails = $rootScope.userdetail;
                                console.log($rootScope.userdetail);
                                $rootScope.username = jsondata.data.User[0].Name;

                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                $rootScope.showFooter = true;
                                $state.go("app.stripayment");
                            } else {
                                $ionicLoading.hide();
                                $rootScope.loggedin = true;
                                $rootScope.userdetail = jsondata.data.User[0];
                                $localStorage.userDetails = $rootScope.userdetail;
                                console.log($rootScope.userdetail);
                                $rootScope.username = jsondata.data.User[0].Name;
                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                //change
                                uid = jsondata.data.User[0].userID;
                                getpushApi();
                                cordova.plugins.Keyboard.close();
                                if ($rootScope.cartstage == true) {
                                    $ionicLoading.hide();
                                    $cordovaToast.showLongBottom('You have successfully registered');
                                    $state.go("app.cart");
                                } else {
                                    $ionicLoading.hide();
                                    $cordovaToast.showLongBottom('You have successfully registered');
                                    $state.go("app.home");
                                }

                            }

                        }, function(err) {
                            console.log(err);
                            clearTimeout(timer);
                            $ionicLoading.hide();
                            var confirmPopup = $ionicPopup.confirm({
                                template: 'Something went wrong!',
                                cssClass: 'popup_head_cust',
                                scope: $scope,
                                buttons: [{
                                    text: 'Try Again!!',
                                    onTap: function(e) {
                                        $state.go($state.current, {}, { reload: true });
                                    }
                                }]
                            });

                        });
                    }
                } else {
                    $ionicLoading.hide();
                    $cordovaToast.showLongCenter("No internet connection!");
                }
            }

            $scope.registerSubmit = function(data) {
                if ($cordovaNetwork.isOnline()) {
                    if (data.fname == '' || data.fname == undefined) {
                        $cordovaToast.showLongBottom('Please Enter Firstname');
                    } else if (data.lname == '' || data.lname == undefined) {
                        $cordovaToast.showLongBottom('Please Enter lastname');

                    } else if (data.email == '' || data.email == undefined) {
                        $cordovaToast.showLongBottom('Please Enter Email');

                    } else if (!(/^([\w]+(?:\.[\w]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/.test(data.email))) {
                        $cordovaToast.showLongBottom("Please enter valid email");
                    } else if (!(/^([\w]+(?:\.[\w]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/.test(data.email))) {
                        $cordovaToast.showLongBottom("Please enter valid email");
                    } else if (data.password == '' || data.password == undefined) {
                        $cordovaToast.showLongBottom("Please enter password");
                    } else if (data.password.length < 6) {
                        $cordovaToast.showLongBottom("Password should be at least 6 characters");
                    } else if (data.password == '' || data.password == undefined) {
                        $cordovaToast.showLongBottom("Please enter password");
                    } else if (data.password != data.confirm_password) {
                        $cordovaToast.showLongBottom("Confirm Passwords don't match");
                    } else {

                        // $ionicLoading.show();
                        $ionicLoading.show({
                            noBackdrop: false,
                            template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                        });
                        apiTimeout();
                        CustomerRegistration.CustomerRegistration(data.email, data.fname, data.lname, data.password, fbid).then(function(response) {
                            console.log(response);
                            var jsondata = JSON.parse("{" + response + "}");
                            $ionicLoading.hide();
                            clearTimeout(timer);
                            if (jsondata.data.User[0].userID == '0') {
                                $ionicLoading.hide();
                                $rootScope.loggedin = false;
                                $rootScope.username = "Guest";
                                $cordovaToast.showLongBottom(jsondata.data.User[0].Error);
                                $rootScope.emailexist = jsondata.data.User[0].Error;

                            } else if ($rootScope.billingdetailState == true) {
                                console.log($rootScope.billingdetailState);
                                $ionicLoading.hide();
                                $rootScope.loggedin = true;
                                $rootScope.userdetail = jsondata.data.User[0];
                                $localStorage.userDetails = $rootScope.userdetail;
                                console.log($rootScope.userdetail);
                                $rootScope.username = jsondata.data.User[0].Name;
                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                $rootScope.showFooter = true;
                                $state.go("app.shippingdetail");
                            } else if ($rootScope.checkoutStage == true) {
                                console.log($rootScope.billingdetailState);
                                $ionicLoading.hide();
                                $rootScope.loggedin = true;
                                $rootScope.userdetail = jsondata.data.User[0];
                                $localStorage.userDetails = $rootScope.userdetail;
                                console.log($rootScope.userdetail);
                                $rootScope.username = jsondata.data.User[0].Name;
                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                $rootScope.showFooter = true;
                                $state.go("app.stripayment");
                            } else {
                                $ionicLoading.hide();
                                $rootScope.loggedin = true;
                                $rootScope.userdetail = jsondata.data.User[0];
                                $localStorage.userDetails = $rootScope.userdetail;
                                console.log($rootScope.userdetail);
                                $rootScope.username = jsondata.data.User[0].Name;
                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                //chnage
                                uid = jsondata.data.User[0].userID;
                                console.log(uid);
                                getpushApi();
                                if ($rootScope.cartstage == true) {
                                    $ionicLoading.hide();
                                    $cordovaToast.showLongBottom('You have successfully registered');
                                    $state.go("app.cart");
                                } else {
                                    $ionicLoading.hide();
                                    $cordovaToast.showLongBottom('You have successfully registered');
                                    $state.go("app.home");
                                }
                            }
                        }, function(err) {
                            console.log(err);
                            clearTimeout(timer);
                            $ionicLoading.hide();
                            var confirmPopup = $ionicPopup.confirm({
                                template: 'Something went wrong!',
                                cssClass: 'popup_head_cust',
                                scope: $scope,
                                buttons: [{
                                    text: 'Try Again!!',
                                    onTap: function(e) {
                                        $state.go($state.current, {}, { reload: true });
                                    }
                                }]
                            });

                        });
                    }
                } else {
                    $ionicLoading.hide();
                    $cordovaToast.showLongCenter("No internet connection!");
                }
            }

            function getpushApi() {
                insertdevice.insertdevice(deviceID, uid).then(function(response) {
                    console.log(response);
                });
            }
            //api timeout
            function apiTimeout() {
                clearTimeout(timer);
                timer = setTimeout(function() {
                    $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
                    $ionicLoading.hide();
                }, delay_time);
            }


            $scope.loginFB = function() {

                if ($cordovaNetwork.isOnline()) {
                    ////facebokplugin 

                    facebookConnectPlugin.login(["email", "public_profile"], function(response) {
                        console.log(response);
                        console.log(JSON.stringify(response));
                        if (response.authResponse) {
                            facebookConnectPlugin.api("me/?fields=name,gender,location,picture,email", null,
                                function(response) {
                                    console.log(response);
                                    $ionicLoading.show({
                                        noBackdrop: false,
                                        template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                                    });
                                    // alert(JSON.stringify(response));
                                    console.log(JSON.stringify(response));
                                    $localStorage.userFbImg = response.picture.data.url;
                                    var nameDetails = response.name.split(' ');
                                    var name = nameDetails[0];
                                    var surname = " - ";
                                    if (nameDetails.length > 1) {
                                        surname = nameDetails[1];
                                    }
                                    $ionicLoading.show({
                                        noBackdrop: false,
                                        template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                                    });
                                    $cordovaToast.showLongBottom("Please wait we are connecting with SocialMedia");
                                    $scope.disableView = true;
                                    loginConfirm(name, surname, response.email, response.id, 1);
                                });


                        } else {
                            $scope.disableView = false;
                        }
                    });

                    // $http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';  
                } else {
                    $ionicLoading.hide();
                    $cordovaToast.showLongBottom("Please check your internet");
                }
            }

            function loginConfirm(fname, lname, emailid, socialmediaID, socialmediaType) {
                apiTimeout();
                $cordovaToast.showLongBottom("Please wait we are connecting with SocialMedia");
                $ionicLoading.show({
                    noBackdrop: false,
                    template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                });

                GetUserDetailByFacebookID.GetUserDetailByFacebookID(socialmediaType, socialmediaID).then(function(response) {
                    var jsondata = JSON.parse(response);
                    $ionicLoading.hide();
                    console.log(jsondata);
                    clearTimeout(timer);
                    if (jsondata.ErrorID == 1) {
                        // Error Not found
                        var pwd = (fname + lname);
                        CustomerRegistration.CustomerRegistration(emailid, fname, lname, pwd, socialmediaID, socialmediaType, $localStorage.postcodeSelected).then(function(responseReg) {
                            var jsondataReg = JSON.parse("{" + responseReg + "}");
                            $ionicLoading.hide();
                            if (jsondataReg != null) {
                                if (jsondataReg.data.Error == undefined || jsondataReg.data.Error == "") {
                                    $rootScope.userdetail = jsondataReg.data.User[0];
                                    $localStorage.userDetails = jsondataReg.data.User[0];
                                    $ionicLoading.hide();
                                    $rootScope.CustomerID = jsondataReg.data.User[0].userID;
                                    if (jsondataReg.data.User[0].userID == 0) {
                                        $ionicLoading.hide();
                                        $rootScope.CustomerID = jsondataReg.data.User[0].userID;
                                        // $cordovaToast.showLongBottom(jsondataReg.data.User[0].Error);
                                        AddOnCustomerSocialMediaID.AddOnCustomerSocialMediaID(emailid, socialmediaType, socialmediaID).then(function(responseReg) {
                                            console.log(responseReg);
                                            var jsondata = JSON.parse("{" + responseReg + "}");
                                            $localStorage.userDetails = jsondata.data.User[0];

                                            if (jsondata.data.User[0].userID == '0') {
                                                $ionicLoading.hide();
                                                cordova.plugins.Keyboard.close();
                                                $rootScope.loggedin = false;
                                                $localStorage.loggedin = $rootScope.loggedin;
                                                $rootScope.username = " Guest";

                                                $cordovaToast.showLongBottom(jsondata.data.User[0].Error);
                                                $state.go("app.login");
                                            } else if ($localStorage.previousState == 'app.billingdetails') {

                                                $rootScope.loggedin = true;
                                                $localStorage.loggedin = $rootScope.loggedin;
                                                $rootScope.userdetail = jsondata.data.User[0];
                                                $localStorage.userDetails = $rootScope.userdetail;
                                                $rootScope.username = jsondata.data.User[0].Name;

                                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                                $rootScope.showFooter = true;
                                                $state.go("app.shippingdetail");

                                                $ionicLoading.hide();

                                            } else if ($rootScope.previousState == 'app.cart') {

                                                $rootScope.loggedin = true;
                                                $localStorage.loggedin = $rootScope.loggedin;
                                                $rootScope.userdetail = jsondata.data.User[0];
                                                $localStorage.userDetails = $rootScope.userdetail;
                                                $rootScope.username = jsondata.data.User[0].Name;

                                                $rootScope.CustomerID = jsondata.data.User[0].userID;
                                                //change
                                                uid = jsondata.data.User[0].userID;
                                                getpushApi();

                                                $ionicLoading.hide();
                                                // $state.go("app.filtersrch");
                                                if (delivery == true) {
                                                    $localStorage.userDetails = $rootScope.userdetail;
                                                    $rootScope.showFooter = true;
                                                    $state.go("app.shippingdetail");
                                                } else {
                                                    $localStorage.userDetails = $rootScope.userdetail;
                                                    $state.go("app.checkout");

                                                }
                                            } else {
                                                $rootScope.loggedin = true;
                                                $localStorage.loggedin = $rootScope.loggedin;
                                                $ionicLoading.hide();
                                                $rootScope.loggedin = true;
                                                $rootScope.userdetail = jsondata.data.User[0];

                                                $rootScope.username = jsondata.data.User[0].Name;
                                                $rootScope.CustomerID = jsondata.data.User[0].userID;

                                                // getpushApi();

                                                // $ionicLoading.hide();
                                                $localStorage.userDetails = jsondata.data.User[0];
                                                console.log("logging");
                                                $cordovaToast.showLongBottom('Logged in successfully!');
                                                //  $state.go("app.home");
                                                if ($localStorage.postcodeSelected != undefined) {
                                                    $state.go('app.searchbusiness');
                                                } else {
                                                    $state.go('app.home');
                                                }
                                            }


                                        });

                                    } else {
                                        $rootScope.loggedin = true;
                                        $ionicLoading.hide();
                                        $cordovaToast.showLongBottom('Logged in successfully!');
                                        // $state.go('app.home');
                                        if ($localStorage.postcodeSelected != undefined) {
                                            $state.go('app.searchbusiness');
                                        } else {
                                            $state.go('app.home');
                                        }
                                    }

                                } else {
                                    $ionicLoading.hide();
                                    $cordovaToast.showLongBottom(jsondataReg.data.Error);
                                }
                            } else {
                                $ionicLoading.hide();
                                $cordovaToast.showLongBottom("Something went wrong! Please check your login deatils.");
                            }
                        });
                    } else if ($localStorage.previousState == 'app.billingdetails') {

                        // Found in cakerstreet
                        $rootScope.loggedin = true;
                        $localStorage.loggedin = $rootScope.loggedin;
                        $rootScope.userdetail = jsondata.User;
                        $rootScope.CustomerID = jsondata.User.userID;
                        $localStorage.userDetails = jsondata.User;
                        $rootScope.showFooter = true;
                        $state.go("app.shippingdetail");

                        $ionicLoading.hide();

                    } else if ($rootScope.billingdetailState == true) {
                        $ionicLoading.hide();
                        $rootScope.loggedin = true;
                        $localStorage.loggedin = $rootScope.loggedin;
                        $rootScope.userdetail = jsondata.User;
                        $rootScope.CustomerID = jsondata.User.userID;
                        $localStorage.userDetails = jsondata.User;
                        $rootScope.showFooter = true;
                        $state.go("app.shippingdetail");
                    } else if ($rootScope.checkoutStage == true) {
                        $ionicLoading.hide();
                        $rootScope.loggedin = true;
                        $localStorage.loggedin = $rootScope.loggedin;
                        $rootScope.userdetail = jsondata.User;
                        $rootScope.CustomerID = jsondata.User.userID;
                        $localStorage.userDetails = jsondata.User;
                        $rootScope.showFooter = true;
                        $state.go("app.stripayment");
                    } else {
                        // Found in cakerstreet
                        $rootScope.loggedin = true;
                        $localStorage.loggedin = $rootScope.loggedin;
                        $rootScope.userdetail = jsondata.User;
                        $rootScope.CustomerID = jsondata.User.userID;
                        $localStorage.userDetails = jsondata.User;

                        $ionicLoading.hide();
                        $cordovaToast.showLongBottom('Logged in successfully!');
                        if ($localStorage.postcodeSelected != undefined) {
                            $state.go('app.searchbusiness');
                        } else {
                            $state.go('app.home');
                        }
                        //  $state.go('app.home');
                    }
                }, function(err) {
                    console.log(err);
                    clearTimeout(timer);
                    $ionicLoading.hide();
                    var confirmPopup = $ionicPopup.confirm({
                        template: 'Something went wrong!',
                        cssClass: 'popup_head_cust',
                        scope: $scope,
                        buttons: [{
                            text: 'Try Again!!',
                            onTap: function(e) {
                                $state.go($state.current, {}, { reload: true });
                            }
                        }]
                    });

                });
            }

            $scope.loginGoogle = function() {
                $scope.disableView = true;
                if ($cordovaNetwork.isOnline()) {
                    $ionicLoading.show({
                        noBackdrop: false,
                        template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                    });

                    window.plugins.googleplus.login({},
                        function(user_data) {

                            $localStorage.userFbImg = user_data.imageUrl;

                            if (user_data.email != null) {

                                var surname = " - ";

                                var name = "";
                                if (user_data.familyName == "") {

                                    surname = " - ";
                                } else {
                                    surname = user_data.familyName;

                                }
                                if (user_data.givenName == "") {
                                    if (user_data.givenName == "") {
                                        name = user_data.email.substring(0, user_data.email.lastIndexOf('@'));
                                    } else {
                                        name = user_data.givenName;
                                    }
                                } else {
                                    name = user_data.givenName;
                                }
                                $cordovaToast.showLongBottom("Please wait we are connecting with SocialMedia");
                                loginConfirm(name, surname, user_data.email, user_data.userId, 2);
                                uid = user_data.userId;
                                console.log(uid);

                                $ionicLoading.hide();
                            } //$state.go('app.home');
                        },
                        function(msg) {
                            $ionicLoading.hide();
                            $scope.disableView = false;
                            console.log(msg);
                        }
                    );
                } else {
                    $ionicLoading.hide();

                    $cordovaToast.showLongBottom("Please check your internet");
                }
            }
        });
