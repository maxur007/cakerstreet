app
    .controller(
        'forgetpwdCtrl',
        function($scope, $stateParams, LocalStorage, $state, $timeout, $ionicHistory,
            $rootScope, $ionicSideMenuDelegate, $ionicPlatform, $q, $http, $cordovaToast, $ionicLoading, $cordovaNetwork,
            $ionicPopup, ForgotPWD) {
            $ionicSideMenuDelegate.canDragContent(false);
            $scope.myGoBack = function() {
                $state.go("app.login");
            };
            var timer;
            var delay_time = $rootScope.timer_delay;

            $scope.data = {};
            //change
            $scope.forgotPadssword = function(text) {
                    if ($cordovaNetwork.isOffline()) {
                        $cordovaToast.showLongCenter("No internet connection!");
                    } else if (!text) {
                        $cordovaToast.showLongBottom('Please Enter Email');
                    } else {
                        if ($cordovaNetwork.isOnline()) {
                            apiTimeout();
                            ForgotPWD.ForgotPWD(text).then(function(response) {
                                console.log(response);
                                clearTimeout(timer);
                                var jsondata = JSON.parse("{" + response + "}");
                                console.log(jsondata);
                                if (jsondata.data.Status[0].Error == 1) {
                                    $cordovaToast.showLongBottom("Email not exists.");

                                } else {
                                    $scope.data.forgotPassword = '';
                                    $cordovaToast.showLongBottom(jsondata.data.Status[0].Error);

                                }
                            });
                        } else {
                            $ionicLoading.hide();
                            $cordovaToast.showLongBottom("Please check your internet");
                        }
                    }
                }
                //api timeout
            function apiTimeout() {
                timer = setTimeout(function() {
                    $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
                    $ionicLoading.hide();
                }, delay_time);
            }

        });
