app
    .controller(
        'helpcenterCtrl',
        function($scope, LocalStorage, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $location,
            $ionicSideMenuDelegate, LocalStore, $window, $ionicPlatform, $ionicModal,
            $q, $http, $cordovaToast, $ionicLoading, $ionicModal, $cordovaNetwork) {
            $ionicSideMenuDelegate.canDragContent(false);
            //change
            $scope.goBack = function() {
                // if ($cordovaNetwork.isOffline()) {
                //     $cordovaToast.showLongCenter("No internet connection!");
                // } else {
                    $state.go("app.home");
                // }
            }


        });