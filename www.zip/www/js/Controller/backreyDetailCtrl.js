app.controller(
    'backreyDetailCtrl',
    function($scope, $stateParams, $state, $timeout,
        WebService, $rootScope, $location, $ionicHistory,
        $ionicSideMenuDelegate, $window, $ionicModal, $cordovaNetwork,
        $q, $http, $cordovaToast, $ionicLoading, $cordovaToast, $ionicPopup, $ionicLoading,
        GetBakeriesAndCakesBypostcodeAndMiles, $ionicPopup, $ionicPlatform, GetCakesByPostcodeAndMiles, $ionicPopup, getbakeryProducts_byBakeryid, $localStorage) {
        var count;
        var bakeryDetailsbyarray;
        $ionicPlatform.registerBackButtonAction(function(event) {
            $scope.myGoBack();
        }, 100);
        var regPostcode = /^([a-zA-Z]){1}([0-9][0-9]|[0-9]|[a-zA-Z][0-9][a-zA-Z]|[a-zA-Z][0-9][0-9]|[a-zA-Z][0-9]){1}([ ])|([0-9][a-zA-z][a-zA-z]){1}$/;
        $scope.objList = [];
        $ionicSideMenuDelegate.canDragContent(false);
        $scope.searchmiles = [];
        $scope.cakesArray = [];
        $scope.cakes_display = [];
        $scope.selected = ''
        var bakery_pagesize = 50;
        /* Method to fatch one ny one the bakery details */
        $scope.bakeryDetailedInfo = [];
        $scope.cake_count = 0;
        $scope.itemNotFound = false;
        $scope.milesSelected = 0;
        var selectedMiles = '';
        $scope.search_miles = $rootScope.miles;
        $scope.bakerylistArray = [];
        $scope.titlepostcode = true;
        $scope.editbtn = true;
        $scope.searchoption = false;
        $scope.loading = true;
        var pagesize = 10;
        var pageno = 1;
        var timer;
        var delay_time = $rootScope.timer_delay;
        var intervalTimer = 0;
        $scope.data = {};

        //change
        $scope.myGoBack = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $state.go("app.searchbusiness");
            }
        }

        $scope.$on("$ionicView.loaded", function(event, data) {
            // $ionicLoading.show({
            //     template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
            // });

        });
        $scope.$on("$ionicView.beforeEnter", function(event, data) {

            $ionicLoading.show({
                template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
            });

            var loadFromAPI = false;
            if (data.fromCache == false) {
                loadFromAPI = true;
            } else {
                var isSameObj = false;
                if ($localStorage.bakeryarray != null && $state.params.bakeryarray != null) {
                    isSameObj = isEquivalent($localStorage.bakeryarray, $state.params.bakeryarray);
                }
                loadFromAPI = !isSameObj;
                $scope.$apply();
            }

            if (loadFromAPI || $localStorage.miles !== $rootScope.selectedvalue || $localStorage.postcode !== $rootScope.postcode) {
                // Avoid to load again in case values are same for previous search
                //$localStorage.miles = $rootScope.selectedvalue;
                //$localStorage.postcode = $rootScope.postcode;
                while ($scope.bakeryDetailedInfo.length > 0) {
                    $scope.bakeryDetailedInfo.pop();
                }
                //delete $scope.bakeryDetailedInfo;
                //$scope.bakeryDetailedInfo = [];
                $scope.cake_count = 0;
                if ($state.params.singleClicked == true) {
                    $localStorage.bakeryarray = $state.params.bakeryarray;
                }
                $rootScope.BakeryidObject = $state.params.bakeryarray;
                 $scope.$watch('online', function(newStatus) { 
                          if(newStatus==false){
                       $scope.loaderimage = false;
                        $cordovaToast.showLongCenter("No internet connection!");
                       }
                       if(newStatus==true){
                          getBakeries(1, $state.params.singleClicked);
                       }
                        });
             
                intervalTimer = setInterval(checkLoadedContent, 1000);
            } else {
                $ionicLoading.hide();
                if ($localStorage.bakeryarray != null) {
                    if ($localStorage.bakeryarray.length == 0) {
                        scope.itemNotFound = true;
                        $scope.loading = false;
                    }
                }
            }
            getcount();
        });
        $scope.$on("$ionicView.enter", function(event, data) {
            // $ionicLoading.show({
            //     template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
            // })

        });
        $scope.$on("$ionicView.afterEnter", function(event, data) {});

        function isEquivalent(a, b) {
            // Create arrays of property names
            var aProps = Object.getOwnPropertyNames(a);
            var bProps = Object.getOwnPropertyNames(b);

            // If number of properties is different,
            // objects are not equivalent
            if (aProps.length != bProps.length) {
                return false;
            }

            for (var i = 0; i < aProps.length; i++) {
                var propName = aProps[i];

                // If values of same property are not equal,
                // objects are not equivalent
                if (a[propName] !== b[propName]) {
                    if ((a[propName] instanceof Object) && (b[propName] instanceof Object)) {
                        if (JSON.stringify(a[propName]) === JSON.stringify(b[propName])) {
                            return true;
                        }
                    }
                    return false;
                }
            }
            // If we made it this far, objects
            // are considered equivalent
            return true;
        }


        function checkLoadedContent() {
            if ($localStorage.bakeryarray != null) {
                if ($localStorage.bakeryarray.length == 0) {
                    clearInterval(intervalTimer);
                    $scope.itemNotFound = true;
                    $scope.loading = false;
                    $ionicLoading.hide();
                } else {
                    if ($scope.bakeryDetailedInfo.length === $localStorage.bakeryarray.length) {
                        clearInterval(intervalTimer);
                        setTimeout(function() {
                            $scope.itemNotFound = false;
                            $scope.loading = false;
                            $ionicLoading.hide();
                        }, 50);
                    }
                }
            }
        }

        function getBakeries(pageno2load, isSingleBakery) {
            clearTimeout(timer);
            $scope.loading = true;
            $scope.itemNotFound = false;
            if (internetcheck()) {
                apiTimeout();
                if (isSingleBakery) {
                    $scope.bakery_Count = 1;
                    getCakesForBakery($localStorage.bakeryarray);
                } else {
                    GetBakeriesAndCakesBypostcodeAndMiles
                        .GetBakeriesAndCakesBypostcodeAndMiles(pageno2load, bakery_pagesize,
                            $localStorage.postcode, $localStorage.miles).then(function(response) {
                            clearTimeout(timer);
                            var resObject = JSON.parse(response);
                            if (resObject.ErrorID == 0) {
                                $localStorage.bakeryarray = resObject.Bakeries;
                                $scope.bakery_Count = $localStorage.bakeryarray.length;
                                getDetailsFromBakeries($localStorage.bakeryarray);
                            } else {
                                // Error from API
                                $ionicLoading.hide();
                                $scope.itemNotFound = true;
                                $cordovaToast.showLongCenter(resObject.ErrorMsg);
                            }
                        }, function(err) {
                            clearTimeout(timer);
                            $ionicLoading.hide();
                            var confirmPopup = $ionicPopup.confirm({
                                template: 'Something went wrong!',
                                scope: $scope,
                                buttons: [{
                                    text: 'Try Again!!',
                                    onTap: function(e) {
                                        $state.go($state.current, {}, { reload: true });
                                    }
                                }]
                            });

                        });
                }

            } else {
                clearTimeout(timer);
                // Replace with New Design for internet connectivity
                $ionicLoading.hide();
                $scope.itemNotFound = true;
                $cordovaToast.showLongCenter(resObject.ErrorMsg);
            }
        }

        function apiTimeout() {
            clearTimeout(timer);
            timer = setTimeout(function() {
                $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
                $ionicLoading.hide();
            }, delay_time);
        }


        function getDetailsFromBakeries(backerylist) {
            if ($localStorage.bakeryarray.length != 0) {
                for (var i in backerylist) {
                    $ionicLoading.show({
                        template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
                    });
                    getCakesForBakery(backerylist[i]);
                }
            } else {
                //$scope.loading = false;
                $scope.itemNotFound = true;
            }
        }
        /* Method to fetch the data for bakeries*/
        function getCakesForBakery(bakeryDetails) {
            bakeryDetailsbyarray = bakeryDetails;
            if (internetcheck()) {
                var bakeryInfo = {};
                apiTimeout();
                getbakeryProducts_byBakeryid.getbakeryProducts_byBakeryid(pageno, pagesize, bakeryDetails.webstore_ID).then(function(response) {
                    var jsondata = JSON.parse("{" + response + "}");
                    console.log(jsondata);
                    clearTimeout(timer);
                    bakeryInfo.bakery = bakeryDetails;
                    //   bakeryInfo.cakes = jsondata.data.BakeryProducts;
                    count = jsondata.data.TotalRows;
                    bakeryInfo.cakesCount = parseInt(jsondata.data.TotalRows);
                    $scope.cake_count += parseInt(jsondata.data.TotalRows);
                    $scope.bakeryDetailedInfo.push(bakeryInfo);
                    for (var i = 0; i < jsondata.data.BakeryProducts.length; i++) {
                        $scope.cakesArray.push(jsondata.data.BakeryProducts[i]);
                        if (jsondata.data.BakeryProducts[i].webstore_IsCollectable == "True") {
                            $scope.webstore_IsCollectable = true;
                        } else {
                            $scope.webstore_IsCollectable = false;
                        }
                        if (jsondata.data.BakeryProducts[i].webstore_IsDeliverable == "True") {
                            $scope.webstore_IsDeliverable = true;
                        } else {
                            $scope.webstore_IsDeliverable = false;
                        }
                    }

                    console.log($scope.cakesArray);
                    busyInLoading = false;
                    $ionicLoading.hide();
                }, function(err) {
                    clearTimeout(timer);
                    $ionicLoading.hide();
                    var confirmPopup = $ionicPopup.confirm({
                        template: 'Something went wrong!',
                        scope: $scope,
                        buttons: [{
                            text: 'Try Again!!',
                            onTap: function(e) {
                                $state.go($state.current, {}, { reload: true });
                            }
                        }]
                    });

                });

            } else {
                clearTimeout(timer);
                // Replace with New Design for internet connectivity
                $ionicLoading.hide();
                $scope.itemNotFound = true;
                $cordovaToast.showLongCenter(resObject.ErrorMsg);
            }

        };

        $scope.detailOfProduct = function(cakeID) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                var cakeObjInfo = { 'id': cakeID };
                $state.go("app.cakedetail", { 'cakeid': cakeObjInfo });
            }
        };

        $scope.miles = function(e) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $ionicModal.fromTemplateUrl('templates/milesradiobutton.html', {
                    scope: $scope,
                    animation: 'fade-in-up',
                }).then(function(modal) {
                    $scope.modal = modal;
                    $scope.modal.show();
                });
            }
        }

        $scope.closeModal = function() {
            $scope.modal.hide();
        };

        $scope.checked = function(selected) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if ($rootScope.selectedvalue === selected) {
                $scope.modal.hide();
            } else {
                $scope.updateStatus = true;
                $rootScope.selectedvalue = selected;
                $scope.modal.hide();
                $state.go('app.searchbusiness');

            }
        };

        $scope.cakeDetails_ClickHandler = function(cakeID) {
            console.log(cakeID);
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                var cakeObjInfo = { 'id': cakeID };
                $state.go("app.cakedetail", { 'cakeid': cakeObjInfo });
            }
        }

        //more cakes
        $scope.morecakes = function(bakeryObj) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $localStorage.webstore_ID = bakeryObj.webstore_ID;
                $rootScope.stateName = "app.filter_detail";
                $state.go("app.allproducts", { 'bakeryinfo': bakeryObj });
            }
        }
        $scope.moreFilterpage = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $state.go("app.filter");
            }
        }
        $scope.handleMoreEvent = function(backery) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $rootScope.BakeryidObject = backery;
                $state.go("app.filter");
            }
        }

        function getcount() {
            if ($rootScope.detail == undefined) {

                $scope.cartnotification = true;
                $scope.count = 0;
            } else if ($rootScope.detail.length == 0) {
                $scope.cartnotification = true;
                $scope.count = 0;
            } else {
                $scope.cartnotification = true;
                $scope.count = $rootScope.detail.length;
            }
        }

        /* header handlers and actions */
        $scope.headerEditPostalCode_ClickHandler = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $scope.postalText = $rootScope.postcode;
                $scope.editCode = true;
                setTimeout(function() {
                    //$('#code').select();
                    //$('#code').focus();
                    cordova.plugins.Keyboard.show();
                }, 50);
            }

        };
        $scope.headerSearchPostalcode_InputHandler = function(text) {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if (!text) {
                $cordovaToast.showLongCenter("Please Enter Area Code");
                return;
            } else if (regPostcode.test(text) == false) {
                $cordovaToast.showLongBottom('Please Enter valid Postcode');
                return;
            } else if (text.length != 0) {
                $rootScope.postcode = text;
                $localStorage.postcodeSelected = $rootScope.postcode;
                $scope.editCode = false;
                setTimeout(function() {
                    cordova.plugins.Keyboard.close();
                }, 50);
                $state.go('app.searchbusiness');

            } else {
                $cordovaToast.showLongBottom("Please enter valid postalcode");
            }
        }


        $scope.headerPostalSearch_CloseHandler = function() {
            $scope.editCode = false;
            setTimeout(function() {
                cordova.plugins.Keyboard.close();
            }, 50);
        }

        $scope.headerSearch_ClickHandler = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else {
                $state.go("app.searchcriteriapage");
            }
        }

        $scope.headerCart_ClickHandler = function() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
            } else if ($rootScope.detail.length == 0) {
                $cordovaToast.showLongBottom("Cart is empty");
            } else {
                $state.go("app.cart");
            }
        }
        var scrolled = 0;
        $scope.upClick = function() {

            scrolled = scrolled + 300;
            $(".cover").animate({
                scrollTop: scrolled
            });
        }

        $scope.downClick = function() {

                scrolled = scrolled - 500;

                $(".cover").animate({
                    scrollTop: scrolled
                });

            }
            // internet check
        function internetcheck() {
            if ($cordovaNetwork.isOffline()) {
                $cordovaToast.showLongCenter("No internet connection!");
                return false;
            } else {
                return true;
            }
        }

        /* Infinite Scroll */
        var busyInLoading = false;
        $scope.loadMore = function() {
            //if($scope.data.cakeCount != undefined){
          if ($cordovaNetwork.isOffline()) {
              $scope.loaderimage = false;
                $cordovaToast.showLongCenter("No internet connection!");
            }
            else{
            if (!busyInLoading) {
                busyInLoading = true;
                if ((parseInt(pageno) * pagesize) < count) {
                    pageno = parseInt(pageno) + 1;
                    $scope.loaderimage = true;
                    getCakesForPagination(pageno)
                    $scope.noMoreItemsAvailable = false;

                } else {
                    $scope.loaderimage = false;
                    if (count != undefined)
                        $scope.loaderimage = false;
                    $scope.noMoreItemsAvailable = true;
                }
            }
            $scope.$broadcast('scroll.infiniteScrollComplete');
        }
        };

        function getCakesForPagination(pageno) {

            if (internetcheck()) {

                apiTimeout();
                getbakeryProducts_byBakeryid.getbakeryProducts_byBakeryid(pageno, pagesize, bakeryDetailsbyarray.webstore_ID).then(function(response) {
                        var jsondata = JSON.parse("{" + response + "}");
                        console.log(jsondata);
                        clearTimeout(timer);
                        for (var i = 0; i < jsondata.data.BakeryProducts.length; i++) {
                            $scope.cakesArray.push(jsondata.data.BakeryProducts[i]);
                            if (jsondata.data.BakeryProducts[i].webstore_IsCollectable == "True") {
                                $scope.webstore_IsCollectable = true;
                            } else {
                                $scope.webstore_IsCollectable = false;
                            }
                            if (jsondata.data.BakeryProducts[i].webstore_IsDeliverable == "True") {
                                $scope.webstore_IsDeliverable = true;
                            } else {
                                $scope.webstore_IsDeliverable = false;
                            }
                        }
                        console.log($scope.cakesArray);
                        busyInLoading = false;
                        $ionicLoading.hide();
                    },
                    function(err) {
                        clearTimeout(timer);
                        $ionicLoading.hide();
                        var confirmPopup = $ionicPopup.confirm({
                            template: 'Something went wrong!',
                            scope: $scope,
                            buttons: [{
                                text: 'Try Again!!',
                                onTap: function(e) {
                                    $state.go($state.current, {}, { reload: true });
                                }
                            }]
                        });

                    });

            } else {
                clearTimeout(timer);
                // Replace with New Design for internet connectivity
                $ionicLoading.hide();
                $scope.itemNotFound = true;
                $cordovaToast.showLongCenter(resObject.ErrorMsg);
            }

        };
    });
