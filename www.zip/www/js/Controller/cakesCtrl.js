app
    .controller(
        'cakesCtrl',
        function($scope, LocalStorage, $state, $timeout, $ionicHistory,
            $rootScope, $location, $cordovaNetwork,
            $ionicSideMenuDelegate, $window,
            $q, $http, $cordovaToast, $ionicLoading, $ionicPopup, $ionicModal, $cordovaNetwork, $ionicPlatform, $cordovaCamera, $cordovaImagePicker, $ionicActionSheet, $timeout, $cordovaCamera, GetCakeAttributesListByCakeID, GetBakeriesAndCakesBypostcodeAndMiles, $cordovaToast, GetCakesByPostcodeAndMiles, GetCakedetailByCakeID) {

            $ionicHistory.nextViewOptions({
                historyRoot: true
            });
            $ionicSideMenuDelegate.canDragContent(false);
            $scope.searchmiles = [];
            $scope.selected = '';
            var selectedMiles = '';
            $scope.search_miles = $rootScope.miles;

            $scope.titlepostcode = true;
            $scope.editbtn = true;
            $scope.searchoption = false;
            var pagesize = 10;
            var pageno = 1;
            var miles = $rootScope.selectedvalue;
            var postalcode = $rootScope.postcode;
            var timer;
            var delay_time = $rootScope.timer_delay;
            $scope.data = {};
            $scope.data.milesdistance = miles;
            $scope.$on("$ionicView.loaded", function(event, data) {
                $scope.loader = true;
                //  window.plugins.spinnerDialog.show(null, null, true);
                $ionicHistory.nextViewOptions({
                    historyRoot: true
                });
                // window.plugins.spinnerDialog.show(null, null, true);
            });
            $scope.$on("$ionicView.beforeEnter", function(event, data) {
                $scope.loader = true;
                $ionicHistory.nextViewOptions({
                    historyRoot: true
                });

            });
            $scope.$on("$ionicView.enter", function(event, data) {

                $ionicHistory.nextViewOptions({
                    historyRoot: true
                });
            });
            $scope.$on("$ionicView.afterEnter", function(event, data) {
                $ionicHistory.nextViewOptions({
                    historyRoot: true
                });
                makeAPI_Call(pageno);
            });

            function makeAPI_Call(pageno2load) {
                apiTimeout();
                GetBakeriesAndCakesBypostcodeAndMiles.GetBakeriesAndCakesBypostcodeAndMiles(pageno, pagesize,
                    postalcode, miles).then(function(response) {
                    clearTimeout(timer);
                    var resObject = JSON.parse(response);
                    if (resObject.ErrorID == 0) {
                        $ionicLoading.hide();

                        $scope.data.bakerylist = resObject.Bakeries;
                        $scope.data.bakeryCount = resObject.BakeryCount;

                    } else {
                        // Error from API
                        $ionicLoading.hide();
                    }
                }, function(err) {
                    clearTimeout(timer);
                    $ionicLoading.hide();
                    var confirmPopup = $ionicPopup.confirm({
                        template: 'Something went wrong!',
                        cssClass: 'popup_head_cust',
                        scope: $scope,
                        buttons: [{
                            text: 'Try Again!!',
                            onTap: function(e) {
                                $state.go($state.current, {}, { reload: true });
                            }
                        }]
                    });

                });

            }
            /* apitimeout*/
            function apiTimeout() {
                clearTimeout(timer);
                timer = setTimeout(function() {
                    $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
                    $ionicLoading.hide();
                }, delay_time);
            }
            //get cakedetail  api call
            GetCakesByPostcodeAndMiles.GetCakesByPostcodeAndMiles(pageno, pagesize,
                postalcode, miles).then(function(response) {
                var responseObject = JSON.parse(response);
                if (responseObject.ErrorID == 0) {
                    $ionicLoading.hide();
                    $scope.data.cakelist = responseObject.Cakes;
                    $scope.data.cakeCount = responseObject.CakeCount;
                } else {
                    // Error from API
                }
                clearTimeout(timer);
                $ionicLoading.hide();

            }, function(err) {
                clearTimeout(timer);
                $ionicLoading.hide();
                var confirmPopup = $ionicPopup.confirm({
                    template: 'Something went wrong!',
                    cssClass: 'popup_head_cust',
                    scope: $scope,
                    buttons: [{
                        text: 'Try Again!!',
                        onTap: function(e) {
                            $state.go($state.current, {}, { reload: true });
                        }
                    }]
                });

            });


            //change
            $scope.myGoBack = function() {
                if ($cordovaNetwork.isOffline()) {
                    $cordovaToast.showLongCenter("No internet connection!");
                } else {
                    $state.go("app.searchbusiness");
                }
            }
            $scope.loadMore = function() {
                if ((pageno * pagesize) < $scope.data.cakeCount) {
                    pageno = pageno + 1
                    timer = setTimeout(alertfun, delay_time);

                    function alertfun() {
                        $cordovaToast.showLongBottom('Respone is taking long time Please check Intenet Connectivity');
                        $ionicLoading.hide();
                    }
                    GetCakesByPostcodeAndMiles.GetCakesByPostcodeAndMiles(pageno, pagesize,
                        postalcode, miles).then(function(response) {
                        var responseObject = JSON.parse(response);
                        if (responseObject.ErrorID == 0) {
                            $ionicLoading.hide();
                            $.merge($scope.data.cakelist, responseObject.Cakes);

                        } else {
                            // Error from API
                        }
                        clearTimeout(timer);
                        $ionicLoading.hide();

                    }, function(err) {
                        clearTimeout(timer);
                        $ionicLoading.hide();
                        var confirmPopup = $ionicPopup.confirm({
                            template: 'Something went wrong!',
                            cssClass: 'popup_head_cust',
                            scope: $scope,
                            buttons: [{
                                text: 'Try Again!!',
                                onTap: function(e) {
                                    $state.go($state.current, {}, { reload: true });
                                }
                            }]
                        });

                    });
                }
                $scope.$broadcast('scroll.infiniteScrollComplete');
            };

            $scope.detailOfProduct = function(product_ID) {

                $rootScope.product_ID = product_ID;
                $state.go("app.cakedetail");
            }

            $scope.doRefresh = function() {

                $timeout(function() {
                    //simulate async response
                    if ((pageno * pagesize) < $scope.data.cakeCount) {
                        pageno = pageno + 1
                        timer = setTimeout(alertfun, delay_time);

                        function alertfun() {
                            $cordovaToast.showLongBottom('Respone is taking long time Please check Intenet Connectivity');
                            $ionicLoading.hide();
                        }
                        GetCakesByPostcodeAndMiles.GetCakesByPostcodeAndMiles(pageno, pagesize,
                            postalcode, miles).then(function(response) {
                            var responseObject = JSON.parse(response);
                            if (responseObject.ErrorID == 0) {
                                $ionicLoading.hide();
                                $.merge($scope.data.cakelist, responseObject.Cakes);

                            } else {
                                // Error from API
                            }
                            clearTimeout(timer);
                            $ionicLoading.hide();

                        }, function(err) {
                            clearTimeout(timer);
                            $ionicLoading.hide();
                            var confirmPopup = $ionicPopup.confirm({
                                template: 'Something went wrong!',
                                cssClass: 'popup_head_cust',
                                scope: $scope,
                                buttons: [{
                                    text: 'Try Again!!',
                                    onTap: function(e) {
                                        $state.go($state.current, {}, { reload: true });
                                    }
                                }]
                            });

                        });
                    }
                    //Stop the ion-refresher from spinning
                    $scope.$broadcast('scroll.refreshComplete');
                }, 1000);

            };

        });
