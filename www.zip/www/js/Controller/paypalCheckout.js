app.controller('paypalCheckoutCtrl', function($scope, $ionicPopup, $timeout, $ionicPlatform, $state, $ionicSideMenuDelegate, $rootScope,
    LocalStorage, $cordovaGeolocation, $cordovaNetwork, $cordovaToast, PaypalService) {
    $ionicPlatform.registerBackButtonAction(function(event) {
        $scope.myGoBack();
    }, 100);
    var CollectionMode;
    var timer;
    var delay_time = $rootScope.timer_delay;
    $scope.data = {};
    console.log($rootScope.detail);

    function calculateTotalSum() {

        var totalSum = 0;
        for (var i in $rootScope.detail) {
            if ($rootScope.detail[i].date) {
                var data = $rootScope.detail[i];
                CollectionMod = data.CollectionMode;
                totalSum += ((data.total_amt) * parseInt(data.quantity));
                if (data.accessories_total_amt != undefined) {
                    totalSum += data.accessories_total_amt;
                }
            }

        }
        $scope.data.Market_Price = totalSum;
        $rootScope.grand_total = $scope.data.Market_Price;
    };

    $scope.$on("$ionicView.afterEnter", function(event, data) {
        calculateTotalSum();
    });

    $ionicSideMenuDelegate.canDragContent(false);
    $scope.items = $rootScope.detail;
    $scope.deliveryMode = $scope.items.deliverAddress;
    $scope.backpaypal = true;
    //change
    $scope.myGoBack = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.cart");
        }
    };

    $scope.change_btn = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.filtersrch");
        }

    }



    function convertToJSONDate(strDate) {
        var dt = new Date(strDate);
        var newDate = new Date(Date.UTC(dt.getFullYear(), dt.getMonth(), dt.getDate(), dt.getHours(), dt.getMinutes(), dt.getSeconds(), dt.getMilliseconds()));
        return '/Date(' + newDate.getTime() + ')/';
    }

    $scope.payToProceed = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if ($rootScope.loggedin != true) {
            $state.go('app.login');
        } else if (CollectionMod == 1 && $rootScope.loggedin == true) {
            $state.go('app.stripayment');
        } else if ($rootScope.loggedin == true) {
            $rootScope.showFooter = true;
            $rootScope.statename = undefined;
            $state.go('app.shippingdetail');

        } else {
            $state.go("app.billingdetails", { 'addressObj': null });
        }
    }
});
