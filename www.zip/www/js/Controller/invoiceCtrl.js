app
    .controller(
        'invoiceCtrl',
        function($scope, LocalStorage, $state, $timeout,
            WebService, $rootScope, $cordovaNetwork, $ionicHistory,
            $ionicSideMenuDelegate, $window, $ionicPlatform,
            $cordovaNetwork, $cordovaToast) {
            $ionicSideMenuDelegate.canDragContent(false);
            //change
            $scope.myGoBack = function() {
                // if ($cordovaNetwork.isOffline()) {
                //     $cordovaToast.showLongCenter("No internet connection!");
                // } else {
                    $state.go("app.myorders");
                // }
            }


        });