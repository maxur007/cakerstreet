app.controller('customercareCtrl', function($scope, $window, $state, $timeout, $http, UploadCustomerPicture, $ionicHistory,
    $rootScope, WebService, $interval, $location, $ionicLoading,
    $cordovaNetwork, $cordovaToast, $ionicSideMenuDelegate, insertdevice, GetMilesListing,
    $ionicPlatform, $ionicPopup, $ionicActionSheet, $cordovaCamera, LocalStorage,
    $ionicModal, $cordovaGeolocation, GetCakesByPostcodeAndMiles, $ionicPopup, $stateParams, getbakerylist_bypostcode, $localStorage) {

    $scope.myGoBack = function() {
        $state.go('app.customer_requrments');
    }
    $scope.$on("$ionicView.afterEnter", function(event, data) {

        $scope.crf_id = $rootScope.crf_id;
        console.log($scope.crf_id);
    });

    $scope.formClick = function() {
        $state.go('app.home');
    }
});
