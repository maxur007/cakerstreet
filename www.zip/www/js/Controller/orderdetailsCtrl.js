app.controller('orderdetailsCtrl', function($scope, $ionicPopup, $state, $timeout, $filter, $cordovaNetwork, $ionicSideMenuDelegate, $rootScope, $stateParams, GetCustomerOrderDetail, $cordovaNetwork, $cordovaToast, $cordovaNetwork, $ionicLoading) {
    $ionicSideMenuDelegate.canDragContent(false);
    var timer;
    var delay_time = $rootScope.timer_delay;
    var customerID = $rootScope.CustomerID;
    console.log(customerID);
    $scope.order_details = {};
    $scope.accessorySum = 0;

    //change
    $scope.myGoBack = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.myorders");
        }
    }

    $scope.$on("$ionicView.enter", function(event, data) {
        // handle event
        if (data.stateParams.id !== '') {
            getcustomerdetails($rootScope.CustomerID, data.stateParams.id);
        }

    });

    function getDayName(dateString) {
        return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][new Date(dateString).getDay()];
    }

    //Api method
    function getcustomerdetails(cust_id, order_id) {
        $ionicLoading.show({
            noBackdrop: false,
            template: '<ion-spinner icon="ripple" class="spinner-assertive" ></ion-spinner>'
        });
        apiTimeout();
        GetCustomerOrderDetail.GetCustomerOrderDetail(cust_id, order_id).then(function(response) {
            $ionicLoading.hide();
            var result = JSON.parse(response);
            console.log(result);
            clearTimeout(timer);
            $scope.order_details.Order = result.Order;

            $scope.order_details.Order = result.Order;
            var orderdate = $scope.order_details.Order.OrderDate.split('T');
            $scope.orderDate = orderdate[0];
            var deliverydate = $scope.order_details.Order.DeliveryDate.split('T');
            $scope.deliveryDate = deliverydate[0];
            $scope.deliveryTime = deliverydate[1];
            $scope.deliveryDay = getDayName($scope.deliveryDate);
            $scope.order_details.orderTotal = $scope.order_details.Order.OrderTotal;
            $scope.order_details.deliverMode = $scope.order_details.Order.DeliveryMode;

            $scope.CollectAddress = result.CollectionAddress;
            $scope.order_details.BillingAddress = result.BillingAddress;
            $scope.order_details.ShippingAddress = result.ShippingAddress;
            $scope.order_details.CakeShape_Size_Type = result.CakeShape_Size_Type;
            $scope.OrderAttributes = result.OrderAttributes;

            $scope.accessoryCost($scope.OrderAttributes);
            $scope.OrderTotal = $scope.SubTotal = ($scope.order_details.Order.Quantity * $scope.order_details.orderTotal) + ($scope.accessorySum);


            //$scope.SubTotal = ($scope.order_details.Order.Quantity * $scope.order_details.Order.OrderTotal);


        }, function(err) {
            console.log(err);
            clearTimeout(timer);
            $ionicLoading.hide();
            var confirmPopup = $ionicPopup.confirm({
                template: 'Something went wrong!',
                cssClass: 'popup_head_cust',
                scope: $scope,
                buttons: [{
                    text: 'Try Again!!',
                    onTap: function(e) {
                        $state.go($state.current, {}, { reload: true });
                    }
                }]
            });

        });
    };

    $scope.accessoryCost = function(OrderAttributes) {
        for (var i in OrderAttributes) {
            if (OrderAttributes[i].FlavourType == 3) {
                $scope.accessorySum += OrderAttributes[i].TotalPrice;
            }
        }
    };

    //api timeout
    function apiTimeout() {
        clearTimeout(timer);
        timer = setTimeout(function() {
            $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
            $ionicLoading.hide();
        }, delay_time);
    }



});
