app
    .controller(
        'allproductsCtrl',
        function($scope, LocalStorage, $state, $timeout, $ionicHistory,
            WebService, $rootScope, $location,
            $ionicSideMenuDelegate, LocalStore, $window, $ionicPlatform, $ionicModal,
            $q, $http, $ionicLoading, $ionicModal, $cordovaNetwork, $cordovaToast) {


            $ionicSideMenuDelegate.canDragContent(false);

        });