app.controller('searchCriteriaCtrl', function($scope, $stateParams, $state, $timeout, $ionicHistory, WebService, $rootScope,
    $location, $localStorage, $ionicPopover, $ionicSideMenuDelegate, $window, $q, $http, $cordovaToast, $ionicLoading, $cordovaToast, $ionicModal,
    $ionicPopup, GetBakeriesAndCakesBypostcodeAndMiles, $ionicPopover, $cordovaNetwork, $rootScope, $ionicSideMenuDelegate, $cacheFactory, GetCakesByPostcodeAndMiles, GetCategories, $ionicPopup, LocalStorage) {


    $scope.selectMessege = true;
    $scope.itemfound = false;
    $scope.searchmiles = [];
    $scope.selected = '';
    $ionicSideMenuDelegate.canDragContent(false);
    var selectedMiles = '';
    $scope.itemNotFound = false;

    $scope.search_miles = $rootScope.miles;
    $scope.visualCategories = [];
    $scope.show_cat = true;
    $scope.titlepostcode = true;
    $scope.editbtn = true;
    $scope.searchoption = true;
    $scope.noMoreItemsAvailable = false;
    $scope.visualCategories = [];
    $scope.updateStatus = false;
    var bakery_pagesize = 10;
    var bakery_pageno = 1;
    var view = $ionicHistory.currentView();
    $localStorage.stateName = view.stateName;

    // Page no for cakes
    var pageno = 1,
        pagesize = 10;
    var miles = $rootScope.selectedvalue;
    var postalcode = $rootScope.postcode;
    var timer;
    var delay_time = $rootScope.timer_delay;
    $scope.data = {};

    $scope.$on("$ionicView.loaded", function(event, data) {
        // setTimeout(function() {
        //     _getCategories();
        // }, 200);

        if ($rootScope.selectedvalue !== null || $rootScope.postcode !== null) {
            $rootScope.postcode = $rootScope.postcode;
            $rootScope.selectedvalue = $rootScope.selectedvalue;
            $scope.data.milesdistance = $rootScope.selectedvalue;
            $rootScope.cake_catIds = "";
        }
    });

    $scope.$on("$ionicView.beforeEnter", function(event, data) {
        $rootScope.sortcode = 0;
        $scope.sortCategoryChoose = "Relevance";
    });

    $scope.$on("$ionicView.enter", function(event, data) {


    });

    $scope.$on("$ionicView.afterEnter", function(event, data) {
        $scope.loaderimage = true;

    });
    $scope.$on('$ionicView.afterLeave', function() {});

    $scope.backerylist = function(backerylist) {
        // $state.go("app.filter_detail", {
        //     'bakeryarray': backerylist
        // });
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            $state.go("app.backreydetail", {
                'bakeryarray': backerylist,
                'singleClicked': true
            });
        }
    }

    /* API section */

    function makingAPICallOnactions(param_postalcode, param_miles, param_catId) {
        if ($scope.data.bakerylist != undefined) {
            while ($scope.data.bakerylist.length > 0) {
                $scope.data.bakerylist.pop();
            }
        }
        if ($scope.data.cakelist != undefined) {
            while ($scope.data.cakelist.length > 0) {
                $scope.data.cakelist.pop();
            }
        }
        $scope.data.cakeCount = 0;
        $scope.data.bakeryCount = 0;
        pageno = 1;
        //$scope.noMoreItemsAvailable = false;
        $scope.data.milesdistance = miles = param_miles;
        postalcode = param_postalcode;
        hitAPIForDisplay(param_postalcode, param_miles, param_catId, false);
    }

    function hitAPIForDisplay(param_postcode, param_miles, param_catIds, param_callExternal) {
        //if (iscallAPI(param_miles, param_postcode, param_catIds)) {
        $scope.data.milesdistance = miles = param_miles;
        postalcode = param_postcode;
        $scope.$watch('online', function(newStatus) {
            if (newStatus == false) {
                $scope.loaderimage = false;
                $cordovaToast.showLongCenter("No internet connection!");
            }
            if (newStatus == true) {
                setTimeout(function() {
                    makeAPI_Call(bakery_pageno);
                }, 50);
                setTimeout(function() {
                    _getcakes(pageno, pagesize, param_postcode, param_miles, param_catIds, $rootScope.searchTextHeadercontent);
                }, 200);
            }
        });

    }

    function makeAPI_Call(pageno2load) {
        //  clearTimeout(timer);
        apiTimeout();
        GetBakeriesAndCakesBypostcodeAndMiles.GetBakeriesAndCakesBypostcodeAndMiles(pageno2load, bakery_pagesize,
            postalcode, miles, $rootScope.searchTextHeadercontent).then(function(response) {
            clearTimeout(timer);
            var resObject = JSON.parse(response);
            console.log(resObject.Bakeries.length);
            // $scope.loaderimage = false;
            if (resObject.ErrorID == 0) {
                if (resObject.Bakeries.length == 0) {
                    $scope.isHideBakerylist = true;

                } else {
                    $scope.isHideBakerylist = false;
                    $scope.data.bakerylist = resObject.Bakeries;
                    $scope.data.bakeryCount = resObject.BakeryCount;
                }
            } else {
                // Error from API
            }
        }, function(err) {
            console.log(err);
            clearTimeout(timer);
            $ionicLoading.hide();
            var confirmPopup = $ionicPopup.confirm({
                template: 'Something went wrong!',
                cssClass: 'popup_head_cust',
                scope: $scope,
                buttons: [{
                    text: 'Try Again!!',
                    onTap: function(e) {
                        $state.go($state.current, {}, { reload: true });
                    }
                }]
            });

        });
    }

    function _getcakes(param_pageno, param_cakecount, param_postalcode, param_miles, param_categoryIds, param_headertextsearch) {
        //clearTimeout(timer);
        apiTimeout();
        //get cakedetail  api call
        GetCakesByPostcodeAndMiles.GetCakesByPostcodeAndMiles(param_pageno, param_cakecount,
            param_postalcode, param_miles, param_categoryIds, param_headertextsearch, $rootScope.sortcode).then(function(response) {
            clearTimeout(timer);
            var responseObject = JSON.parse(response);
            console.log(responseObject);
            $scope.loaderimage = false;
            if (responseObject.ErrorID == 0) {

                if ($scope.data.cakelist === undefined) {
                    $scope.data.cakelist = responseObject.Cakes;
                } else {
                    $.merge($scope.data.cakelist, responseObject.Cakes);
                }
                $scope.data.cakeCount = responseObject.CakeCount;
                busyInLoading = false;
                notFound($scope.data.cakeCount == 0 ? true : false);
            } else {
                // Error from API
                notFound($scope.data.cakeCount == 0 ? true : false);
                $cordovaToast.showLongCenter(responseObject.ErrorMsg);
            }
        }, function(err) {
            console.log(err);
            clearTimeout(timer);
            $ionicLoading.hide();
            var confirmPopup = $ionicPopup.confirm({
                template: 'Something went wrong!',
                cssClass: 'popup_head_cust',
                scope: $scope,
                buttons: [{
                    text: 'Try Again!!',
                    onTap: function(e) {
                        $state.go($state.current, {}, { reload: true });
                    }
                }]
            });

        });
    }

    function notFound(val) {
        $scope.itemNotFound = val;
        $scope.itemfound = !val;
    }

    /* */
    function apiTimeout() {
        clearTimeout(timer);
        timer = setTimeout(function() {
            $cordovaToast.showLongBottom('Response is taking long time.Please wait while we process your request');
            $ionicLoading.hide();
        }, delay_time);
    }
    /* Infinite Scroll */
    var busyInLoading = false;
    $scope.loadMore = function() {
        if ($cordovaNetwork.isOffline()) {
            $scope.loaderimage = false;
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            if (!busyInLoading) {
                busyInLoading = true;
                if ((parseInt(pageno) * pagesize) < $scope.data.cakeCount) {
                    pageno = parseInt(pageno) + 1;
                    $scope.loaderimage = true;
                    $scope.noMoreItemsAvailable = false;
                    _getcakes(pageno, pagesize, $rootScope.postcode, $rootScope.selectedvalue, $rootScope.cake_catIds, $rootScope.searchTextHeadercontent);
                } else {
                    $scope.loaderimage = false;
                    if ($scope.data.cakeCount != undefined)
                        $scope.loaderimage = false;
                    $scope.noMoreItemsAvailable = true;
                }
            }
            $scope.$broadcast('scroll.infiniteScrollComplete');
        }
    };
    /* Infinite Scroll End */
    $scope.cakesClicked = function() {
        $scope.isHideBakerylist = true;
    }
    $scope.businessClick = function() {
        if ($scope.updateStatus) {
            $scope.updateStatus = false;
            $state.go("app.filter_detail", {
                'bakeryarray': $scope.data.bakerylist
            }, { 'cache': true });
        } else {
            var stateName = "app.filter_detail"
            console.log($ionicHistory.backView());
            var backFound = false;
            var historyId = $ionicHistory.currentHistoryId();
            var history = $ionicHistory.viewHistory().histories[historyId];
            for (var i = history.stack.length - 1; i >= 0; i--) {
                if (history.stack[i].stateName == stateName) {
                    $ionicHistory.backView(history.stack[i]);
                    backFound = true;
                    $ionicHistory.goBack();
                }
            }
            if (!backFound) {
                $state.go("app.filter_detail", {
                    'bakeryarray': $scope.data.bakerylist
                }, { 'cache': true });
            }
        }
    }
    $scope.detailOfProduct = function(cakeID, prd_apitype, image, data) {
        //  alert(prd_apitype);
        if (prd_apitype == 0) {
            var cakeObjInfo = { 'id': cakeID };
            $state.go("app.cakedetail", { 'cakeid': cakeObjInfo }, { 'cache': true });
        } else if (prd_apitype == 1 || prd_apitype == 2) {
            $rootScope.dataOfcake = data;
            $state.go("app.customer_requrments", { 'imageparmas': image });
        }
    }

    var isBusyWithRefresh = false;
    $scope.doRefresh = function() {
        if (!isBusyWithRefresh) {
            isBusyWithRefresh = true;
            pageno = 1;
            pagesize = 10;
            $timeout(function() {
                makingAPICallOnactions($rootScope.postcode, $rootScope.selectedvalue, $rootScope.cake_catIds);
                isBusyWithRefresh = false;
                $scope.$broadcast('scroll.refreshComplete');
            }, 500);
        }
    };
    /* header handlers and actions */
    $scope.headerEditPostalCode_ClickHandler = function() {
        $scope.data.areacode = $rootScope.postcode;
        $scope.editCode = true;
        setTimeout(function() {
            $('#code').select();
            cordova.plugins.Keyboard.show();
        }, 50);
    };
    $scope.headerSearchPostalcode_InputHandler = function() {
        if ($rootScope.postcode === $scope.data.areacode) {
            setTimeout(function() {
                cordova.plugins.Keyboard.close();
            }, 50);
            return;
        } else {
            $rootScope.postcode = $scope.data.areacode;
            $scope.editCode = false;
            $scope.updateStatus = true;
            setTimeout(function() {
                cordova.plugins.Keyboard.close();
            }, 50);
            setTimeout(function() {
                $state.reload();
            }, 200);
        }
    }

    $scope.headerSearch_InputHandler = function(searchcontent) {

        if (searchcontent == '' || searchcontent == undefined) {
            $cordovaToast.showLongCenter("enter search keywords");
        } else {
            console.log(searchcontent);
            $rootScope.searchTextHeadercontent = searchcontent;
            $scope.selectMessege = false;
            $scope.itemfound = true;
            $scope.itemNotFound = false;
            // $scope.selectMessege = true;
            makingAPICallOnactions($rootScope.postcode, $rootScope.selectedvalue, "", true);
            // _getcakes(pageno, pagesize, $rootScope.postcode, $rootScope.selectedvalue, $rootScope.cake_catIds, $rootScope.searchTextHeadercontent);
            cordova.plugins.Keyboard.close();

        }

    }


    $scope.headerSearch_CloseHandler = function() {
        $rootScope.searchTextHeadercontent = "";
        $state.go("app.searchbusiness");
        $scope.editbtn = true;
        $scope.titlepostcode = true;
        $scope.searchoption = false;
        $scope.maindiv = false;

    }

    $scope.headerSearch_ClickHandler = function() {
        $scope.editCode = false;
        $scope.titlepostcode = false;
        $scope.editbtn = true;
        $scope.searchoption = true;
        $scope.maindiv = true;
        setTimeout(function() {
            $('.keyword-search').select();
        }, 50);
    }

    //change
    $scope.headerCart_ClickHandler = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if ($rootScope.detail.length == 0) {
            $cordovaToast.showLongBottom("Cart is empty");
        } else {
            $state.go("app.cart");
        }
    }

    $scope.popover = $ionicPopover.fromTemplate(template, {
        scope: $scope
    });


    $ionicPopover.fromTemplateUrl('sortby-popover.html', {
        scope: $scope
    }).then(function(popover) {
        $scope.popover = popover;
    });


    $scope.openPopover = function($event) {
        $scope.popover.show($event);
    };

    $scope.closePopover = function() {
        $scope.popover.hide();
    };

    $scope.sortingCakes = function(sortValue, sortName) {
        $rootScope.sortcode = sortValue;
        $scope.sortCategoryChoose = sortName;
        $scope.popover.hide();
        $scope.data.cakelist = [];
        _getcakes(pageno, pagesize, $rootScope.postcode, $rootScope.selectedvalue, $rootScope.cake_catIds, $rootScope.searchTextHeadercontent);
    };

});
