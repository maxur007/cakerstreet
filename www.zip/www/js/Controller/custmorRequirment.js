app.controller('customer_requirmentCtrl', function($scope, $stateParams, $state, $timeout, GetBakeriesAndCakesBypostcodeAndMiles, GetCakesByPostcodeAndMiles, $rootScope, $location, $ionicSideMenuDelegate, $window, $ionicPlatform, GetCategories, $timeout, $filter, $ionicHistory,
    $q, $http, ionicDatePicker, $cordovaNetwork, $ionicPlatform, $cordovaDevice, $ionicActionSheet, $rootScope, $cordovaCamera, $ionicPopup, CustomrequirementForm_Submit, Customrequirement_AttributeList, $localStorage, $cordovaToast, $ionicPopover, $ionicLoading, $cordovaNetwork, $ionicModal, $ionicSlideBoxDelegate, Customrequirement_optionList) {
    //  $timeout(function() {
    $scope.img = 'img/not-available.jpg';
    var image = $scope.img;
    var imagepath;
    $ionicPlatform.registerBackButtonAction(function(event) {
        $scope.myGoBack();

    }, 100);
    $scope.$on("$ionicView.afterEnter", function(event, data) {
        currentdate();
        $scope.occassionArray = [];
        $scope.cakeTypeArray = [];
        $scope.cakeShapeArray = [];
        $scope.groups = [];
        $scope.messages = [];
        $scope.data = {};
        $scope.attributesJson = [];
        $scope.data.miles = 0;
        $scope.data.deliver = 0;
        $scope.data.collect = 0;
        $scope.data.emailId = $rootScope.userdetail.Email;
        $scope.data.uid = $rootScope.CustomerID;
        if ($scope.data.uid == null || undefined || "") {
            $scope.data.uid = 0;
            console.log($scope.data.uid);
        }
        $rootScope.img_news = $state.params.imageparmas;
        console.log($rootScope.img_news + " " + "in images");
        console.log($scope.data.uid + " " + "in cusotmer page");
        Customrequirement_optionList.Customrequirement_optionList().then(function(response) {
            var resObject = JSON.parse(response);
            //console.log(resObject);
            for (var i = 0; i < resObject.Filter.Occsasion.length; i++) {
                //console.log(resObject.Filter.Occsasion[i]);
                $scope.occassionArray.push(resObject.Filter.Occsasion[i]);
            }
            //   cakeTypeArray
            for (var i = 0; i < resObject.Filter.CakeType.length; i++) {
                $scope.cakeTypeArray.push(resObject.Filter.CakeType[i]);
            }
            //     cakeShapeArray
            for (var i = 0; i < resObject.Filter.CakeShape.length; i++) {
                $scope.cakeShapeArray.push(resObject.Filter.CakeShape[i]);
            }
        });
        Customrequirement_AttributeList.Customrequirement_AttributeList().then(function(response) {
            var resObject = JSON.parse(response);
            console.log(resObject.CakeFlavour.length);
            for (var i = 0; i < resObject.CakeFlavour.length; i++) {
                // console.log(resObject.CakeFlavour[i]);
                if (resObject.CakeFlavour[i].Attribute_ViewType == "Message Box") {
                    $scope.messages.push(resObject.CakeFlavour[i]);
                } else if (resObject.CakeFlavour[i].Attribute_ViewType == "Selection") {
                    $scope.groups.push(resObject.CakeFlavour[i]);
                    // console.log(resObject.CakeFlavour[i]);
                }
            }
        });
        //console.log($state.params.imageparmas);
        if ($state.params.imageparmas == null) {
            $scope.img = 'img/not-available.jpg';
        } else {
            $scope.img = $state.params.imageparmas;
        }
        if (!$scope.data.emailId) {
            $scope.data.emailId = ''
        } else {
            $scope.data.emailId = $localStorage.userDetails.Email;
        }
    });
    $ionicSideMenuDelegate.canDragContent(false);
    //change
    $scope.myGoBack = function() {
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else if ($rootScope.previousState == 'app.searchbusiness') {
            $state.go("app.searchbusiness");
        } else {
            $state.go("app.searchbusiness");
        }
    }
    $scope.imgs = 'https://ionicframework.com/img/ionic-logo-blog.png';
    $scope.aImages = [{
        'src': 'https://ionicframework.com/img/ionic-logo-blog.png',
        'msg': 'Swipe me to the left. Tap/click to close'
    }, {
        'src': 'https://ionicframework.com/img/ionic_logo.svg',
        'msg': ''
    }, {
        'src': 'https://ionicframework.com/img/homepage/phones-weather-demo@2x.png',
        'msg': ''
    }];
    $ionicModal.fromTemplateUrl('image-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modal = modal;
    });
    $ionicModal.fromTemplateUrl('templates/mylongform.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modalsInput = modal;
    });
    // Modal for occassion input
    $ionicModal.fromTemplateUrl('templates/occassion.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.occassions = modal;
    });
    $scope.openModelFieldOccassion = function() {
        $scope.occassions.show();
    };
    // Modal for time input
    $ionicModal.fromTemplateUrl('templates/time.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.times = modal;
    });
    $scope.openModelFieldtime = function() {
        $scope.times.show();
    };
    $scope.openModelField = function() {
        $scope.modalsInput.show();
    };
    $ionicModal.fromTemplateUrl('templates/size.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modalsForSize = modal;
    });
    $scope.openModelFieldSize = function() {
        $scope.modalsForSize.show();
    };
    $scope.openModal = function() {
        $ionicSlideBoxDelegate.slide(0);
        $scope.modal.show();
    };
    $scope.closeModal = function() {
        $scope.modalsInput.hide();
        $scope.modal.hide();
        $scope.modalsForSize.hide();
        $scope.occassions.hide();
        $scope.times.hide();
        //$scope.forms.hide();
    };
    $scope.clicker = function() {
        $scope.modalsInput.hide();
        $scope.modal.hide();
        $scope.modalsForSize.hide();
        $scope.occassions.hide();
        $scope.times.hide();
        //$scope.forms.hide();
    };
    // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function() {
        $scope.modal.remove();
    });
    // Execute action on hide modal
    $scope.$on('modal.hide', function() {
        // Execute action
    });
    // Execute action on remove modal
    $scope.$on('modal.removed', function() {
        // Execute action
    });
    $scope.$on('modal.shown', function() {
        console.log('Modal is shown!');
    });
    // Call this functions if you need to manually control the slides
    $scope.next = function() {
        $ionicSlideBoxDelegate.next();
    };
    $scope.previous = function() {
        $ionicSlideBoxDelegate.previous();
    };
    $scope.goToSlide = function(index) {
            $scope.modal.show();
            $ionicSlideBoxDelegate.slide(index);
        }
        // Called each time the slide changes
    $scope.slideChanged = function(index) {
        $scope.slideIndex = index;
    };

    var datePickerObj1 = {};

    $scope.callDatePicker = function() {
        var datePickerObj1 = {
            inputDate: new Date(),
            titleLabel: 'Select a Date',
            setLabel: 'Set',
            todayLabel: 'Today',
            closeLabel: 'Close',
            // mondayFirst: true,
            weeksList: ["S", "M", "T", "W", "T", "F", "S"],
            monthsList: ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"],
            templateType: 'popup',
            from: new Date(),
            to: new Date(2020, 1, 1),
            showTodayButton: false,
            dateFormat: 'MMMM dd  yyyy',
            closeOnSelect: false,
            callback: function(val) { //Mandatory
                if (!val) {
                    $cordovaToast
                        .show("Please select the Order Date range !", 'short', 'center')
                        .then(function(success) {

                        }, function(error) {

                        });
                } else {
                    var date = new Date(val);
                    $scope.date = date;
                    var year = date.getFullYear();
                    var month = date.getMonth() + 1;
                    if (month < 10) {
                        month = "0" + month;
                    }
                    var fullDate = date.getDate();
                    if (fullDate < 10) {
                        fullDate = "0" + fullDate;
                    }
                    $scope.datepicker = year + '-' + month + '-' + fullDate;
                    $scope.datepickerShow = fullDate + '-' + month + '-' + year;
                    console.log($scope.datepickerShow);
                    //check for current date
                    if ($scope.datepicker >= $scope.today) {
                        console.log("setdate here");
                        $scope.data.date = $scope.datepickerShow;
                        console.log($scope.data.date);
                    } else {
                        $cordovaToast.showLongCenter("select current date");
                    }
                }
            }
        };

        ionicDatePicker.openDatePicker(datePickerObj1);
    };

    $scope.time = [
        { id: '08:00 AM', value: '08_00_00' },
        { id: '09:00 AM', value: '09_00_00' },
        { id: '10:00 AM', value: '10_00_00' },
        { id: '11:00 AM', value: '11_00_00' },
        { id: '12:00 PM', value: '12_00_00' },
        { id: '1:00 PM', value: '13_00_00' },
        { id: '2:00 PM', value: '14_00_00' },
        { id: '3:00 PM', value: '15_00_00' },
        { id: '4:00 PM', value: '16_00_00' },
        { id: '5:00 PM', value: '17_00_00' },
        { id: '6:00 PM', value: '18_00_00' },
        { id: '7:00 PM', value: '19_00_00' },
        { id: '8:00 PM', value: '20_00_00' },
    ];
    /*
     * if given group is the selected group, deselect it
     * else, select the given group
     */
    $scope.toggleGroup = function(group) {
        if ($scope.isGroupShown(group)) {
            $scope.shownGroup = null;
        } else {
            $scope.shownGroup = group;
        }
    };
    $scope.isGroupShown = function(group) {
        return $scope.shownGroup === group;
    };
    $scope.selectedvalue = function(item_id, ques_name) {
        console.log("FlavourID" + " " + item_id);
        console.log("q_name" + " " + ques_name);
        $scope.attributesJson[$scope.id_q] = { "CRFAtt_ID": 0, "CRFAtt_CRFID": 0, "CRFAtt_ParentattID": $scope.id_q, "CRFAtt_AttID": item_id, "CRFAtt_datatext": "", "CRFAtt_ViewType": 1, "CRFAtt_createOn": 0, "CRFAtt_modifiedOn": 0 };
        console.log($scope.attributesJson);
    }
    $scope.selectedval = function(group_id, group_name) {
        console.log(group_id);
        console.log(group_name);
        $scope.id_q = group_id;
    }
    $scope.toggleSubGroup = function(group) {
        // console.log(group);
        $scope.id_q = group.FlavourID;
        if ($scope.isGroupShown(group)) {
            $scope.shownGroup = null;
        } else {
            $scope.shownGroup = group;
        }
        // console.log(group);
        //return $scope.shownGroup === group;
    };
    $scope.toggleGroup = function(group) {
        console.log(JSON.stringify(group.FlavourID));
        $scope.id_q = group.FlavourID;
        if ($scope.isGroupShown(group)) {
            $scope.shownGroup = null;
        } else {
            $scope.shownGroup = group;
        }
    };
    $scope.miles_opt = function() {
        $("#miles_opt").toggle();
    }

    $scope.tocustomercare = function() {
        console.log($scope.data);
        console.log($scope.data.date);
        if ($cordovaNetwork.isOffline()) {
            $cordovaToast.showLongCenter("No internet connection!");
        } else {
            var regPostcode = /^([a-zA-Z]){1}([0-9][0-9]|[0-9]|[a-zA-Z][0-9][a-zA-Z]|[a-zA-Z][0-9][0-9]|[a-zA-Z][0-9]){1}([ ])|([0-9][a-zA-z][a-zA-z]){1}$/;
            if (!$scope.data.discription) {
                $cordovaToast.showLongCenter("Please fill the Description");
            } else if (!$scope.data.selcectOccasion) {
                $cordovaToast.showLongCenter("Please fill the Occasion");
            } else if (!$scope.data.date) {
                $cordovaToast.showLongCenter("Please select the date");
            } else if (!$scope.data.selcectTime) {
                $cordovaToast.showLongCenter("Please select time");
            } else if ($scope.data.postcode == '' || $scope.data.postcode == undefined) {
                $cordovaToast.showLongBottom("Please Enter postalcode");
            } else if (regPostcode.test($scope.data.postcode) == false) {
                $cordovaToast.showLongCenter("Enter valid postcode");
            } else if (!$scope.data.deliver && !$scope.data.collect) {
                $cordovaToast.showLongCenter("Please select any option collection/delivery");
            } else if (!$scope.data.name) {
                $cordovaToast.showLongCenter("Please fill the name");
            } else if (!$scope.data.contact) {
                $cordovaToast.showLongCenter("Please fill the contact");
            } else {
                var s = $scope.data.date.replace(/\-/g, '_');
                console.log(s);
                $scope.date_time = s + "_" + $scope.data.selcectTime.value;
                console.log($scope.date_time);
                if ($scope.img == $state.params.imageparmas) {
                    isimage = 1;
                    imgbool_1 = 0;
                    $scope.imgURI = " ";
                } else {
                    console.log("here we go");
                    isimage = 1;
                    imgbool_1 = 1;
                }

                console.log($scope.attributesJson);
                if (del) {
                    $scope.data.deliver = 1;
                } else {
                    $scope.data.deliver = 0;
                }
                var coll = $('#coll').is(':checked');
                if (coll) {
                    $scope.data.collect = 1
                } else {
                    $scope.data.collect = 0;
                }
                console.log("im here");
                console.log($scope.data.deliver);
                console.log($scope.data.collect);
                console.log($scope.data.date);
                console.log($scope.attributesJson);
                var newArray = [];
                $.each($scope.attributesJson, function(idx, obj) {
                    if (obj != null) {
                        newArray.push(obj);
                    }
                });
                var json_data = JSON.stringify(newArray);
                if ($scope.img == image) {
                    $cordovaToast.showLongCenter("Please add image to upload");
                } else {
                    CustomrequirementForm_Submit.CustomrequirementForm_Submit(0, 0, 0, $scope.data.uid, $scope.data.name, $scope.data.emailId, $scope.data.AlergyAdvice, $scope.data.discription, $scope.data.remark, $scope.data.contact, $scope.data.postcode, $scope.date_time, $scope.data.collect, $scope.data.miles, $scope.data.deliver, $scope.data.text, $scope.data.occid, $scope.data.min_portion, $scope.data.max_portion, $scope.data.size, $scope.data.shapeid, $scope.data.typeid,
                        imgbool_1, isimage, $scope.imgURI, 0, 0, "", 0, 0, "", 0, 0, "", json_data).then(function(response) {
                        console.log(response);
                        console.log(JSON.parse(response));
                        $scope.result = JSON.parse(response);
                        console.log($scope.result.CRFID);
                        //console.log(Object.values(response));
                        $rootScope.crf_id = $scope.result.CRFID;
                        $state.go('app.customercare');
                    });
                }
                //}
                // $scope.forms.hide();
            }
        }
    };

    $scope.uploadProfile = function(index) {
        var hideSheet = $ionicActionSheet.show({
            buttons: [
                { text: '<b>Camera</b> ' },
                { text: 'Gallery' },
                { text: 'Cancel' }
            ],
            //destructiveText: 'Gallery',
            titleText: 'Please choose',
            cancelText: 'Cancel',
            cancel: function() {
                // add cancel code..
            },
            buttonClicked: function(index) {
                if (index == 0) {
                    var options = {
                        quality: 75,
                        destinationType: Camera.DestinationType.DATA_URL,
                        sourceType: Camera.PictureSourceType.CAMERA,
                        allowEdit: true,
                        encodingType: Camera.EncodingType.JPEG,
                        targetWidth: 300,
                        targetHeight: 300,
                        popoverOptions: CameraPopoverOptions,
                        saveToPhotoAlbum: false
                    };
                    $cordovaCamera.getPicture(options).then(function(imageData) {
                        $scope.fileURL = imageData;
                        console.log(imageData);
                        imagepath = imageData;
                        $scope.imgURI = imagepath;
                        $scope.img = "data:image/jpeg;base64," + imagepath;
                        imagebsee64 = imageData;
                        $scope.imgURI = imagepath;
                        console.log($scope.imgURI);
                    }, function(err) {
                        // An error occured. Show a message to the user
                    });
                }
                if (index == 1) {
                    var options = {
                        quality: 75,
                        destinationType: Camera.DestinationType.DATA_URL,
                        sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                        allowEdit: true,
                        encodingType: Camera.EncodingType.JPEG,
                        targetWidth: 300,
                        targetHeight: 300,
                        popoverOptions: CameraPopoverOptions,
                        saveToPhotoAlbum: false
                    };
                    $cordovaCamera.getPicture(options).then(function(imageData) {
                        $scope.fileURL = imageData;
                        imagepath = imageData;
                        $scope.imgURI = imagepath;
                        $scope.img = "data:image/jpeg;base64," + imagepath;
                        imagebsee64 = imageData;
                        console.log("base64");
                        console.log($scope.imgURI);
                    }, function(err) {});
                }
                if (index == 2) {
                    $timeout(function() {
                        hideSheet();
                    }, 500);
                }
                return true;
            }
        });
    };
    $scope.clickerShape = function(shape) {
        $scope.data.shapeid = shape.id;
        console.log($scope.data.shapeid);
        $scope.data.selectShape = shape.title;
        $rootScope.occassion = $scope.data.selcectOccasion;
        $scope.modalsInput.hide();
    }
    $scope.clickerType = function(type) {
        $scope.data.typeid = type.id;
        console.log($scope.data.typeid);
        $scope.data.selectType = type.title;

        $scope.modalsForSize.hide();
    }
    $scope.clickerTime = function(time) {
        $scope.data.selcectTime = time;
        $scope.times.hide();
    }
    $scope.clickerOccassion = function(occ) {
            $scope.data.occid = occ.id;
            console.log($scope.data.occid);
            $scope.data.selcectOccasion = occ.title;
            $scope.Occassion = {
                "occ_title": $scope.data.selcectOccasion,
                "occ_time": $scope.data.selcectTime,
                "occ_date": $scope.data.date
            }
            console.log("occassion details");
            $rootScope.occ_detail = $scope.Occassion;
            console.log($rootScope.occ_detail);
            $scope.occassions.hide();
        }
        //get current date 
    function currentdate() {
        $scope.today = new Date();
        var dd = $scope.today.getDate();
        var mm = $scope.today.getMonth() + 1; //January is 0!
        var yyyy = $scope.today.getFullYear();

        if (dd < 10) {
            dd = '0' + dd
        }

        if (mm < 10) {
            mm = '0' + mm
        }
        $scope.today = yyyy + '-' + mm + '-' + dd;
        console.log($scope.today);
    }

});
